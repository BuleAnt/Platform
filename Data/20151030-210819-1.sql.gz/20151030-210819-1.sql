-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : 127.0.0.1
-- Port     : 3306
-- Database : onethink
-- 
-- Part : #1
-- Date : 2015-10-30 21:08:19
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `onethink_action`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_action`;
CREATE TABLE `onethink_action` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` char(30) NOT NULL DEFAULT '' COMMENT '行为唯一标识',
  `title` char(80) NOT NULL DEFAULT '' COMMENT '行为说明',
  `remark` char(140) NOT NULL DEFAULT '' COMMENT '行为描述',
  `rule` text COMMENT '行为规则',
  `log` text COMMENT '日志规则',
  `type` tinyint(2) unsigned NOT NULL DEFAULT '1' COMMENT '类型',
  `status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '状态',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '修改时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='系统行为表';

-- -----------------------------
-- Records of `onethink_action`
-- -----------------------------
INSERT INTO `onethink_action` VALUES ('1', 'user_login', '用户登录', '积分+10，每天一次', 'table:member|field:score|condition:uid={$self} AND status>-1|rule:score+10|cycle:24|max:1;', '[user|get_nickname]在[time|time_format]登录了后台', '1', '1', '1387181220');
INSERT INTO `onethink_action` VALUES ('2', 'add_article', '发布文章', '积分+5，每天上限5次', 'table:member|field:score|condition:uid={$self}|rule:score+5|cycle:24|max:5', '', '2', '0', '1380173180');
INSERT INTO `onethink_action` VALUES ('3', 'review', '评论', '评论积分+1，无限制', 'table:member|field:score|condition:uid={$self}|rule:score+1', '', '2', '1', '1383285646');
INSERT INTO `onethink_action` VALUES ('4', 'add_document', '发表文档', '积分+10，每天上限5次', 'table:member|field:score|condition:uid={$self}|rule:score+10|cycle:24|max:5', '[user|get_nickname]在[time|time_format]发表了一篇文章。\r\n表[model]，记录编号[record]。', '2', '0', '1386139726');
INSERT INTO `onethink_action` VALUES ('5', 'add_document_topic', '发表讨论', '积分+5，每天上限10次', 'table:member|field:score|condition:uid={$self}|rule:score+5|cycle:24|max:10', '', '2', '0', '1383285551');
INSERT INTO `onethink_action` VALUES ('6', 'update_config', '更新配置', '新增或修改或删除配置', '', '', '1', '1', '1383294988');
INSERT INTO `onethink_action` VALUES ('7', 'update_model', '更新模型', '新增或修改模型', '', '', '1', '1', '1383295057');
INSERT INTO `onethink_action` VALUES ('8', 'update_attribute', '更新属性', '新增或更新或删除属性', '', '', '1', '1', '1383295963');
INSERT INTO `onethink_action` VALUES ('9', 'update_channel', '更新导航', '新增或修改或删除导航', '', '', '1', '1', '1383296301');
INSERT INTO `onethink_action` VALUES ('10', 'update_menu', '更新菜单', '新增或修改或删除菜单', '', '', '1', '1', '1383296392');
INSERT INTO `onethink_action` VALUES ('11', 'update_category', '更新分类', '新增或修改或删除分类', '', '', '1', '1', '1383296765');

-- -----------------------------
-- Table structure for `onethink_action_log`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_action_log`;
CREATE TABLE `onethink_action_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `action_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '行为id',
  `user_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '执行用户id',
  `action_ip` bigint(20) NOT NULL COMMENT '执行行为者ip',
  `model` varchar(50) NOT NULL DEFAULT '' COMMENT '触发行为的表',
  `record_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '触发行为的数据id',
  `remark` varchar(255) NOT NULL DEFAULT '' COMMENT '日志备注',
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '状态',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '执行行为的时间',
  PRIMARY KEY (`id`),
  KEY `action_ip_ix` (`action_ip`),
  KEY `action_id_ix` (`action_id`),
  KEY `user_id_ix` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=234 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='行为日志表';

-- -----------------------------
-- Records of `onethink_action_log`
-- -----------------------------
INSERT INTO `onethink_action_log` VALUES ('1', '1', '1', '2130706433', 'member', '1', 'admin在2015-08-30 20:59登录了后台', '1', '1440939589');
INSERT INTO `onethink_action_log` VALUES ('2', '1', '1', '2130706433', 'member', '1', 'admin在2015-08-30 21:02登录了后台', '1', '1440939773');
INSERT INTO `onethink_action_log` VALUES ('3', '11', '1', '2130706433', 'category', '39', '操作url：/wwwroot/admin.php?s=/Category/add.html', '1', '1440940433');
INSERT INTO `onethink_action_log` VALUES ('4', '1', '2', '2130706433', 'member', '2', 'cheng1483在2015-08-30 22:19登录了后台', '1', '1440944380');
INSERT INTO `onethink_action_log` VALUES ('5', '1', '1', '2130706433', 'member', '1', 'admin在2015-09-03 21:26登录了后台', '1', '1441286788');
INSERT INTO `onethink_action_log` VALUES ('6', '9', '1', '2130706433', 'channel', '2', '操作url：/wwwroot/admin.php?s=/Channel/edit.html', '1', '1441287166');
INSERT INTO `onethink_action_log` VALUES ('7', '9', '1', '2130706433', 'channel', '3', '操作url：/wwwroot/admin.php?s=/Channel/edit.html', '1', '1441287231');
INSERT INTO `onethink_action_log` VALUES ('8', '9', '1', '2130706433', 'channel', '4', '操作url：/wwwroot/admin.php?s=/Channel/edit.html', '1', '1441287292');
INSERT INTO `onethink_action_log` VALUES ('9', '1', '1', '2130706433', 'member', '1', 'admin在2015-09-08 12:50登录了后台', '1', '1441687842');
INSERT INTO `onethink_action_log` VALUES ('10', '1', '1', '2130706433', 'member', '1', 'admin在2015-09-10 10:53登录了后台', '1', '1441853605');
INSERT INTO `onethink_action_log` VALUES ('11', '1', '1', '2130706433', 'member', '1', 'admin在2015-09-10 14:17登录了后台', '1', '1441865820');
INSERT INTO `onethink_action_log` VALUES ('12', '1', '1', '2130706433', 'member', '1', 'admin在2015-09-11 09:29登录了后台', '1', '1441934963');
INSERT INTO `onethink_action_log` VALUES ('13', '1', '1', '2130706433', 'member', '1', 'admin在2015-09-11 10:39登录了后台', '1', '1441939142');
INSERT INTO `onethink_action_log` VALUES ('14', '1', '1', '2130706433', 'member', '1', 'admin在2015-09-12 21:08登录了后台', '1', '1442063313');
INSERT INTO `onethink_action_log` VALUES ('15', '1', '1', '2130706433', 'member', '1', 'admin在2015-09-14 08:39登录了后台', '1', '1442191140');
INSERT INTO `onethink_action_log` VALUES ('16', '1', '1', '2130706433', 'member', '1', 'admin在2015-09-14 22:41登录了后台', '1', '1442241673');
INSERT INTO `onethink_action_log` VALUES ('17', '7', '1', '2130706433', 'model', '4', '操作url：/wwwroot/admin.php?s=/Model/update.html', '1', '1442241921');
INSERT INTO `onethink_action_log` VALUES ('18', '1', '1', '2130706433', 'member', '1', 'admin在2015-09-15 08:07登录了后台', '1', '1442275651');
INSERT INTO `onethink_action_log` VALUES ('19', '8', '1', '2130706433', 'attribute', '34', '操作url：/wwwroot/admin.php?s=/Attribute/update.html', '1', '1442275744');
INSERT INTO `onethink_action_log` VALUES ('20', '8', '1', '2130706433', 'attribute', '35', '操作url：/wwwroot/admin.php?s=/Model/generate.html', '1', '1442277965');
INSERT INTO `onethink_action_log` VALUES ('21', '8', '1', '2130706433', 'attribute', '36', '操作url：/wwwroot/admin.php?s=/Model/generate.html', '1', '1442277965');
INSERT INTO `onethink_action_log` VALUES ('22', '8', '1', '2130706433', 'attribute', '37', '操作url：/wwwroot/admin.php?s=/Model/generate.html', '1', '1442277965');
INSERT INTO `onethink_action_log` VALUES ('23', '8', '1', '2130706433', 'attribute', '38', '操作url：/wwwroot/admin.php?s=/Model/generate.html', '1', '1442277965');
INSERT INTO `onethink_action_log` VALUES ('24', '8', '1', '2130706433', 'attribute', '39', '操作url：/wwwroot/admin.php?s=/Model/generate.html', '1', '1442277965');
INSERT INTO `onethink_action_log` VALUES ('25', '8', '1', '2130706433', 'attribute', '40', '操作url：/wwwroot/admin.php?s=/Model/generate.html', '1', '1442277965');
INSERT INTO `onethink_action_log` VALUES ('26', '8', '1', '2130706433', 'attribute', '41', '操作url：/wwwroot/admin.php?s=/Model/generate.html', '1', '1442277965');
INSERT INTO `onethink_action_log` VALUES ('27', '8', '1', '2130706433', 'attribute', '42', '操作url：/wwwroot/admin.php?s=/Model/generate.html', '1', '1442277965');
INSERT INTO `onethink_action_log` VALUES ('28', '8', '1', '2130706433', 'attribute', '43', '操作url：/wwwroot/admin.php?s=/Model/generate.html', '1', '1442277965');
INSERT INTO `onethink_action_log` VALUES ('29', '8', '1', '2130706433', 'attribute', '44', '操作url：/wwwroot/admin.php?s=/Model/generate.html', '1', '1442279192');
INSERT INTO `onethink_action_log` VALUES ('30', '8', '1', '2130706433', 'attribute', '45', '操作url：/wwwroot/admin.php?s=/Model/generate.html', '1', '1442279192');
INSERT INTO `onethink_action_log` VALUES ('31', '8', '1', '2130706433', 'attribute', '46', '操作url：/wwwroot/admin.php?s=/Model/generate.html', '1', '1442279192');
INSERT INTO `onethink_action_log` VALUES ('32', '8', '1', '2130706433', 'attribute', '47', '操作url：/wwwroot/admin.php?s=/Model/generate.html', '1', '1442279192');
INSERT INTO `onethink_action_log` VALUES ('33', '8', '1', '2130706433', 'attribute', '48', '操作url：/wwwroot/admin.php?s=/Model/generate.html', '1', '1442279192');
INSERT INTO `onethink_action_log` VALUES ('34', '8', '1', '2130706433', 'attribute', '49', '操作url：/wwwroot/admin.php?s=/Model/generate.html', '1', '1442279192');
INSERT INTO `onethink_action_log` VALUES ('35', '8', '1', '2130706433', 'attribute', '50', '操作url：/wwwroot/admin.php?s=/Model/generate.html', '1', '1442279192');
INSERT INTO `onethink_action_log` VALUES ('36', '8', '1', '2130706433', 'attribute', '51', '操作url：/wwwroot/admin.php?s=/Model/generate.html', '1', '1442279192');
INSERT INTO `onethink_action_log` VALUES ('37', '8', '1', '2130706433', 'attribute', '52', '操作url：/wwwroot/admin.php?s=/Model/generate.html', '1', '1442279192');
INSERT INTO `onethink_action_log` VALUES ('38', '8', '1', '2130706433', 'attribute', '53', '操作url：/wwwroot/admin.php?s=/Model/generate.html', '1', '1442279323');
INSERT INTO `onethink_action_log` VALUES ('39', '8', '1', '2130706433', 'attribute', '54', '操作url：/wwwroot/admin.php?s=/Model/generate.html', '1', '1442279323');
INSERT INTO `onethink_action_log` VALUES ('40', '8', '1', '2130706433', 'attribute', '55', '操作url：/wwwroot/admin.php?s=/Model/generate.html', '1', '1442279323');
INSERT INTO `onethink_action_log` VALUES ('41', '8', '1', '2130706433', 'attribute', '56', '操作url：/wwwroot/admin.php?s=/Model/generate.html', '1', '1442279323');
INSERT INTO `onethink_action_log` VALUES ('42', '8', '1', '2130706433', 'attribute', '57', '操作url：/wwwroot/admin.php?s=/Model/generate.html', '1', '1442279323');
INSERT INTO `onethink_action_log` VALUES ('43', '8', '1', '2130706433', 'attribute', '58', '操作url：/wwwroot/admin.php?s=/Model/generate.html', '1', '1442279323');
INSERT INTO `onethink_action_log` VALUES ('44', '8', '1', '2130706433', 'attribute', '59', '操作url：/wwwroot/admin.php?s=/Model/generate.html', '1', '1442279323');
INSERT INTO `onethink_action_log` VALUES ('45', '8', '1', '2130706433', 'attribute', '60', '操作url：/wwwroot/admin.php?s=/Model/generate.html', '1', '1442279323');
INSERT INTO `onethink_action_log` VALUES ('46', '8', '1', '2130706433', 'attribute', '61', '操作url：/wwwroot/admin.php?s=/Model/generate.html', '1', '1442279323');
INSERT INTO `onethink_action_log` VALUES ('47', '7', '1', '2130706433', 'model', '7', '操作url：/wwwroot/admin.php?s=/Model/update.html', '1', '1442279757');
INSERT INTO `onethink_action_log` VALUES ('48', '8', '1', '2130706433', 'attribute', '62', '操作url：/wwwroot/admin.php?s=/Model/generate.html', '1', '1442280074');
INSERT INTO `onethink_action_log` VALUES ('49', '8', '1', '2130706433', 'attribute', '63', '操作url：/wwwroot/admin.php?s=/Model/generate.html', '1', '1442280074');
INSERT INTO `onethink_action_log` VALUES ('50', '8', '1', '2130706433', 'attribute', '64', '操作url：/wwwroot/admin.php?s=/Model/generate.html', '1', '1442280074');
INSERT INTO `onethink_action_log` VALUES ('51', '8', '1', '2130706433', 'attribute', '65', '操作url：/wwwroot/admin.php?s=/Model/generate.html', '1', '1442280074');
INSERT INTO `onethink_action_log` VALUES ('52', '8', '1', '2130706433', 'attribute', '66', '操作url：/wwwroot/admin.php?s=/Model/generate.html', '1', '1442280074');
INSERT INTO `onethink_action_log` VALUES ('53', '8', '1', '2130706433', 'attribute', '67', '操作url：/wwwroot/admin.php?s=/Model/generate.html', '1', '1442280074');
INSERT INTO `onethink_action_log` VALUES ('54', '8', '1', '2130706433', 'attribute', '68', '操作url：/wwwroot/admin.php?s=/Model/generate.html', '1', '1442280074');
INSERT INTO `onethink_action_log` VALUES ('55', '8', '1', '2130706433', 'attribute', '69', '操作url：/wwwroot/admin.php?s=/Model/generate.html', '1', '1442280074');
INSERT INTO `onethink_action_log` VALUES ('56', '8', '1', '2130706433', 'attribute', '70', '操作url：/wwwroot/admin.php?s=/Model/generate.html', '1', '1442280074');
INSERT INTO `onethink_action_log` VALUES ('57', '7', '1', '2130706433', 'model', '8', '操作url：/wwwroot/admin.php?s=/Model/update.html', '1', '1442280125');
INSERT INTO `onethink_action_log` VALUES ('58', '7', '1', '2130706433', 'model', '8', '操作url：/wwwroot/admin.php?s=/Model/update.html', '1', '1442280349');
INSERT INTO `onethink_action_log` VALUES ('59', '7', '1', '2130706433', 'model', '8', '操作url：/wwwroot/admin.php?s=/Model/update.html', '1', '1442280394');
INSERT INTO `onethink_action_log` VALUES ('60', '11', '1', '2130706433', 'category', '1', '操作url：/wwwroot/admin.php?s=/Category/edit.html', '1', '1442280803');
INSERT INTO `onethink_action_log` VALUES ('61', '11', '1', '2130706433', 'category', '39', '操作url：/wwwroot/admin.php?s=/Category/edit.html', '1', '1442280827');
INSERT INTO `onethink_action_log` VALUES ('62', '11', '1', '2130706433', 'category', '1', '操作url：/wwwroot/admin.php?s=/Category/edit.html', '1', '1442280897');
INSERT INTO `onethink_action_log` VALUES ('63', '9', '1', '2130706433', 'channel', '6', '操作url：/wwwroot/admin.php?s=/Channel/edit.html', '1', '1442281129');
INSERT INTO `onethink_action_log` VALUES ('64', '9', '1', '2130706433', 'channel', '7', '操作url：/wwwroot/admin.php?s=/Channel/edit.html', '1', '1442281137');
INSERT INTO `onethink_action_log` VALUES ('65', '9', '1', '2130706433', 'channel', '8', '操作url：/wwwroot/admin.php?s=/Channel/edit.html', '1', '1442281174');
INSERT INTO `onethink_action_log` VALUES ('66', '1', '1', '2130706433', 'member', '1', 'admin在2015-09-16 08:05登录了后台', '1', '1442361940');
INSERT INTO `onethink_action_log` VALUES ('67', '1', '1', '2130706433', 'member', '1', 'admin在2015-09-16 13:41登录了后台', '1', '1442382069');
INSERT INTO `onethink_action_log` VALUES ('68', '1', '1', '2130706433', 'member', '1', 'admin在2015-09-18 09:03登录了后台', '1', '1442538208');
INSERT INTO `onethink_action_log` VALUES ('69', '1', '1', '2130706433', 'member', '1', 'admin在2015-09-20 12:26登录了后台', '1', '1442723181');
INSERT INTO `onethink_action_log` VALUES ('70', '1', '1', '2130706433', 'member', '1', 'admin在2015-09-21 19:07登录了后台', '1', '1442833656');
INSERT INTO `onethink_action_log` VALUES ('71', '1', '1', '2130706433', 'member', '1', 'admin在2015-10-03 11:09登录了后台', '1', '1443841775');
INSERT INTO `onethink_action_log` VALUES ('72', '1', '1', '2130706433', 'member', '1', 'admin在2015-10-07 14:34登录了后台', '1', '1444199699');
INSERT INTO `onethink_action_log` VALUES ('73', '1', '1', '2130706433', 'member', '1', 'admin在2015-10-07 14:38登录了后台', '1', '1444199892');
INSERT INTO `onethink_action_log` VALUES ('74', '1', '1', '2130706433', 'member', '1', 'admin在2015-10-07 14:48登录了后台', '1', '1444200481');
INSERT INTO `onethink_action_log` VALUES ('75', '1', '1', '2130706433', 'member', '1', 'admin在2015-10-07 15:54登录了后台', '1', '1444204474');
INSERT INTO `onethink_action_log` VALUES ('76', '1', '1', '2130706433', 'member', '1', 'admin在2015-10-07 16:16登录了后台', '1', '1444205817');
INSERT INTO `onethink_action_log` VALUES ('77', '1', '1', '2130706433', 'member', '1', 'admin在2015-10-07 16:18登录了后台', '1', '1444205914');
INSERT INTO `onethink_action_log` VALUES ('78', '1', '1', '2130706433', 'member', '1', 'admin在2015-10-07 16:21登录了后台', '1', '1444206096');
INSERT INTO `onethink_action_log` VALUES ('79', '1', '4', '2130706433', 'member', '4', 'cheng在2015-10-07 16:23登录了后台', '1', '1444206200');
INSERT INTO `onethink_action_log` VALUES ('80', '1', '4', '2130706433', 'member', '4', 'cheng在2015-10-07 16:26登录了后台', '1', '1444206368');
INSERT INTO `onethink_action_log` VALUES ('81', '1', '4', '2130706433', 'member', '4', 'cheng在2015-10-07 16:30登录了后台', '1', '1444206608');
INSERT INTO `onethink_action_log` VALUES ('82', '1', '1', '2130706433', 'member', '1', 'admin在2015-10-07 16:30登录了后台', '1', '1444206658');
INSERT INTO `onethink_action_log` VALUES ('83', '1', '5', '2130706433', 'member', '5', 'zz1234在2015-10-07 16:32登录了后台', '1', '1444206742');
INSERT INTO `onethink_action_log` VALUES ('84', '1', '5', '2130706433', 'member', '5', 'zz1234在2015-10-07 16:32登录了后台', '1', '1444206774');
INSERT INTO `onethink_action_log` VALUES ('85', '1', '1', '2130706433', 'member', '1', 'admin在2015-10-07 16:33登录了后台', '1', '1444206800');
INSERT INTO `onethink_action_log` VALUES ('86', '1', '1', '2130706433', 'member', '1', 'admin在2015-10-07 16:36登录了后台', '1', '1444206968');
INSERT INTO `onethink_action_log` VALUES ('87', '11', '1', '2130706433', 'category', '40', '操作url：/wwwroot/admin.php?s=/Category/add.html', '1', '1444207099');
INSERT INTO `onethink_action_log` VALUES ('88', '11', '1', '2130706433', 'category', '40', '操作url：/wwwroot/admin.php?s=/Category/edit.html', '1', '1444207165');
INSERT INTO `onethink_action_log` VALUES ('89', '11', '1', '2130706433', 'category', '40', '操作url：/wwwroot/admin.php?s=/Category/remove/id/40.html', '1', '1444207416');
INSERT INTO `onethink_action_log` VALUES ('90', '11', '1', '2130706433', 'category', '41', '操作url：/wwwroot/admin.php?s=/Category/add.html', '1', '1444207585');
INSERT INTO `onethink_action_log` VALUES ('91', '1', '1', '2130706433', 'member', '1', 'admin在2015-10-08 22:42登录了后台', '1', '1444315323');
INSERT INTO `onethink_action_log` VALUES ('92', '1', '1', '2130706433', 'member', '1', 'admin在2015-10-10 20:52登录了后台', '1', '1444481521');
INSERT INTO `onethink_action_log` VALUES ('93', '1', '1', '2130706433', 'member', '1', 'admin在2015-10-18 18:08登录了后台', '1', '1445162918');
INSERT INTO `onethink_action_log` VALUES ('94', '1', '1', '2130706433', 'member', '1', 'admin在2015-10-18 19:54登录了后台', '1', '1445169272');
INSERT INTO `onethink_action_log` VALUES ('95', '1', '1', '2130706433', 'member', '1', 'admin在2015-10-18 20:40登录了后台', '1', '1445172028');
INSERT INTO `onethink_action_log` VALUES ('96', '1', '1', '2130706433', 'member', '1', 'admin在2015-10-20 10:07登录了后台', '1', '1445306846');
INSERT INTO `onethink_action_log` VALUES ('97', '1', '6', '2130706433', 'member', '6', 'cctv在2015-10-20 10:48登录了后台', '1', '1445309296');
INSERT INTO `onethink_action_log` VALUES ('98', '1', '1', '2130706433', 'member', '1', 'admin在2015-10-20 11:23登录了后台', '1', '1445311420');
INSERT INTO `onethink_action_log` VALUES ('99', '1', '1', '2130706433', 'member', '1', 'admin在2015-10-20 12:46登录了后台', '1', '1445316369');
INSERT INTO `onethink_action_log` VALUES ('100', '1', '6', '2130706433', 'member', '6', 'cctv在2015-10-20 12:50登录了后台', '1', '1445316616');
INSERT INTO `onethink_action_log` VALUES ('101', '1', '6', '2130706433', 'member', '6', 'cctv在2015-10-20 20:24登录了后台', '1', '1445343897');
INSERT INTO `onethink_action_log` VALUES ('102', '1', '6', '2130706433', 'member', '6', 'cctv在2015-10-21 18:26登录了后台', '1', '1445423202');
INSERT INTO `onethink_action_log` VALUES ('103', '1', '1', '2130706433', 'member', '1', 'admin在2015-10-21 18:36登录了后台', '1', '1445423775');
INSERT INTO `onethink_action_log` VALUES ('104', '1', '6', '2130706433', 'member', '6', 'cctv在2015-10-21 19:09登录了后台', '1', '1445425743');
INSERT INTO `onethink_action_log` VALUES ('105', '1', '6', '2130706433', 'member', '6', 'cctv在2015-10-21 19:10登录了后台', '1', '1445425816');
INSERT INTO `onethink_action_log` VALUES ('106', '1', '6', '2130706433', 'member', '6', 'cctv在2015-10-21 19:24登录了后台', '1', '1445426691');
INSERT INTO `onethink_action_log` VALUES ('107', '1', '6', '2130706433', 'member', '6', 'cctv在2015-10-21 19:29登录了后台', '1', '1445426979');
INSERT INTO `onethink_action_log` VALUES ('108', '1', '6', '2130706433', 'member', '6', 'cctv在2015-10-21 19:31登录了后台', '1', '1445427090');
INSERT INTO `onethink_action_log` VALUES ('109', '1', '1', '0', 'member', '1', 'admin在2015-10-22 21:31登录了后台', '1', '1445520690');
INSERT INTO `onethink_action_log` VALUES ('110', '1', '1', '0', 'member', '1', 'admin在2015-10-23 12:11登录了后台', '1', '1445573486');
INSERT INTO `onethink_action_log` VALUES ('111', '1', '1', '0', 'member', '1', 'admin在2015-10-24 12:34登录了后台', '1', '1445661250');
INSERT INTO `onethink_action_log` VALUES ('112', '10', '1', '0', 'Menu', '124', '操作url：/wwwroot/admin.php?s=/Menu/add.html', '1', '1445662609');
INSERT INTO `onethink_action_log` VALUES ('113', '10', '1', '0', 'Menu', '124', '操作url：/wwwroot/admin.php?s=/Menu/edit.html', '1', '1445662640');
INSERT INTO `onethink_action_log` VALUES ('114', '10', '1', '0', 'Menu', '93', '操作url：/wwwroot/admin.php?s=/Menu/edit.html', '1', '1445662684');
INSERT INTO `onethink_action_log` VALUES ('115', '10', '1', '0', 'Menu', '124', '操作url：/wwwroot/admin.php?s=/Menu/edit.html', '1', '1445662702');
INSERT INTO `onethink_action_log` VALUES ('116', '10', '1', '0', 'Menu', '124', '操作url：/wwwroot/admin.php?s=/Menu/edit.html', '1', '1445662745');
INSERT INTO `onethink_action_log` VALUES ('117', '10', '1', '0', 'Menu', '93', '操作url：/wwwroot/admin.php?s=/Menu/edit.html', '1', '1445663389');
INSERT INTO `onethink_action_log` VALUES ('118', '10', '1', '0', 'Menu', '93', '操作url：/wwwroot/admin.php?s=/Menu/edit.html', '1', '1445663795');
INSERT INTO `onethink_action_log` VALUES ('119', '10', '1', '0', 'Menu', '1', '操作url：/wwwroot/admin.php?s=/Menu/edit.html', '1', '1445663863');
INSERT INTO `onethink_action_log` VALUES ('120', '10', '1', '0', 'Menu', '124', '操作url：/wwwroot/admin.php?s=/Menu/edit.html', '1', '1445664748');
INSERT INTO `onethink_action_log` VALUES ('121', '10', '1', '0', 'Menu', '93', '操作url：/wwwroot/admin.php?s=/Menu/edit.html', '1', '1445664764');
INSERT INTO `onethink_action_log` VALUES ('122', '10', '1', '0', 'Menu', '124', '操作url：/wwwroot/admin.php?s=/Menu/edit.html', '1', '1445665456');
INSERT INTO `onethink_action_log` VALUES ('123', '10', '1', '0', 'Menu', '124', '操作url：/wwwroot/admin.php?s=/Menu/edit.html', '1', '1445665464');
INSERT INTO `onethink_action_log` VALUES ('124', '6', '1', '0', 'config', '8', '操作url：/wwwroot/admin.php?s=/Advertisement/edit.html', '1', '1445673916');
INSERT INTO `onethink_action_log` VALUES ('125', '6', '1', '0', 'config', '8', '操作url：/wwwroot/admin.php?s=/Advertisement/edit.html', '1', '1445673934');
INSERT INTO `onethink_action_log` VALUES ('126', '1', '1', '0', 'member', '1', 'admin在2015-10-24 19:43登录了后台', '1', '1445687023');
INSERT INTO `onethink_action_log` VALUES ('127', '6', '1', '0', 'config', '4', '操作url：/wwwroot/admin.php?s=/Advertisement/edit.html', '1', '1445687743');
INSERT INTO `onethink_action_log` VALUES ('128', '6', '1', '0', 'config', '4', '操作url：/wwwroot/admin.php?s=/Advertisement/edit.html', '1', '1445687758');
INSERT INTO `onethink_action_log` VALUES ('129', '6', '1', '0', 'config', '5', '操作url：/wwwroot/admin.php?s=/Advertisement/edit.html', '1', '1445687893');
INSERT INTO `onethink_action_log` VALUES ('130', '6', '1', '0', 'config', '6', '操作url：/wwwroot/admin.php?s=/Advertisement/edit.html', '1', '1445688212');
INSERT INTO `onethink_action_log` VALUES ('131', '6', '1', '0', 'config', '8', '操作url：/wwwroot/admin.php?s=/Advertisement/edit.html', '1', '1445688638');
INSERT INTO `onethink_action_log` VALUES ('132', '6', '1', '0', 'config', '18', '操作url：/wwwroot/admin.php?s=/Advertisement/edit.html', '1', '1445688799');
INSERT INTO `onethink_action_log` VALUES ('133', '6', '1', '0', 'config', '18', '操作url：/wwwroot/admin.php?s=/Advertisement/edit.html', '1', '1445688806');
INSERT INTO `onethink_action_log` VALUES ('134', '6', '1', '0', 'config', '18', '操作url：/wwwroot/admin.php?s=/Advertisement/edit.html', '1', '1445688862');
INSERT INTO `onethink_action_log` VALUES ('135', '6', '1', '0', 'config', '18', '操作url：/wwwroot/admin.php?s=/Advertisement/edit.html', '1', '1445688886');
INSERT INTO `onethink_action_log` VALUES ('136', '6', '1', '0', 'config', '18', '操作url：/wwwroot/admin.php?s=/Advertisement/edit.html', '1', '1445688895');
INSERT INTO `onethink_action_log` VALUES ('137', '6', '1', '0', 'config', '18', '操作url：/wwwroot/admin.php?s=/Advertisement/edit.html', '1', '1445689033');
INSERT INTO `onethink_action_log` VALUES ('138', '6', '1', '0', 'config', '18', '操作url：/wwwroot/admin.php?s=/Advertisement/edit.html', '1', '1445689081');
INSERT INTO `onethink_action_log` VALUES ('139', '6', '1', '0', 'config', '17', '操作url：/wwwroot/admin.php?s=/Advertisement/edit.html', '1', '1445689091');
INSERT INTO `onethink_action_log` VALUES ('140', '6', '1', '0', 'config', '16', '操作url：/wwwroot/admin.php?s=/Advertisement/edit.html', '1', '1445689103');
INSERT INTO `onethink_action_log` VALUES ('141', '6', '1', '0', 'config', '15', '操作url：/wwwroot/admin.php?s=/Advertisement/edit.html', '1', '1445692227');
INSERT INTO `onethink_action_log` VALUES ('142', '6', '1', '0', 'BannerList', '0', '操作url：/wwwroot/admin.php?s=/Advertisement/del.html', '1', '1445693660');
INSERT INTO `onethink_action_log` VALUES ('143', '6', '1', '0', 'config', '19', '操作url：/wwwroot/admin.php?s=/Advertisement/edit.html', '1', '1445694434');
INSERT INTO `onethink_action_log` VALUES ('144', '10', '1', '0', 'Menu', '124', '操作url：/wwwroot/admin.php?s=/Menu/edit.html', '1', '1445738137');
INSERT INTO `onethink_action_log` VALUES ('145', '10', '1', '0', 'Menu', '124', '操作url：/wwwroot/admin.php?s=/Menu/edit.html', '1', '1445738221');
INSERT INTO `onethink_action_log` VALUES ('146', '10', '1', '0', 'Menu', '125', '操作url：/wwwroot/admin.php?s=/Menu/add.html', '1', '1445738304');
INSERT INTO `onethink_action_log` VALUES ('147', '10', '1', '0', 'Menu', '126', '操作url：/wwwroot/admin.php?s=/Menu/add.html', '1', '1445761068');
INSERT INTO `onethink_action_log` VALUES ('148', '6', '1', '0', 'ResourceTab', '0', '操作url：/wwwroot/admin.php?s=/Tab/del.html', '1', '1445765262');
INSERT INTO `onethink_action_log` VALUES ('149', '6', '1', '0', 'ResourceTab', '0', '操作url：/wwwroot/admin.php?s=/Tab/del/id/11.html', '1', '1445772200');
INSERT INTO `onethink_action_log` VALUES ('150', '6', '1', '0', 'ResourceTab', '0', '操作url：/wwwroot/admin.php?s=/Tab/del.html', '1', '1445775697');
INSERT INTO `onethink_action_log` VALUES ('151', '6', '1', '0', 'ResourceTab', '0', '操作url：/wwwroot/admin.php?s=/Tab/del/id/13.html', '1', '1445775886');
INSERT INTO `onethink_action_log` VALUES ('152', '10', '1', '0', 'Menu', '126', '操作url：/wwwroot/admin.php?s=/Menu/edit.html', '1', '1445776095');
INSERT INTO `onethink_action_log` VALUES ('153', '10', '1', '0', 'Menu', '127', '操作url：/wwwroot/admin.php?s=/Menu/add.html', '1', '1445786928');
INSERT INTO `onethink_action_log` VALUES ('154', '10', '1', '0', 'Menu', '127', '操作url：/wwwroot/admin.php?s=/Menu/edit.html', '1', '1445786953');
INSERT INTO `onethink_action_log` VALUES ('155', '1', '1', '0', 'member', '1', 'admin在2015-10-26 16:23登录了后台', '1', '1445847792');
INSERT INTO `onethink_action_log` VALUES ('156', '1', '1', '0', 'member', '1', 'admin在2015-10-27 08:38登录了后台', '1', '1445906301');
INSERT INTO `onethink_action_log` VALUES ('157', '1', '1', '0', 'member', '1', 'admin在2015-10-27 10:09登录了后台', '1', '1445911766');
INSERT INTO `onethink_action_log` VALUES ('158', '1', '1', '0', 'member', '1', 'admin在2015-10-27 12:31登录了后台', '1', '1445920261');
INSERT INTO `onethink_action_log` VALUES ('159', '1', '1', '0', 'member', '1', 'admin在2015-10-27 16:22登录了后台', '1', '1445934176');
INSERT INTO `onethink_action_log` VALUES ('160', '6', '1', '0', 'Resource', '1', '操作url：/wwwroot/admin.php?s=/Resource/edit.html', '1', '1445935726');
INSERT INTO `onethink_action_log` VALUES ('161', '6', '1', '0', 'Resource', '1', '操作url：/wwwroot/admin.php?s=/Resource/edit.html', '1', '1445935788');
INSERT INTO `onethink_action_log` VALUES ('162', '6', '1', '0', 'Resource', '1', '操作url：/wwwroot/admin.php?s=/Resource/edit.html', '1', '1445936254');
INSERT INTO `onethink_action_log` VALUES ('163', '6', '1', '0', 'Resource', '1', '操作url：/wwwroot/admin.php?s=/Resource/edit.html', '1', '1445939940');
INSERT INTO `onethink_action_log` VALUES ('164', '6', '1', '0', 'Resource', '1', '操作url：/wwwroot/admin.php?s=/Resource/edit.html', '1', '1445941026');
INSERT INTO `onethink_action_log` VALUES ('165', '6', '1', '0', 'Resource', '1', '操作url：/wwwroot/admin.php?s=/Resource/edit.html', '1', '1445941231');
INSERT INTO `onethink_action_log` VALUES ('166', '6', '1', '0', 'Resource', '0', '操作url：/wwwroot/admin.php?s=/Resource/del/id/28.html', '1', '1445941431');
INSERT INTO `onethink_action_log` VALUES ('167', '6', '1', '0', 'Resource', '0', '操作url：/wwwroot/admin.php?s=/Resource/del.html', '1', '1445941527');
INSERT INTO `onethink_action_log` VALUES ('168', '6', '1', '0', 'Resource', '0', '操作url：/wwwroot/admin.php?s=/Resource/del.html', '1', '1445941536');
INSERT INTO `onethink_action_log` VALUES ('169', '10', '1', '0', 'Menu', '128', '操作url：/wwwroot/admin.php?s=/Menu/add.html', '1', '1445949658');
INSERT INTO `onethink_action_log` VALUES ('170', '6', '1', '0', 'PersonnelData', '1', '操作url：/wwwroot/admin.php?s=/Personnel/edit.html', '1', '1445959249');
INSERT INTO `onethink_action_log` VALUES ('171', '6', '1', '0', 'PersonnelData', '2', '操作url：/wwwroot/admin.php?s=/Personnel/edit.html', '1', '1445959358');
INSERT INTO `onethink_action_log` VALUES ('172', '6', '1', '0', 'Resource', '0', '操作url：/wwwroot/admin.php?s=/Personnel/del/id/9.html', '1', '1445959741');
INSERT INTO `onethink_action_log` VALUES ('173', '6', '1', '0', 'PersonnelData', '0', '操作url：/wwwroot/admin.php?s=/Personnel/del.html', '1', '1445960344');
INSERT INTO `onethink_action_log` VALUES ('174', '6', '1', '0', 'PersonnelData', '0', '操作url：/wwwroot/admin.php?s=/Personnel/del/id/15.html', '1', '1445960350');
INSERT INTO `onethink_action_log` VALUES ('175', '6', '1', '0', 'PersonnelData', '0', '操作url：/wwwroot/admin.php?s=/Personnel/del/id/17.html', '1', '1445960419');
INSERT INTO `onethink_action_log` VALUES ('176', '1', '1', '0', 'member', '1', 'admin在2015-10-28 15:26登录了后台', '1', '1446017201');
INSERT INTO `onethink_action_log` VALUES ('177', '6', '1', '0', 'PersonnelData', '16', '操作url：/wwwroot/admin.php?s=/Personnel/edit.html', '1', '1446024050');
INSERT INTO `onethink_action_log` VALUES ('178', '6', '1', '0', 'PersonnelData', '17', '操作url：/wwwroot/admin.php?s=/Personnel/edit.html', '1', '1446024060');
INSERT INTO `onethink_action_log` VALUES ('179', '10', '1', '0', 'Menu', '129', '操作url：/wwwroot/admin.php?s=/Menu/add.html', '1', '1446046098');
INSERT INTO `onethink_action_log` VALUES ('180', '10', '1', '0', 'Menu', '130', '操作url：/wwwroot/admin.php?s=/Menu/add.html', '1', '1446046632');
INSERT INTO `onethink_action_log` VALUES ('181', '10', '1', '0', 'Menu', '131', '操作url：/wwwroot/admin.php?s=/Menu/add.html', '1', '1446046689');
INSERT INTO `onethink_action_log` VALUES ('182', '10', '1', '0', 'Menu', '130', '操作url：/wwwroot/admin.php?s=/Menu/edit.html', '1', '1446046873');
INSERT INTO `onethink_action_log` VALUES ('183', '10', '1', '0', 'Menu', '129', '操作url：/wwwroot/admin.php?s=/Menu/edit.html', '1', '1446046904');
INSERT INTO `onethink_action_log` VALUES ('184', '10', '1', '0', 'Menu', '131', '操作url：/wwwroot/admin.php?s=/Menu/edit.html', '1', '1446046924');
INSERT INTO `onethink_action_log` VALUES ('185', '10', '1', '0', 'Menu', '131', '操作url：/wwwroot/admin.php?s=/Menu/edit.html', '1', '1446046964');
INSERT INTO `onethink_action_log` VALUES ('186', '1', '1', '0', 'member', '1', 'admin在2015-10-29 09:11登录了后台', '1', '1446081109');
INSERT INTO `onethink_action_log` VALUES ('187', '1', '1', '0', 'member', '1', 'admin在2015-10-29 10:10登录了后台', '1', '1446084614');
INSERT INTO `onethink_action_log` VALUES ('188', '1', '1', '0', 'member', '1', 'admin在2015-10-29 12:23登录了后台', '1', '1446092583');
INSERT INTO `onethink_action_log` VALUES ('189', '1', '1', '0', 'member', '1', 'admin在2015-10-29 12:41登录了后台', '1', '1446093665');
INSERT INTO `onethink_action_log` VALUES ('190', '6', '1', '0', 'media_data', '3', '操作url：/wwwroot/admin.php?s=/Media/newsedit.html', '1', '1446112942');
INSERT INTO `onethink_action_log` VALUES ('191', '6', '1', '0', 'MediaData', '3', '操作url：/wwwroot/admin.php?s=/Media/newsedit.html', '1', '1446118739');
INSERT INTO `onethink_action_log` VALUES ('192', '6', '1', '0', 'MediaArticle', '3', '操作url：/wwwroot/admin.php?s=/Media/newsedit.html', '1', '1446118739');
INSERT INTO `onethink_action_log` VALUES ('193', '6', '1', '0', 'PersonnelData', '0', '操作url：/wwwroot/admin.php?s=/Media/del/type/1.html', '1', '1446122897');
INSERT INTO `onethink_action_log` VALUES ('194', '6', '1', '0', 'PersonnelData', '0', '操作url：/wwwroot/admin.php?s=/Media/del/type/1.html', '1', '1446122953');
INSERT INTO `onethink_action_log` VALUES ('195', '6', '1', '0', 'MediaData', '1', '操作url：/wwwroot/admin.php?s=/Media/newsedit/type/1.html', '1', '1446123552');
INSERT INTO `onethink_action_log` VALUES ('196', '6', '1', '0', 'MediaArticle', '1', '操作url：/wwwroot/admin.php?s=/Media/newsedit/type/1.html', '1', '1446123552');
INSERT INTO `onethink_action_log` VALUES ('197', '6', '1', '0', 'PersonnelData', '0', '操作url：/wwwroot/admin.php?s=/Media/del/type/1/id/60.html', '1', '1446123615');
INSERT INTO `onethink_action_log` VALUES ('198', '6', '1', '0', 'MediaData', '50', '操作url：/wwwroot/admin.php?s=/Media/teachingedit/type/1.html', '1', '1446126577');
INSERT INTO `onethink_action_log` VALUES ('199', '6', '1', '0', 'MediaArticle', '50', '操作url：/wwwroot/admin.php?s=/Media/teachingedit/type/1.html', '1', '1446126577');
INSERT INTO `onethink_action_log` VALUES ('200', '6', '1', '0', 'MediaData', '53', '操作url：/wwwroot/admin.php?s=/Media/teachingedit/type/1.html', '1', '1446126614');
INSERT INTO `onethink_action_log` VALUES ('201', '6', '1', '0', 'MediaArticle', '53', '操作url：/wwwroot/admin.php?s=/Media/teachingedit/type/1.html', '1', '1446126614');
INSERT INTO `onethink_action_log` VALUES ('202', '6', '1', '0', 'MediaData', '51', '操作url：/wwwroot/admin.php?s=/Media/teachingedit/type/1.html', '1', '1446126645');
INSERT INTO `onethink_action_log` VALUES ('203', '6', '1', '0', 'MediaArticle', '51', '操作url：/wwwroot/admin.php?s=/Media/teachingedit/type/1.html', '1', '1446126645');
INSERT INTO `onethink_action_log` VALUES ('204', '6', '1', '0', 'MediaData', '52', '操作url：/wwwroot/admin.php?s=/Media/teachingedit/type/1.html', '1', '1446126794');
INSERT INTO `onethink_action_log` VALUES ('205', '6', '1', '0', 'MediaArticle', '52', '操作url：/wwwroot/admin.php?s=/Media/teachingedit/type/1.html', '1', '1446126794');
INSERT INTO `onethink_action_log` VALUES ('206', '6', '1', '0', 'MediaData', '50', '操作url：/wwwroot/admin.php?s=/Media/teachingedit/type/1.html', '1', '1446127035');
INSERT INTO `onethink_action_log` VALUES ('207', '6', '1', '0', 'MediaArticle', '50', '操作url：/wwwroot/admin.php?s=/Media/teachingedit/type/1.html', '1', '1446127035');
INSERT INTO `onethink_action_log` VALUES ('208', '6', '1', '0', 'MediaData', '54', '操作url：/wwwroot/admin.php?s=/Media/teachingedit/type/1.html', '1', '1446127054');
INSERT INTO `onethink_action_log` VALUES ('209', '6', '1', '0', 'MediaArticle', '54', '操作url：/wwwroot/admin.php?s=/Media/teachingedit/type/1.html', '1', '1446127054');
INSERT INTO `onethink_action_log` VALUES ('210', '6', '1', '0', 'MediaData', '53', '操作url：/wwwroot/admin.php?s=/Media/teachingedit/type/1.html', '1', '1446127067');
INSERT INTO `onethink_action_log` VALUES ('211', '6', '1', '0', 'MediaArticle', '53', '操作url：/wwwroot/admin.php?s=/Media/teachingedit/type/1.html', '1', '1446127067');
INSERT INTO `onethink_action_log` VALUES ('212', '6', '1', '0', 'MediaData', '55', '操作url：/wwwroot/admin.php?s=/Media/teachingedit/type/1.html', '1', '1446127080');
INSERT INTO `onethink_action_log` VALUES ('213', '6', '1', '0', 'MediaArticle', '55', '操作url：/wwwroot/admin.php?s=/Media/teachingedit/type/1.html', '1', '1446127080');
INSERT INTO `onethink_action_log` VALUES ('214', '6', '1', '0', 'MediaData', '56', '操作url：/wwwroot/admin.php?s=/Media/teachingedit/type/1.html', '1', '1446127091');
INSERT INTO `onethink_action_log` VALUES ('215', '6', '1', '0', 'MediaArticle', '56', '操作url：/wwwroot/admin.php?s=/Media/teachingedit/type/1.html', '1', '1446127091');
INSERT INTO `onethink_action_log` VALUES ('216', '6', '1', '0', 'MediaData', '57', '操作url：/wwwroot/admin.php?s=/Media/teachingedit/type/1.html', '1', '1446127106');
INSERT INTO `onethink_action_log` VALUES ('217', '6', '1', '0', 'MediaArticle', '57', '操作url：/wwwroot/admin.php?s=/Media/teachingedit/type/1.html', '1', '1446127106');
INSERT INTO `onethink_action_log` VALUES ('218', '6', '1', '0', 'MediaData', '58', '操作url：/wwwroot/admin.php?s=/Media/teachingedit/type/1.html', '1', '1446127117');
INSERT INTO `onethink_action_log` VALUES ('219', '6', '1', '0', 'MediaArticle', '58', '操作url：/wwwroot/admin.php?s=/Media/teachingedit/type/1.html', '1', '1446127117');
INSERT INTO `onethink_action_log` VALUES ('220', '6', '1', '0', 'MediaData', '59', '操作url：/wwwroot/admin.php?s=/Media/teachingedit/type/1.html', '1', '1446127128');
INSERT INTO `onethink_action_log` VALUES ('221', '6', '1', '0', 'MediaArticle', '59', '操作url：/wwwroot/admin.php?s=/Media/teachingedit/type/1.html', '1', '1446127128');
INSERT INTO `onethink_action_log` VALUES ('222', '6', '1', '0', 'PersonnelData', '0', '操作url：/wwwroot/admin.php?s=/Media/del/type/2.html', '1', '1446127184');
INSERT INTO `onethink_action_log` VALUES ('223', '6', '1', '0', 'PersonnelData', '0', '操作url：/wwwroot/admin.php?s=/Media/del/type/2/id/68.html', '1', '1446127374');
INSERT INTO `onethink_action_log` VALUES ('224', '6', '1', '0', 'PersonnelData', '0', '操作url：/wwwroot/admin.php?s=/Media/del/type/2/id/69.html', '1', '1446127439');
INSERT INTO `onethink_action_log` VALUES ('225', '6', '1', '0', 'PersonnelData', '0', '操作url：/wwwroot/admin.php?s=/Media/del/type/3.html', '1', '1446128590');
INSERT INTO `onethink_action_log` VALUES ('226', '6', '1', '0', 'PersonnelData', '0', '操作url：/wwwroot/admin.php?s=/Media/del/type/3/id/72.html', '1', '1446128613');
INSERT INTO `onethink_action_log` VALUES ('227', '10', '1', '0', 'Menu', '132', '操作url：/wwwroot/admin.php?s=/Menu/add.html', '1', '1446129311');
INSERT INTO `onethink_action_log` VALUES ('228', '6', '1', '0', 'Friendlink', '5', '操作url：/wwwroot/admin.php?s=/Friendlink/edit.html', '1', '1446131351');
INSERT INTO `onethink_action_log` VALUES ('229', '6', '1', '0', 'Friendlink', '0', '操作url：/wwwroot/admin.php?s=/Friendlink/del.html', '1', '1446131425');
INSERT INTO `onethink_action_log` VALUES ('230', '6', '1', '0', 'Friendlink', '0', '操作url：/wwwroot/admin.php?s=/Friendlink/del/id/7.html', '1', '1446131442');
INSERT INTO `onethink_action_log` VALUES ('231', '1', '1', '0', 'member', '1', 'admin在2015-10-30 20:56登录了后台', '1', '1446209776');
INSERT INTO `onethink_action_log` VALUES ('232', '1', '1', '0', 'member', '1', 'admin在2015-10-30 21:06登录了后台', '1', '1446210399');
INSERT INTO `onethink_action_log` VALUES ('233', '1', '1', '0', 'member', '1', 'admin在2015-10-30 21:06登录了后台', '1', '1446210417');

-- -----------------------------
-- Table structure for `onethink_addons`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_addons`;
CREATE TABLE `onethink_addons` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(40) NOT NULL COMMENT '插件名或标识',
  `title` varchar(20) NOT NULL DEFAULT '' COMMENT '中文名',
  `description` text COMMENT '插件描述',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态',
  `config` text COMMENT '配置',
  `author` varchar(40) DEFAULT '' COMMENT '作者',
  `version` varchar(20) DEFAULT '' COMMENT '版本号',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '安装时间',
  `has_adminlist` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否有后台列表',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=utf8 COMMENT='插件表';

-- -----------------------------
-- Records of `onethink_addons`
-- -----------------------------
INSERT INTO `onethink_addons` VALUES ('15', 'EditorForAdmin', '后台编辑器', '用于增强整站长文本的输入和显示', '1', '{\"editor_type\":\"2\",\"editor_wysiwyg\":\"1\",\"editor_height\":\"500px\",\"editor_resize_type\":\"1\"}', 'thinkphp', '0.1', '1383126253', '0');
INSERT INTO `onethink_addons` VALUES ('2', 'SiteStat', '站点统计信息', '统计站点的基础信息', '1', '{\"title\":\"\\u7cfb\\u7edf\\u4fe1\\u606f\",\"width\":\"1\",\"display\":\"1\",\"status\":\"0\"}', 'thinkphp', '0.1', '1379512015', '0');
INSERT INTO `onethink_addons` VALUES ('16', 'ReturnTop', '返回顶部', '回到顶部美化，随机或指定显示，100款样式，每天一种换，天天都用新样式', '1', '{\"random\":\"0\",\"current\":\"79\"}', 'thinkphp', '0.1', '1445428865', '0');
INSERT INTO `onethink_addons` VALUES ('4', 'SystemInfo', '系统环境信息', '用于显示一些服务器的信息', '1', '{\"title\":\"\\u7cfb\\u7edf\\u4fe1\\u606f\",\"width\":\"2\",\"display\":\"1\"}', 'thinkphp', '0.1', '1379512036', '0');
INSERT INTO `onethink_addons` VALUES ('5', 'Editor', '前台编辑器', '用于增强整站长文本的输入和显示', '1', '{\"editor_type\":\"2\",\"editor_wysiwyg\":\"1\",\"editor_height\":\"300px\",\"editor_resize_type\":\"1\"}', 'thinkphp', '0.1', '1379830910', '0');
INSERT INTO `onethink_addons` VALUES ('6', 'Attachment', '附件', '用于文档模型上传附件', '1', 'null', 'thinkphp', '0.1', '1379842319', '1');
INSERT INTO `onethink_addons` VALUES ('9', 'SocialComment', '通用社交化评论', '集成了各种社交化评论插件，轻松集成到系统中。', '1', '{\"comment_type\":\"1\",\"comment_uid_youyan\":\"\",\"comment_short_name_duoshuo\":\"\",\"comment_data_list_duoshuo\":\"\"}', 'thinkphp', '0.1', '1380273962', '0');
INSERT INTO `onethink_addons` VALUES ('17', 'DevTeam', '开发团队信息', '开发团队成员信息', '1', '{\"title\":\"OneThink\\u5f00\\u53d1\\u56e2\\u961f\",\"width\":\"2\",\"display\":\"1\"}', 'thinkphp', '0.1', '1445429131', '0');
INSERT INTO `onethink_addons` VALUES ('18', 'Message', '留言板', '留言板插件', '1', '{\"reply\":\"1\",\"title\":\"1\",\"summary\":\"1\",\"username\":\"1\",\"phone\":\"0\",\"addr\":\"0\",\"email\":\"1\",\"qq\":\"0\",\"type\":\"0\"}', 'nzing', '0.1', '1445523325', '1');

-- -----------------------------
-- Table structure for `onethink_attachment`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_attachment`;
CREATE TABLE `onethink_attachment` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '用户ID',
  `title` char(30) NOT NULL DEFAULT '' COMMENT '附件显示名',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '附件类型',
  `source` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '资源ID',
  `record_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '关联记录ID',
  `download` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '下载次数',
  `size` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '附件大小',
  `dir` int(12) unsigned NOT NULL DEFAULT '0' COMMENT '上级目录ID',
  `sort` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`),
  KEY `idx_record_status` (`record_id`,`status`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='附件表';


-- -----------------------------
-- Table structure for `onethink_attribute`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_attribute`;
CREATE TABLE `onethink_attribute` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL DEFAULT '' COMMENT '字段名',
  `title` varchar(100) NOT NULL DEFAULT '' COMMENT '字段注释',
  `field` varchar(100) NOT NULL DEFAULT '' COMMENT '字段定义',
  `type` varchar(20) NOT NULL DEFAULT '' COMMENT '数据类型',
  `value` varchar(100) NOT NULL DEFAULT '' COMMENT '字段默认值',
  `remark` varchar(100) NOT NULL DEFAULT '' COMMENT '备注',
  `is_show` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '是否显示',
  `extra` varchar(255) NOT NULL DEFAULT '' COMMENT '参数',
  `model_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '模型id',
  `is_must` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否必填',
  `status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '状态',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `validate_rule` varchar(255) NOT NULL DEFAULT '',
  `validate_time` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `error_info` varchar(100) NOT NULL DEFAULT '',
  `validate_type` varchar(25) NOT NULL DEFAULT '',
  `auto_rule` varchar(100) NOT NULL DEFAULT '',
  `auto_time` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `auto_type` varchar(25) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `model_id` (`model_id`)
) ENGINE=MyISAM AUTO_INCREMENT=71 DEFAULT CHARSET=utf8 COMMENT='模型属性表';

-- -----------------------------
-- Records of `onethink_attribute`
-- -----------------------------
INSERT INTO `onethink_attribute` VALUES ('1', 'uid', '用户ID', 'int(10) unsigned NOT NULL ', 'num', '0', '', '0', '', '1', '0', '1', '1384508362', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('2', 'name', '标识', 'char(40) NOT NULL ', 'string', '', '同一根节点下标识不重复', '1', '', '1', '0', '1', '1383894743', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('3', 'title', '标题', 'char(80) NOT NULL ', 'string', '', '文档标题', '1', '', '1', '0', '1', '1383894778', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('4', 'category_id', '所属分类', 'int(10) unsigned NOT NULL ', 'string', '', '', '0', '', '1', '0', '1', '1384508336', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('5', 'description', '描述', 'char(140) NOT NULL ', 'textarea', '', '', '1', '', '1', '0', '1', '1383894927', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('6', 'root', '根节点', 'int(10) unsigned NOT NULL ', 'num', '0', '该文档的顶级文档编号', '0', '', '1', '0', '1', '1384508323', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('7', 'pid', '所属ID', 'int(10) unsigned NOT NULL ', 'num', '0', '父文档编号', '0', '', '1', '0', '1', '1384508543', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('8', 'model_id', '内容模型ID', 'tinyint(3) unsigned NOT NULL ', 'num', '0', '该文档所对应的模型', '0', '', '1', '0', '1', '1384508350', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('9', 'type', '内容类型', 'tinyint(3) unsigned NOT NULL ', 'select', '2', '', '1', '1:目录\r\n2:主题\r\n3:段落', '1', '0', '1', '1384511157', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('10', 'position', '推荐位', 'smallint(5) unsigned NOT NULL ', 'checkbox', '0', '多个推荐则将其推荐值相加', '1', '[DOCUMENT_POSITION]', '1', '0', '1', '1383895640', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('11', 'link_id', '外链', 'int(10) unsigned NOT NULL ', 'num', '0', '0-非外链，大于0-外链ID,需要函数进行链接与编号的转换', '1', '', '1', '0', '1', '1383895757', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('12', 'cover_id', '封面', 'int(10) unsigned NOT NULL ', 'picture', '0', '0-无封面，大于0-封面图片ID，需要函数处理', '1', '', '1', '0', '1', '1384147827', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('13', 'display', '可见性', 'tinyint(3) unsigned NOT NULL ', 'radio', '1', '', '1', '0:不可见\r\n1:所有人可见', '1', '0', '1', '1386662271', '1383891233', '', '0', '', 'regex', '', '0', 'function');
INSERT INTO `onethink_attribute` VALUES ('14', 'deadline', '截至时间', 'int(10) unsigned NOT NULL ', 'datetime', '0', '0-永久有效', '1', '', '1', '0', '1', '1387163248', '1383891233', '', '0', '', 'regex', '', '0', 'function');
INSERT INTO `onethink_attribute` VALUES ('15', 'attach', '附件数量', 'tinyint(3) unsigned NOT NULL ', 'num', '0', '', '0', '', '1', '0', '1', '1387260355', '1383891233', '', '0', '', 'regex', '', '0', 'function');
INSERT INTO `onethink_attribute` VALUES ('16', 'view', '浏览量', 'int(10) unsigned NOT NULL ', 'num', '0', '', '1', '', '1', '0', '1', '1383895835', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('17', 'comment', '评论数', 'int(10) unsigned NOT NULL ', 'num', '0', '', '1', '', '1', '0', '1', '1383895846', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('18', 'extend', '扩展统计字段', 'int(10) unsigned NOT NULL ', 'num', '0', '根据需求自行使用', '0', '', '1', '0', '1', '1384508264', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('19', 'level', '优先级', 'int(10) unsigned NOT NULL ', 'num', '0', '越高排序越靠前', '1', '', '1', '0', '1', '1383895894', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('20', 'create_time', '创建时间', 'int(10) unsigned NOT NULL ', 'datetime', '0', '', '1', '', '1', '0', '1', '1383895903', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('21', 'update_time', '更新时间', 'int(10) unsigned NOT NULL ', 'datetime', '0', '', '0', '', '1', '0', '1', '1384508277', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('22', 'status', '数据状态', 'tinyint(4) NOT NULL ', 'radio', '0', '', '0', '-1:删除\r\n0:禁用\r\n1:正常\r\n2:待审核\r\n3:草稿', '1', '0', '1', '1384508496', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('23', 'parse', '内容解析类型', 'tinyint(3) unsigned NOT NULL ', 'select', '0', '', '0', '0:html\r\n1:ubb\r\n2:markdown', '2', '0', '1', '1384511049', '1383891243', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('24', 'content', '文章内容', 'text NOT NULL ', 'editor', '', '', '1', '', '2', '0', '1', '1383896225', '1383891243', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('25', 'template', '详情页显示模板', 'varchar(100) NOT NULL ', 'string', '', '参照display方法参数的定义', '1', '', '2', '0', '1', '1383896190', '1383891243', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('26', 'bookmark', '收藏数', 'int(10) unsigned NOT NULL ', 'num', '0', '', '1', '', '2', '0', '1', '1383896103', '1383891243', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('27', 'parse', '内容解析类型', 'tinyint(3) unsigned NOT NULL ', 'select', '0', '', '0', '0:html\r\n1:ubb\r\n2:markdown', '3', '0', '1', '1387260461', '1383891252', '', '0', '', 'regex', '', '0', 'function');
INSERT INTO `onethink_attribute` VALUES ('28', 'content', '下载详细描述', 'text NOT NULL ', 'editor', '', '', '1', '', '3', '0', '1', '1383896438', '1383891252', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('29', 'template', '详情页显示模板', 'varchar(100) NOT NULL ', 'string', '', '', '1', '', '3', '0', '1', '1383896429', '1383891252', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('30', 'file_id', '文件ID', 'int(10) unsigned NOT NULL ', 'file', '0', '需要函数处理', '1', '', '3', '0', '1', '1383896415', '1383891252', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('31', 'download', '下载次数', 'int(10) unsigned NOT NULL ', 'num', '0', '', '1', '', '3', '0', '1', '1383896380', '1383891252', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('32', 'size', '文件大小', 'bigint(20) unsigned NOT NULL ', 'num', '0', '单位bit', '1', '', '3', '0', '1', '1383896371', '1383891252', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('70', 'sort', '排序', 'smallint(3) unsigned NOT NULL ', 'string', '0', '', '1', '', '8', '0', '1', '1442280074', '1442280074', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('68', 'update_time', '更新时间', 'int(10) unsigned NOT NULL ', 'string', '', '', '1', '', '8', '0', '1', '1442280074', '1442280074', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('69', 'status', '状态（-1：已删除，0：禁用，1：正常）', 'tinyint(4) NOT NULL ', 'string', '1', '', '1', '', '8', '0', '1', '1442280074', '1442280074', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('67', 'create_time', '创建时间', 'int(10) unsigned NOT NULL ', 'string', '', '', '1', '', '8', '0', '1', '1442280074', '1442280074', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('66', 'img', '图片链接地址', 'varchar(255) NOT NULL ', 'string', '', '', '1', '', '8', '0', '1', '1442280074', '1442280074', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('65', 'url', '链接地址', 'varchar(255) NOT NULL ', 'string', '', '', '1', '', '8', '0', '1', '1442280074', '1442280074', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('62', 'group', '分组类别', 'varchar(40) NULL ', 'string', '', '', '1', '', '8', '0', '1', '1442280074', '1442280074', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('63', 'type', '种类', 'varchar(40) NOT NULL ', 'string', '', '', '1', '', '8', '0', '1', '1442280074', '1442280074', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('64', 'title', '标题', 'varchar(80) NOT NULL ', 'string', '', '', '1', '', '8', '0', '1', '1442280074', '1442280074', '', '0', '', '', '', '0', '');

-- -----------------------------
-- Table structure for `onethink_auth_extend`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_auth_extend`;
CREATE TABLE `onethink_auth_extend` (
  `group_id` mediumint(10) unsigned NOT NULL COMMENT '用户id',
  `extend_id` mediumint(8) unsigned NOT NULL COMMENT '扩展表中数据的id',
  `type` tinyint(1) unsigned NOT NULL COMMENT '扩展类型标识 1:栏目分类权限;2:模型权限',
  UNIQUE KEY `group_extend_type` (`group_id`,`extend_id`,`type`),
  KEY `uid` (`group_id`),
  KEY `group_id` (`extend_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='用户组与分类的对应关系表';

-- -----------------------------
-- Records of `onethink_auth_extend`
-- -----------------------------
INSERT INTO `onethink_auth_extend` VALUES ('1', '1', '2');
INSERT INTO `onethink_auth_extend` VALUES ('1', '2', '2');
INSERT INTO `onethink_auth_extend` VALUES ('1', '3', '2');
INSERT INTO `onethink_auth_extend` VALUES ('2', '1', '1');
INSERT INTO `onethink_auth_extend` VALUES ('2', '2', '1');

-- -----------------------------
-- Table structure for `onethink_auth_group`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_auth_group`;
CREATE TABLE `onethink_auth_group` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户组id,自增主键',
  `module` varchar(20) NOT NULL DEFAULT '' COMMENT '用户组所属模块',
  `type` tinyint(4) NOT NULL DEFAULT '0' COMMENT '组类型',
  `title` char(20) NOT NULL DEFAULT '' COMMENT '用户组中文名称',
  `description` varchar(80) NOT NULL DEFAULT '' COMMENT '描述信息',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '用户组状态：为1正常，为0禁用,-1为删除',
  `rules` varchar(500) NOT NULL DEFAULT '' COMMENT '用户组拥有的规则id，多个规则 , 隔开',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `onethink_auth_group`
-- -----------------------------
INSERT INTO `onethink_auth_group` VALUES ('1', 'admin', '1', '普通用户组', '学生用户', '1', '2,7,8,9,10,11,12,13,14,15,16,18,79');
INSERT INTO `onethink_auth_group` VALUES ('2', 'admin', '1', '测试用户', '测试用户', '1', '1,2,5,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,79,80,82,83,84,88,89,90,91,92,93,96,97,100,102,103,195');
INSERT INTO `onethink_auth_group` VALUES ('3', 'admin', '1', '老师组', '这里是教师上传视频，管理视频的界面', '1', '');

-- -----------------------------
-- Table structure for `onethink_auth_group_access`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_auth_group_access`;
CREATE TABLE `onethink_auth_group_access` (
  `uid` int(10) unsigned NOT NULL COMMENT '用户id',
  `group_id` mediumint(8) unsigned NOT NULL COMMENT '用户组id',
  UNIQUE KEY `uid_group_id` (`uid`,`group_id`),
  KEY `uid` (`uid`),
  KEY `group_id` (`group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `onethink_auth_rule`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_auth_rule`;
CREATE TABLE `onethink_auth_rule` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '规则id,自增主键',
  `module` varchar(20) NOT NULL COMMENT '规则所属module',
  `type` tinyint(2) NOT NULL DEFAULT '1' COMMENT '1-url;2-主菜单',
  `name` char(80) NOT NULL DEFAULT '' COMMENT '规则唯一英文标识',
  `title` char(20) NOT NULL DEFAULT '' COMMENT '规则中文描述',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否有效(0:无效,1:有效)',
  `condition` varchar(300) NOT NULL DEFAULT '' COMMENT '规则附加条件',
  PRIMARY KEY (`id`),
  KEY `module` (`module`,`status`,`type`)
) ENGINE=MyISAM AUTO_INCREMENT=219 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `onethink_auth_rule`
-- -----------------------------
INSERT INTO `onethink_auth_rule` VALUES ('1', 'admin', '2', 'Admin/Index/index', '首页', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('2', 'admin', '2', 'Admin/Article/index', '内容', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('3', 'admin', '2', 'Admin/User/index', '用户', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('4', 'admin', '2', 'Admin/Addons/index', '扩展', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('5', 'admin', '2', 'Admin/Config/group', '系统', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('7', 'admin', '1', 'Admin/article/add', '新增', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('8', 'admin', '1', 'Admin/article/edit', '编辑', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('9', 'admin', '1', 'Admin/article/setStatus', '改变状态', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('10', 'admin', '1', 'Admin/article/update', '保存', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('11', 'admin', '1', 'Admin/article/autoSave', '保存草稿', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('12', 'admin', '1', 'Admin/article/move', '移动', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('13', 'admin', '1', 'Admin/article/copy', '复制', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('14', 'admin', '1', 'Admin/article/paste', '粘贴', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('15', 'admin', '1', 'Admin/article/permit', '还原', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('16', 'admin', '1', 'Admin/article/clear', '清空', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('17', 'admin', '1', 'Admin/Article/examine', '审核列表', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('18', 'admin', '1', 'Admin/article/recycle', '回收站', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('19', 'admin', '1', 'Admin/User/addaction', '新增用户行为', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('20', 'admin', '1', 'Admin/User/editaction', '编辑用户行为', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('21', 'admin', '1', 'Admin/User/saveAction', '保存用户行为', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('22', 'admin', '1', 'Admin/User/setStatus', '变更行为状态', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('23', 'admin', '1', 'Admin/User/changeStatus?method=forbidUser', '禁用会员', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('24', 'admin', '1', 'Admin/User/changeStatus?method=resumeUser', '启用会员', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('25', 'admin', '1', 'Admin/User/changeStatus?method=deleteUser', '删除会员', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('26', 'admin', '1', 'Admin/User/index', '用户信息', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('27', 'admin', '1', 'Admin/User/action', '用户行为', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('28', 'admin', '1', 'Admin/AuthManager/changeStatus?method=deleteGroup', '删除', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('29', 'admin', '1', 'Admin/AuthManager/changeStatus?method=forbidGroup', '禁用', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('30', 'admin', '1', 'Admin/AuthManager/changeStatus?method=resumeGroup', '恢复', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('31', 'admin', '1', 'Admin/AuthManager/createGroup', '新增', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('32', 'admin', '1', 'Admin/AuthManager/editGroup', '编辑', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('33', 'admin', '1', 'Admin/AuthManager/writeGroup', '保存用户组', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('34', 'admin', '1', 'Admin/AuthManager/group', '授权', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('35', 'admin', '1', 'Admin/AuthManager/access', '访问授权', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('36', 'admin', '1', 'Admin/AuthManager/user', '成员授权', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('37', 'admin', '1', 'Admin/AuthManager/removeFromGroup', '解除授权', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('38', 'admin', '1', 'Admin/AuthManager/addToGroup', '保存成员授权', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('39', 'admin', '1', 'Admin/AuthManager/category', '分类授权', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('40', 'admin', '1', 'Admin/AuthManager/addToCategory', '保存分类授权', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('41', 'admin', '1', 'Admin/AuthManager/index', '权限管理', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('42', 'admin', '1', 'Admin/Addons/create', '创建', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('43', 'admin', '1', 'Admin/Addons/checkForm', '检测创建', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('44', 'admin', '1', 'Admin/Addons/preview', '预览', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('45', 'admin', '1', 'Admin/Addons/build', '快速生成插件', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('46', 'admin', '1', 'Admin/Addons/config', '设置', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('47', 'admin', '1', 'Admin/Addons/disable', '禁用', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('48', 'admin', '1', 'Admin/Addons/enable', '启用', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('49', 'admin', '1', 'Admin/Addons/install', '安装', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('50', 'admin', '1', 'Admin/Addons/uninstall', '卸载', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('51', 'admin', '1', 'Admin/Addons/saveconfig', '更新配置', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('52', 'admin', '1', 'Admin/Addons/adminList', '插件后台列表', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('53', 'admin', '1', 'Admin/Addons/execute', 'URL方式访问插件', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('54', 'admin', '1', 'Admin/Addons/index', '插件管理', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('55', 'admin', '1', 'Admin/Addons/hooks', '钩子管理', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('56', 'admin', '1', 'Admin/model/add', '新增', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('57', 'admin', '1', 'Admin/model/edit', '编辑', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('58', 'admin', '1', 'Admin/model/setStatus', '改变状态', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('59', 'admin', '1', 'Admin/model/update', '保存数据', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('60', 'admin', '1', 'Admin/Model/index', '模型管理', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('61', 'admin', '1', 'Admin/Config/edit', '编辑', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('62', 'admin', '1', 'Admin/Config/del', '删除', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('63', 'admin', '1', 'Admin/Config/add', '新增', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('64', 'admin', '1', 'Admin/Config/save', '保存', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('65', 'admin', '1', 'Admin/Config/group', '网站设置', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('66', 'admin', '1', 'Admin/Config/index', '配置管理', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('67', 'admin', '1', 'Admin/Channel/add', '新增', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('68', 'admin', '1', 'Admin/Channel/edit', '编辑', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('69', 'admin', '1', 'Admin/Channel/del', '删除', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('70', 'admin', '1', 'Admin/Channel/index', '导航管理', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('71', 'admin', '1', 'Admin/Category/edit', '编辑', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('72', 'admin', '1', 'Admin/Category/add', '新增', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('73', 'admin', '1', 'Admin/Category/remove', '删除', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('74', 'admin', '1', 'Admin/Category/index', '分类管理', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('75', 'admin', '1', 'Admin/file/upload', '上传控件', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('76', 'admin', '1', 'Admin/file/uploadPicture', '上传图片', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('77', 'admin', '1', 'Admin/file/download', '下载', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('94', 'admin', '1', 'Admin/AuthManager/modelauth', '模型授权', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('79', 'admin', '1', 'Admin/article/batchOperate', '导入', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('80', 'admin', '1', 'Admin/Database/index?type=export', '备份数据库', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('81', 'admin', '1', 'Admin/Database/index?type=import', '还原数据库', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('82', 'admin', '1', 'Admin/Database/export', '备份', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('83', 'admin', '1', 'Admin/Database/optimize', '优化表', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('84', 'admin', '1', 'Admin/Database/repair', '修复表', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('86', 'admin', '1', 'Admin/Database/import', '恢复', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('87', 'admin', '1', 'Admin/Database/del', '删除', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('88', 'admin', '1', 'Admin/User/add', '新增用户', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('89', 'admin', '1', 'Admin/Attribute/index', '属性管理', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('90', 'admin', '1', 'Admin/Attribute/add', '新增', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('91', 'admin', '1', 'Admin/Attribute/edit', '编辑', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('92', 'admin', '1', 'Admin/Attribute/setStatus', '改变状态', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('93', 'admin', '1', 'Admin/Attribute/update', '保存数据', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('95', 'admin', '1', 'Admin/AuthManager/addToModel', '保存模型授权', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('96', 'admin', '1', 'Admin/Category/move', '移动', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('97', 'admin', '1', 'Admin/Category/merge', '合并', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('98', 'admin', '1', 'Admin/Config/menu', '后台菜单管理', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('99', 'admin', '1', 'Admin/Article/mydocument', '内容', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('100', 'admin', '1', 'Admin/Menu/index', '菜单管理', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('101', 'admin', '1', 'Admin/other', '其他', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('102', 'admin', '1', 'Admin/Menu/add', '新增', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('103', 'admin', '1', 'Admin/Menu/edit', '编辑', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('104', 'admin', '1', 'Admin/Think/lists?model=article', '文章管理', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('105', 'admin', '1', 'Admin/Think/lists?model=download', '下载管理', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('106', 'admin', '1', 'Admin/Think/lists?model=config', '配置管理', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('107', 'admin', '1', 'Admin/Action/actionlog', '行为日志', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('108', 'admin', '1', 'Admin/User/updatePassword', '修改密码', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('109', 'admin', '1', 'Admin/User/updateNickname', '修改昵称', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('110', 'admin', '1', 'Admin/action/edit', '查看行为日志', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('205', 'admin', '1', 'Admin/think/add', '新增数据', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('111', 'admin', '2', 'Admin/article/index', '文档列表', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('112', 'admin', '2', 'Admin/article/add', '新增', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('113', 'admin', '2', 'Admin/article/edit', '编辑', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('114', 'admin', '2', 'Admin/article/setStatus', '改变状态', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('115', 'admin', '2', 'Admin/article/update', '保存', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('116', 'admin', '2', 'Admin/article/autoSave', '保存草稿', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('117', 'admin', '2', 'Admin/article/move', '移动', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('118', 'admin', '2', 'Admin/article/copy', '复制', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('119', 'admin', '2', 'Admin/article/paste', '粘贴', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('120', 'admin', '2', 'Admin/article/batchOperate', '导入', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('121', 'admin', '2', 'Admin/article/recycle', '回收站', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('122', 'admin', '2', 'Admin/article/permit', '还原', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('123', 'admin', '2', 'Admin/article/clear', '清空', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('124', 'admin', '2', 'Admin/User/add', '新增用户', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('125', 'admin', '2', 'Admin/User/action', '用户行为', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('126', 'admin', '2', 'Admin/User/addAction', '新增用户行为', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('127', 'admin', '2', 'Admin/User/editAction', '编辑用户行为', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('128', 'admin', '2', 'Admin/User/saveAction', '保存用户行为', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('129', 'admin', '2', 'Admin/User/setStatus', '变更行为状态', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('130', 'admin', '2', 'Admin/User/changeStatus?method=forbidUser', '禁用会员', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('131', 'admin', '2', 'Admin/User/changeStatus?method=resumeUser', '启用会员', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('132', 'admin', '2', 'Admin/User/changeStatus?method=deleteUser', '删除会员', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('133', 'admin', '2', 'Admin/AuthManager/index', '权限管理', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('134', 'admin', '2', 'Admin/AuthManager/changeStatus?method=deleteGroup', '删除', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('135', 'admin', '2', 'Admin/AuthManager/changeStatus?method=forbidGroup', '禁用', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('136', 'admin', '2', 'Admin/AuthManager/changeStatus?method=resumeGroup', '恢复', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('137', 'admin', '2', 'Admin/AuthManager/createGroup', '新增', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('138', 'admin', '2', 'Admin/AuthManager/editGroup', '编辑', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('139', 'admin', '2', 'Admin/AuthManager/writeGroup', '保存用户组', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('140', 'admin', '2', 'Admin/AuthManager/group', '授权', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('141', 'admin', '2', 'Admin/AuthManager/access', '访问授权', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('142', 'admin', '2', 'Admin/AuthManager/user', '成员授权', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('143', 'admin', '2', 'Admin/AuthManager/removeFromGroup', '解除授权', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('144', 'admin', '2', 'Admin/AuthManager/addToGroup', '保存成员授权', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('145', 'admin', '2', 'Admin/AuthManager/category', '分类授权', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('146', 'admin', '2', 'Admin/AuthManager/addToCategory', '保存分类授权', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('147', 'admin', '2', 'Admin/AuthManager/modelauth', '模型授权', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('148', 'admin', '2', 'Admin/AuthManager/addToModel', '保存模型授权', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('149', 'admin', '2', 'Admin/Addons/create', '创建', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('150', 'admin', '2', 'Admin/Addons/checkForm', '检测创建', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('151', 'admin', '2', 'Admin/Addons/preview', '预览', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('152', 'admin', '2', 'Admin/Addons/build', '快速生成插件', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('153', 'admin', '2', 'Admin/Addons/config', '设置', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('154', 'admin', '2', 'Admin/Addons/disable', '禁用', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('155', 'admin', '2', 'Admin/Addons/enable', '启用', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('156', 'admin', '2', 'Admin/Addons/install', '安装', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('157', 'admin', '2', 'Admin/Addons/uninstall', '卸载', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('158', 'admin', '2', 'Admin/Addons/saveconfig', '更新配置', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('159', 'admin', '2', 'Admin/Addons/adminList', '插件后台列表', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('160', 'admin', '2', 'Admin/Addons/execute', 'URL方式访问插件', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('161', 'admin', '2', 'Admin/Addons/hooks', '钩子管理', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('162', 'admin', '2', 'Admin/Model/index', '模型管理', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('163', 'admin', '2', 'Admin/model/add', '新增', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('164', 'admin', '2', 'Admin/model/edit', '编辑', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('165', 'admin', '2', 'Admin/model/setStatus', '改变状态', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('166', 'admin', '2', 'Admin/model/update', '保存数据', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('167', 'admin', '2', 'Admin/Attribute/index', '属性管理', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('168', 'admin', '2', 'Admin/Attribute/add', '新增', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('169', 'admin', '2', 'Admin/Attribute/edit', '编辑', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('170', 'admin', '2', 'Admin/Attribute/setStatus', '改变状态', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('171', 'admin', '2', 'Admin/Attribute/update', '保存数据', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('172', 'admin', '2', 'Admin/Config/index', '配置管理', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('173', 'admin', '2', 'Admin/Config/edit', '编辑', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('174', 'admin', '2', 'Admin/Config/del', '删除', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('175', 'admin', '2', 'Admin/Config/add', '新增', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('176', 'admin', '2', 'Admin/Config/save', '保存', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('177', 'admin', '2', 'Admin/Menu/index', '菜单管理', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('178', 'admin', '2', 'Admin/Channel/index', '导航管理', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('179', 'admin', '2', 'Admin/Channel/add', '新增', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('180', 'admin', '2', 'Admin/Channel/edit', '编辑', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('181', 'admin', '2', 'Admin/Channel/del', '删除', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('182', 'admin', '2', 'Admin/Category/index', '分类管理', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('183', 'admin', '2', 'Admin/Category/edit', '编辑', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('184', 'admin', '2', 'Admin/Category/add', '新增', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('185', 'admin', '2', 'Admin/Category/remove', '删除', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('186', 'admin', '2', 'Admin/Category/move', '移动', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('187', 'admin', '2', 'Admin/Category/merge', '合并', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('188', 'admin', '2', 'Admin/Database/index?type=export', '备份数据库', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('189', 'admin', '2', 'Admin/Database/export', '备份', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('190', 'admin', '2', 'Admin/Database/optimize', '优化表', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('191', 'admin', '2', 'Admin/Database/repair', '修复表', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('192', 'admin', '2', 'Admin/Database/index?type=import', '还原数据库', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('193', 'admin', '2', 'Admin/Database/import', '恢复', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('194', 'admin', '2', 'Admin/Database/del', '删除', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('195', 'admin', '2', 'Admin/other', '其他', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('196', 'admin', '2', 'Admin/Menu/add', '新增', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('197', 'admin', '2', 'Admin/Menu/edit', '编辑', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('198', 'admin', '2', 'Admin/Think/lists?model=article', '应用', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('199', 'admin', '2', 'Admin/Think/lists?model=download', '下载管理', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('200', 'admin', '2', 'Admin/Think/lists?model=config', '应用', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('201', 'admin', '2', 'Admin/Action/actionlog', '行为日志', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('202', 'admin', '2', 'Admin/User/updatePassword', '修改密码', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('203', 'admin', '2', 'Admin/User/updateNickname', '修改昵称', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('204', 'admin', '2', 'Admin/action/edit', '查看行为日志', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('206', 'admin', '1', 'Admin/think/edit', '编辑数据', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('207', 'admin', '1', 'Admin/Menu/import', '导入', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('208', 'admin', '1', 'Admin/Model/generate', '生成', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('209', 'admin', '1', 'Admin/Addons/addHook', '新增钩子', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('210', 'admin', '1', 'Admin/Addons/edithook', '编辑钩子', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('211', 'admin', '1', 'Admin/Article/sort', '文档排序', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('212', 'admin', '1', 'Admin/Config/sort', '排序', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('213', 'admin', '1', 'Admin/Menu/sort', '排序', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('214', 'admin', '1', 'Admin/Channel/sort', '排序', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('215', 'admin', '1', 'Admin/Category/operate/type/move', '移动', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('216', 'admin', '1', 'Admin/Category/operate/type/merge', '合并', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('217', 'admin', '1', 'Admin/article/index', '文档列表', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('218', 'admin', '1', 'Admin/think/lists', '数据列表', '1', '');

-- -----------------------------
-- Table structure for `onethink_banner_list`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_banner_list`;
CREATE TABLE `onethink_banner_list` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '广告id',
  `group` varchar(20) COLLATE utf8_bin DEFAULT NULL COMMENT '分组类别',
  `type` tinyint(4) NOT NULL COMMENT '类型',
  `title` varchar(30) COLLATE utf8_bin NOT NULL COMMENT '标题<最多26个字符>',
  `url` varchar(255) COLLATE utf8_bin NOT NULL COMMENT '链接地址',
  `img` varchar(255) COLLATE utf8_bin NOT NULL COMMENT '图片链接地址',
  `create_time` int(10) unsigned NOT NULL COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL COMMENT '更新时间',
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '状态（-1：已删除，0：禁用，1：正常）',
  `sort` smallint(3) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- -----------------------------
-- Records of `onethink_banner_list`
-- -----------------------------
INSERT INTO `onethink_banner_list` VALUES ('4', '1', '1', '图片1', 'http://baidu.com', '5', '1442543813', '1445687758', '1', '0');
INSERT INTO `onethink_banner_list` VALUES ('5', '1', '1', '图片2', 'http://baidu.com', '6', '1442543813', '1445687893', '1', '0');
INSERT INTO `onethink_banner_list` VALUES ('6', '1', '1', '图片3', 'http://baidu.com', '7', '1442543813', '1445688212', '1', '0');
INSERT INTO `onethink_banner_list` VALUES ('7', '1', '5', '图片3', 'http://baidu.com', '5', '1442628522', '1442628522', '1', '0');
INSERT INTO `onethink_banner_list` VALUES ('8', '1', '5', 'zzzzzzz', 'http://baidu.com', '6', '1442628522', '1445688638', '1', '0');
INSERT INTO `onethink_banner_list` VALUES ('9', '1', '5', '图片5', 'http://baidu.com', '7', '1442628522', '1442628522', '1', '0');
INSERT INTO `onethink_banner_list` VALUES ('10', '1', '6', '图片1', 'http://baidu.com', '5', '1442639498', '1442639498', '1', '0');
INSERT INTO `onethink_banner_list` VALUES ('11', '1', '6', '图片2', 'http://baidu.com', '6', '1442639498', '1442639498', '1', '0');
INSERT INTO `onethink_banner_list` VALUES ('12', '1', '6', '图片3', 'http://baidu.com', '7', '1442639498', '1442639498', '1', '0');
INSERT INTO `onethink_banner_list` VALUES ('13', '1', '7', '图片1', 'http://baidu.com', '5', '1442639868', '1442639868', '1', '0');
INSERT INTO `onethink_banner_list` VALUES ('14', '1', '7', '图片2', 'http://baidu.com', '6', '1442639868', '1442639868', '1', '0');
INSERT INTO `onethink_banner_list` VALUES ('15', '1', '7', '图片3', 'http://baidu.com', '7', '1442639868', '1445692227', '1', '0');
INSERT INTO `onethink_banner_list` VALUES ('16', '1', '2', '图片1', 'http://baidu.com', '8', '1442651646', '1445689103', '1', '0');
INSERT INTO `onethink_banner_list` VALUES ('17', '1', '3', '图片1', 'http://baidu.com', '8', '1442652096', '1445689091', '1', '0');
INSERT INTO `onethink_banner_list` VALUES ('19', '', '4', '图片2', 'baidu.com', '8', '0', '1445694434', '1', '0');

-- -----------------------------
-- Table structure for `onethink_category`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_category`;
CREATE TABLE `onethink_category` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '分类ID',
  `name` varchar(30) NOT NULL COMMENT '标志',
  `title` varchar(50) NOT NULL COMMENT '标题',
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `sort` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '排序（同级有效）',
  `list_row` tinyint(3) unsigned NOT NULL DEFAULT '10' COMMENT '列表每页行数',
  `meta_title` varchar(50) NOT NULL DEFAULT '' COMMENT 'SEO的网页标题',
  `keywords` varchar(255) NOT NULL DEFAULT '' COMMENT '关键字',
  `description` varchar(255) NOT NULL DEFAULT '' COMMENT '描述',
  `template_index` varchar(100) NOT NULL DEFAULT '' COMMENT '频道页模板',
  `template_lists` varchar(100) NOT NULL DEFAULT '' COMMENT '列表页模板',
  `template_detail` varchar(100) NOT NULL DEFAULT '' COMMENT '详情页模板',
  `template_edit` varchar(100) NOT NULL DEFAULT '' COMMENT '编辑页模板',
  `model` varchar(100) NOT NULL DEFAULT '' COMMENT '列表绑定模型',
  `model_sub` varchar(100) NOT NULL DEFAULT '' COMMENT '子文档绑定模型',
  `type` varchar(100) NOT NULL DEFAULT '' COMMENT '允许发布的内容类型',
  `link_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '外链',
  `allow_publish` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '是否允许发布内容',
  `display` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '可见性',
  `reply` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '是否允许回复',
  `check` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '发布的文章是否需要审核',
  `reply_model` varchar(100) NOT NULL DEFAULT '',
  `extend` text COMMENT '扩展设置',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '数据状态',
  `icon` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '分类图标',
  `groups` varchar(255) NOT NULL DEFAULT '' COMMENT '分组定义',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_name` (`name`),
  KEY `pid` (`pid`)
) ENGINE=MyISAM AUTO_INCREMENT=42 DEFAULT CHARSET=utf8 COMMENT='分类表';

-- -----------------------------
-- Records of `onethink_category`
-- -----------------------------
INSERT INTO `onethink_category` VALUES ('1', 'blog', '文档', '1', '0', '10', '', '', '', '', '', '', '', '2,3', '2', '2,1', '0', '0', '1', '0', '0', '1', '', '1379474947', '1442280897', '1', '2', '');
INSERT INTO `onethink_category` VALUES ('2', 'default_blog', '默认分类', '1', '1', '10', '', '', '', '', '', '', '', '2,3', '2', '2,1,3', '0', '1', '1', '0', '1', '1', '', '1379475028', '1386839751', '1', '0', '');
INSERT INTO `onethink_category` VALUES ('39', 'sz', '课程', '1', '0', '10', '', '', '', '', '', '', '', '2', '2', '2', '0', '1', '1', '0', '0', '', '', '1440940433', '1442280827', '1', '0', '123456');
INSERT INTO `onethink_category` VALUES ('41', 'jx', '教学', '0', '0', '10', '', '', '', '', '', '', '', '2,3', '2,3', '2,1,3', '0', '1', '1', '0', '0', '', '', '1444207585', '1444207585', '1', '0', '里面包含教学类的文章');

-- -----------------------------
-- Table structure for `onethink_channel`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_channel`;
CREATE TABLE `onethink_channel` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '频道ID',
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '上级频道ID',
  `title` char(30) NOT NULL COMMENT '频道标题',
  `url` char(100) NOT NULL COMMENT '频道连接',
  `sort` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '导航排序',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '状态',
  `target` tinyint(2) unsigned NOT NULL DEFAULT '0' COMMENT '新窗口打开',
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `onethink_channel`
-- -----------------------------
INSERT INTO `onethink_channel` VALUES ('1', '0', '首页', 'Index/index', '1', '1379475111', '1379923177', '1', '0');
INSERT INTO `onethink_channel` VALUES ('2', '0', '名师讲堂', 'Auditorium/index', '2', '1379475131', '1441287166', '1', '0');
INSERT INTO `onethink_channel` VALUES ('3', '0', '教育教学', 'Education/index', '3', '1379475154', '1441287231', '1', '0');
INSERT INTO `onethink_channel` VALUES ('4', '0', '教学资源', 'Resources/index', '4', '1441287282', '1441287292', '1', '0');
INSERT INTO `onethink_channel` VALUES ('5', '0', '前沿专题', 'Information/index', '5', '1441287336', '1441287336', '1', '0');
INSERT INTO `onethink_channel` VALUES ('6', '0', '主题活动', 'Activity/index', '7', '1441287387', '1442281129', '1', '0');
INSERT INTO `onethink_channel` VALUES ('7', '0', '学生作品', 'Display/index', '8', '1441287428', '1442281137', '1', '0');
INSERT INTO `onethink_channel` VALUES ('8', '0', '新闻资讯', 'News/index', '6', '1442281118', '1442281174', '1', '0');

-- -----------------------------
-- Table structure for `onethink_config`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_config`;
CREATE TABLE `onethink_config` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '配置ID',
  `name` varchar(30) NOT NULL DEFAULT '' COMMENT '配置名称',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '配置类型',
  `title` varchar(50) NOT NULL DEFAULT '' COMMENT '配置说明',
  `group` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '配置分组',
  `extra` varchar(255) NOT NULL DEFAULT '' COMMENT '配置值',
  `remark` varchar(100) NOT NULL DEFAULT '' COMMENT '配置说明',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '状态',
  `value` text COMMENT '配置值',
  `sort` smallint(3) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_name` (`name`),
  KEY `type` (`type`),
  KEY `group` (`group`)
) ENGINE=MyISAM AUTO_INCREMENT=49 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `onethink_config`
-- -----------------------------
INSERT INTO `onethink_config` VALUES ('1', 'WEB_SITE_TITLE', '1', '网站标题', '1', '', '网站标题前台显示标题', '1378898976', '1379235274', '1', '高职院校思想政治实践教学平台', '1');
INSERT INTO `onethink_config` VALUES ('2', 'WEB_SITE_DESCRIPTION', '2', '网站描述', '1', '', '网站搜索引擎描述', '1378898976', '1379235841', '1', '高职院校思想政治实践教学平台', '5');
INSERT INTO `onethink_config` VALUES ('3', 'WEB_SITE_KEYWORD', '2', '网站关键字', '1', '', '网站搜索引擎关键字，必须逗号隔开', '1378898976', '1381390100', '1', '思想政治 ，教学平台，高职思想政治，高职政治', '6');
INSERT INTO `onethink_config` VALUES ('4', 'WEB_SITE_CLOSE', '4', '关闭站点', '1', '0:关闭,1:开启', '站点关闭后其他用户不能访问，管理员可以正常访问', '1378898976', '1379235296', '1', '1', '20');
INSERT INTO `onethink_config` VALUES ('9', 'CONFIG_TYPE_LIST', '3', '配置类型列表', '4', '', '主要用于数据解析和页面表单的生成', '1378898976', '1379235348', '1', '0:数字\r\n1:字符\r\n2:文本\r\n3:数组\r\n4:枚举', '2');
INSERT INTO `onethink_config` VALUES ('10', 'WEB_SITE_ICP', '1', '网站备案号', '1', '', '设置在网站底部显示的备案号，如“沪ICP备12007941号-2', '1378900335', '1379235859', '1', '沪ICP备12007941号-2', '3');
INSERT INTO `onethink_config` VALUES ('11', 'DOCUMENT_POSITION', '3', '文档推荐位', '2', '', '文档推荐位，推荐到多个位置KEY值相加即可', '1379053380', '1379235329', '1', '1:列表推荐\r\n2:频道推荐\r\n4:首页推荐', '3');
INSERT INTO `onethink_config` VALUES ('12', 'DOCUMENT_DISPLAY', '3', '文档可见性', '2', '', '文章可见性仅影响前台显示，后台不收影响', '1379056370', '1379235322', '1', '0:所有人可见\r\n1:仅注册会员可见\r\n2:仅管理员可见', '4');
INSERT INTO `onethink_config` VALUES ('13', 'COLOR_STYLE', '4', '后台色系', '1', 'default_color:默认\r\nblue_color:紫罗兰', '后台颜色风格', '1379122533', '1379235904', '1', 'default_color', '20');
INSERT INTO `onethink_config` VALUES ('20', 'CONFIG_GROUP_LIST', '3', '配置分组', '4', '', '配置分组', '1379228036', '1384418383', '1', '1:基本\r\n3:用户\r\n4:系统', '4');
INSERT INTO `onethink_config` VALUES ('21', 'HOOKS_TYPE', '3', '钩子的类型', '4', '', '类型 1-用于扩展显示内容，2-用于扩展业务处理', '1379313397', '1379313407', '1', '1:视图\r\n2:控制器', '6');
INSERT INTO `onethink_config` VALUES ('22', 'AUTH_CONFIG', '3', 'Auth配置', '4', '', '自定义Auth.class.php类配置', '1379409310', '1379409564', '1', 'AUTH_ON:1\r\nAUTH_TYPE:2', '8');
INSERT INTO `onethink_config` VALUES ('23', 'OPEN_DRAFTBOX', '4', '是否开启草稿功能', '2', '0:关闭草稿功能\r\n1:开启草稿功能\r\n', '新增文章时的草稿功能配置', '1379484332', '1379484591', '1', '1', '1');
INSERT INTO `onethink_config` VALUES ('24', 'DRAFT_AOTOSAVE_INTERVAL', '0', '自动保存草稿时间', '2', '', '自动保存草稿的时间间隔，单位：秒', '1379484574', '1386143323', '1', '60', '2');
INSERT INTO `onethink_config` VALUES ('25', 'LIST_ROWS', '0', '后台每页记录数', '2', '', '后台数据每页显示记录数', '1379503896', '1380427745', '1', '10', '10');
INSERT INTO `onethink_config` VALUES ('26', 'USER_ALLOW_REGISTER', '4', '是否允许用户注册', '3', '0:关闭注册\r\n1:允许注册', '是否开放用户注册', '1379504487', '1379504580', '1', '1', '3');
INSERT INTO `onethink_config` VALUES ('27', 'CODEMIRROR_THEME', '4', '预览插件的CodeMirror主题', '4', '3024-day:3024 day\r\n3024-night:3024 night\r\nambiance:ambiance\r\nbase16-dark:base16 dark\r\nbase16-light:base16 light\r\nblackboard:blackboard\r\ncobalt:cobalt\r\neclipse:eclipse\r\nelegant:elegant\r\nerlang-dark:erlang-dark\r\nlesser-dark:lesser-dark\r\nmidnight:midnight', '详情见CodeMirror官网', '1379814385', '1384740813', '1', 'ambiance', '3');
INSERT INTO `onethink_config` VALUES ('28', 'DATA_BACKUP_PATH', '1', '数据库备份根路径', '4', '', '路径必须以 / 结尾', '1381482411', '1381482411', '1', './Data/', '5');
INSERT INTO `onethink_config` VALUES ('29', 'DATA_BACKUP_PART_SIZE', '0', '数据库备份卷大小', '4', '', '该值用于限制压缩后的分卷最大长度。单位：B；建议设置20M', '1381482488', '1381729564', '1', '20971520', '7');
INSERT INTO `onethink_config` VALUES ('30', 'DATA_BACKUP_COMPRESS', '4', '数据库备份文件是否启用压缩', '4', '0:不压缩\r\n1:启用压缩', '压缩备份文件需要PHP环境支持gzopen,gzwrite函数', '1381713345', '1381729544', '1', '1', '9');
INSERT INTO `onethink_config` VALUES ('31', 'DATA_BACKUP_COMPRESS_LEVEL', '4', '数据库备份文件压缩级别', '4', '1:普通\r\n4:一般\r\n9:最高', '数据库备份文件的压缩级别，该配置在开启压缩时生效', '1381713408', '1381713408', '1', '9', '10');
INSERT INTO `onethink_config` VALUES ('32', 'DEVELOP_MODE', '4', '开启开发者模式', '4', '0:关闭\r\n1:开启', '是否开启开发者模式', '1383105995', '1383291877', '1', '1', '11');
INSERT INTO `onethink_config` VALUES ('33', 'ALLOW_VISIT', '3', '不受限控制器方法', '0', '', '', '1386644047', '1386644741', '1', '0:article/draftbox\r\n1:article/mydocument\r\n2:Category/tree\r\n3:Index/verify\r\n4:file/upload\r\n5:file/download\r\n6:user/updatePassword\r\n7:user/updateNickname\r\n8:user/submitPassword\r\n9:user/submitNickname\r\n10:file/uploadpicture', '0');
INSERT INTO `onethink_config` VALUES ('34', 'DENY_VISIT', '3', '超管专限控制器方法', '0', '', '仅超级管理员可访问的控制器方法', '1386644141', '1386644659', '1', '0:Addons/addhook\r\n1:Addons/edithook\r\n2:Addons/delhook\r\n3:Addons/updateHook\r\n4:Admin/getMenus\r\n5:Admin/recordList\r\n6:AuthManager/updateRules\r\n7:AuthManager/tree', '1');
INSERT INTO `onethink_config` VALUES ('35', 'REPLY_LIST_ROWS', '0', '回复列表每页条数', '2', '', '', '1386645376', '1387178083', '1', '10', '0');
INSERT INTO `onethink_config` VALUES ('36', 'ADMIN_ALLOW_IP', '2', '后台允许访问IP', '4', '', '多个用逗号分隔，如果不配置表示不限制IP访问', '1387165454', '1387165553', '1', '', '12');
INSERT INTO `onethink_config` VALUES ('37', 'SHOW_PAGE_TRACE', '4', '是否显示页面Trace', '4', '0:关闭\r\n1:开启', '是否显示页面Trace信息', '1387165685', '1387165685', '1', '1', '1');
INSERT INTO `onethink_config` VALUES ('38', 'NETWORK_TEACHING_PLATFORM', '2', '网络教学综合平台', '1', '', '网络教学综合平台简介', '1378898976', '1379235274', '1', '为全面落实省教育厅、财政厅《关于实施广东省高等学校教学质量与教学改革工程的意见》精神，加快我校优质教学资源的共建共享，利用互联网技术实现课程、教学资源数字化，促进师生互动交流；利用教学信息化支撑我校人才培养模式改革与创新，推动我校新一轮教学改革与质量工程建设，学校于2015年9月开发了网络教学综合平台', '13');
INSERT INTO `onethink_config` VALUES ('39', 'CONTACT_WORD_PESS', '1', '答疑博客', '1', '', '用于回答用户疑问的博客', '1379409310', '1379409564', '1', 'cheng1483@163.com', '10');
INSERT INTO `onethink_config` VALUES ('40', 'CONTACT_EMAIL', '1', '电子邮箱', '1', '', '联系网站的Email', '1442196450', '1442196450', '1', 'cheng1483@163.com', '7');
INSERT INTO `onethink_config` VALUES ('41', 'CONTACT_ADDRESS', '1', '学校地址', '1', '', '网站所有者地址', '1442197384', '1442197384', '1', '天津电子信息职业技术学院', '12');
INSERT INTO `onethink_config` VALUES ('42', 'WEB_COPYRIGHT', '1', '版权所有', '1', '', '这里设置版权', '1442197384', '1442197384', '1', '天津电子XXXXXXXX所有', '4');
INSERT INTO `onethink_config` VALUES ('43', 'CONTACT_ZIP_CODE', '1', '邮编', '1', '', '所在地邮编', '1442197971', '1442197971', '1', '300350', '11');
INSERT INTO `onethink_config` VALUES ('44', 'WEB_ADMINISTRATOR_EMAIL', '1', '管理员邮箱', '1', '', '网站管理员的Email', '1442197971', '1442197971', '1', 'cheng1483@163.com', '9');
INSERT INTO `onethink_config` VALUES ('45', 'CONTACT_PHONE', '1', '电话', '1', '联系方式 ', '联系网站的电话', '1442198186', '1442198186', '1', '13920826591', '8');
INSERT INTO `onethink_config` VALUES ('47', 'WEB_ADDRESS', '1', '网站URL地址', '1', '请输入url格式数据', '能够访问到本网站的域名', '1387165685', '1387165685', '1', 'www.gaoxiao.com', '2');
INSERT INTO `onethink_config` VALUES ('48', '', '0', '123456', '0', '', '', '1445669796', '1445669796', '1', '', '0');

-- -----------------------------
-- Table structure for `onethink_document`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_document`;
CREATE TABLE `onethink_document` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '文档ID',
  `uid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '用户ID',
  `name` char(40) NOT NULL DEFAULT '' COMMENT '标识',
  `title` char(80) NOT NULL DEFAULT '' COMMENT '标题',
  `category_id` int(10) unsigned NOT NULL COMMENT '所属分类',
  `group_id` smallint(3) unsigned NOT NULL COMMENT '所属分组',
  `description` char(140) NOT NULL DEFAULT '' COMMENT '描述',
  `root` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '根节点',
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '所属ID',
  `model_id` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '内容模型ID',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '2' COMMENT '内容类型',
  `position` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '推荐位',
  `link_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '外链',
  `cover_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '封面',
  `display` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '可见性',
  `deadline` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '截至时间',
  `attach` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '附件数量',
  `view` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '浏览量',
  `comment` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '评论数',
  `extend` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '扩展统计字段',
  `level` int(10) NOT NULL DEFAULT '0' COMMENT '优先级',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '数据状态',
  PRIMARY KEY (`id`),
  KEY `idx_category_status` (`category_id`,`status`),
  KEY `idx_status_type_pid` (`status`,`uid`,`pid`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='文档模型基础表';

-- -----------------------------
-- Records of `onethink_document`
-- -----------------------------
INSERT INTO `onethink_document` VALUES ('1', '1', '', 'OneThink1.1开发版发布', '2', '0', '期待已久的OneThink最新版发布', '0', '0', '2', '2', '0', '0', '1', '1', '0', '0', '15', '0', '0', '0', '1406001360', '1440947961', '1');

-- -----------------------------
-- Table structure for `onethink_document_article`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_document_article`;
CREATE TABLE `onethink_document_article` (
  `id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文档ID',
  `parse` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '内容解析类型',
  `content` text NOT NULL COMMENT '文章内容',
  `template` varchar(100) NOT NULL DEFAULT '' COMMENT '详情页显示模板',
  `bookmark` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '收藏数',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='文档模型文章表';

-- -----------------------------
-- Records of `onethink_document_article`
-- -----------------------------
INSERT INTO `onethink_document_article` VALUES ('1', '0', '<h1>\n	OneThink1.1开发版发布&nbsp;\n</h1>\n<p>\n	<br />\n</p>\n<p>\n	<strong>OneThink是一个开源的内容管理框架，基于最新的ThinkPHP3.2版本开发，提供更方便、更安全的WEB应用开发体验，采用了全新的架构设计和命名空间机制，融合了模块化、驱动化和插件化的设计理念于一体，开启了国内WEB应用傻瓜式开发的新潮流。&nbsp;</strong> \n</p>\n<h2>\n	主要特性：\n</h2>\n<p>\n	1. 基于ThinkPHP最新3.2版本。\n</p>\n<p>\n	2. 模块化：全新的架构和模块化的开发机制，便于灵活扩展和二次开发。&nbsp;\n</p>\n<p>\n	3. 文档模型/分类体系：通过和文档模型绑定，以及不同的文档类型，不同分类可以实现差异化的功能，轻松实现诸如资讯、下载、讨论和图片等功能。\n</p>\n<p>\n	4. 开源免费：OneThink遵循Apache2开源协议,免费提供使用。&nbsp;\n</p>\n<p>\n	5. 用户行为：支持自定义用户行为，可以对单个用户或者群体用户的行为进行记录及分享，为您的运营决策提供有效参考数据。\n</p>\n<p>\n	6. 云端部署：通过驱动的方式可以轻松支持平台的部署，让您的网站无缝迁移，内置已经支持SAE和BAE3.0。\n</p>\n<p>\n	7. 云服务支持：即将启动支持云存储、云安全、云过滤和云统计等服务，更多贴心的服务让您的网站更安心。\n</p>\n<p>\n	8. 安全稳健：提供稳健的安全策略，包括备份恢复、容错、防止恶意攻击登录，网页防篡改等多项安全管理功能，保证系统安全，可靠、稳定的运行。&nbsp;\n</p>\n<p>\n	9. 应用仓库：官方应用仓库拥有大量来自第三方插件和应用模块、模板主题，有众多来自开源社区的贡献，让您的网站“One”美无缺。&nbsp;\n</p>\n<p>\n	<br />\n</p>\n<p>\n	<strong>&nbsp;OneThink集成了一个完善的后台管理体系和前台模板标签系统，让你轻松管理数据和进行前台网站的标签式开发。&nbsp;</strong> \n</p>\n<p>\n	<br />\n</p>\n<h2>\n	后台主要功能：\n</h2>\n<p>\n	1. 用户Passport系统\n</p>\n<p>\n	2. 配置管理系统&nbsp;\n</p>\n<p>\n	3. 权限控制系统\n</p>\n<p>\n	4. 后台建模系统&nbsp;\n</p>\n<p>\n	5. 多级分类系统&nbsp;\n</p>\n<p>\n	6. 用户行为系统&nbsp;\n</p>\n<p>\n	7. 钩子和插件系统\n</p>\n<p>\n	8. 系统日志系统&nbsp;\n</p>\n<p>\n	9. 数据备份和还原\n</p>\n<p>\n	<br />\n</p>\n<p>\n	&nbsp;[ 官方下载：&nbsp;<a href=\"http://www.onethink.cn/download.html\" target=\"_blank\">http://www.onethink.cn/download.html</a>&nbsp;&nbsp;开发手册：<a href=\"http://document.onethink.cn/\" target=\"_blank\">http://document.onethink.cn/</a>&nbsp;]&nbsp;\n</p>\n<p>\n	<br />\n</p>\n<p>\n	<strong>OneThink开发团队 2013~2014</strong> \n</p>', '', '0');

-- -----------------------------
-- Table structure for `onethink_document_download`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_document_download`;
CREATE TABLE `onethink_document_download` (
  `id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文档ID',
  `parse` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '内容解析类型',
  `content` text NOT NULL COMMENT '下载详细描述',
  `template` varchar(100) NOT NULL DEFAULT '' COMMENT '详情页显示模板',
  `file_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文件ID',
  `download` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '下载次数',
  `size` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '文件大小',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='文档模型下载表';


-- -----------------------------
-- Table structure for `onethink_file`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_file`;
CREATE TABLE `onethink_file` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '文件ID',
  `name` char(30) NOT NULL DEFAULT '' COMMENT '原始文件名',
  `savename` char(20) NOT NULL DEFAULT '' COMMENT '保存名称',
  `savepath` char(30) NOT NULL DEFAULT '' COMMENT '文件保存路径',
  `ext` char(5) NOT NULL DEFAULT '' COMMENT '文件后缀',
  `mime` char(40) NOT NULL DEFAULT '' COMMENT '文件mime类型',
  `size` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文件大小',
  `md5` char(32) NOT NULL DEFAULT '' COMMENT '文件md5',
  `sha1` char(40) NOT NULL DEFAULT '' COMMENT '文件 sha1编码',
  `location` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '文件保存位置',
  `url` varchar(255) NOT NULL DEFAULT '' COMMENT '远程地址',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '上传时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_md5` (`md5`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COMMENT='文件表';

-- -----------------------------
-- Records of `onethink_file`
-- -----------------------------
INSERT INTO `onethink_file` VALUES ('8', 'atmins.mp4', '562f3c6fbd9f4.mp4', '2015-10-27/', 'mp4', 'video/mp4', '998006', 'ce1c4dfc2a4c490750e6dbf96fdc2f20', 'ce18189d1a2a491b5337f61cb3895e56a883adf1', '0', '', '1445936239');
INSERT INTO `onethink_file` VALUES ('5', 'preview.mp4', '562edf064cc2f.mp4', '2015-10-27/', 'mp4', 'video/mp4', '5842606', '26475bc59102545c9f898e44d461219e', '2a3dc1c04f5aed82b909c00f726d6c9f21e1701e', '0', '', '1445912325');

-- -----------------------------
-- Table structure for `onethink_friendlink`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_friendlink`;
CREATE TABLE `onethink_friendlink` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '自增id',
  `title` varchar(20) COLLATE utf8_bin NOT NULL COMMENT '链接标题',
  `url` varchar(255) COLLATE utf8_bin NOT NULL COMMENT '链接地址',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '状态（-1：已删除，0：禁用，1：正常）',
  `create_time` int(10) unsigned NOT NULL COMMENT '建时间',
  `update_time` int(10) NOT NULL,
  `sort` smallint(3) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- -----------------------------
-- Records of `onethink_friendlink`
-- -----------------------------
INSERT INTO `onethink_friendlink` VALUES ('1', '百度搜索', 'https://www.baidu.com/', '1', '0', '0', '4');
INSERT INTO `onethink_friendlink` VALUES ('2', '谷歌翻译', 'http://translate.google.cn/', '1', '0', '0', '1');
INSERT INTO `onethink_friendlink` VALUES ('3', '必应翻译', 'http://cn.bing.com/dict/', '1', '0', '0', '2');
INSERT INTO `onethink_friendlink` VALUES ('4', '有道翻译', 'http://fanyi.youdao.com/', '1', '0', '0', '3');
INSERT INTO `onethink_friendlink` VALUES ('5', '金山词霸', 'http://www.iciba.com/', '1', '0', '0', '1');

-- -----------------------------
-- Table structure for `onethink_hooks`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_hooks`;
CREATE TABLE `onethink_hooks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(40) NOT NULL DEFAULT '' COMMENT '钩子名称',
  `description` text COMMENT '描述',
  `type` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '类型',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `addons` varchar(255) NOT NULL DEFAULT '' COMMENT '钩子挂载的插件 ''，''分割',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `onethink_hooks`
-- -----------------------------
INSERT INTO `onethink_hooks` VALUES ('1', 'pageHeader', '页面header钩子，一般用于加载插件CSS文件和代码', '1', '0', '', '1');
INSERT INTO `onethink_hooks` VALUES ('2', 'pageFooter', '页面footer钩子，一般用于加载插件JS文件和JS代码', '1', '0', 'ReturnTop', '1');
INSERT INTO `onethink_hooks` VALUES ('3', 'documentEditForm', '添加编辑表单的 扩展内容钩子', '1', '0', 'Attachment', '1');
INSERT INTO `onethink_hooks` VALUES ('4', 'documentDetailAfter', '文档末尾显示', '1', '0', 'Attachment,SocialComment', '1');
INSERT INTO `onethink_hooks` VALUES ('5', 'documentDetailBefore', '页面内容前显示用钩子', '1', '0', '', '1');
INSERT INTO `onethink_hooks` VALUES ('6', 'documentSaveComplete', '保存文档数据后的扩展钩子', '2', '0', 'Attachment', '1');
INSERT INTO `onethink_hooks` VALUES ('7', 'documentEditFormContent', '添加编辑表单的内容显示钩子', '1', '0', 'Editor', '1');
INSERT INTO `onethink_hooks` VALUES ('8', 'adminArticleEdit', '后台内容编辑页编辑器', '1', '1378982734', 'EditorForAdmin', '1');
INSERT INTO `onethink_hooks` VALUES ('13', 'AdminIndex', '首页小格子个性化显示', '1', '1382596073', 'SiteStat,SystemInfo,DevTeam', '1');
INSERT INTO `onethink_hooks` VALUES ('14', 'topicComment', '评论提交方式扩展钩子。', '1', '1380163518', 'Editor', '1');
INSERT INTO `onethink_hooks` VALUES ('16', 'app_begin', '应用开始', '2', '1384481614', '', '1');
INSERT INTO `onethink_hooks` VALUES ('17', 'Message', '在线留言提交钩子', '1', '0', 'Message', '1');

-- -----------------------------
-- Table structure for `onethink_media_article`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_media_article`;
CREATE TABLE `onethink_media_article` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `media_id` int(11) unsigned NOT NULL COMMENT '资源数据对应id',
  `parse` tinyint(4) NOT NULL COMMENT '内容解析类型（0-html,1-ubb,2-markdown）',
  `content` text COLLATE utf8_bin NOT NULL COMMENT '文章内容',
  `template` varchar(100) COLLATE utf8_bin NOT NULL COMMENT '详情页显示模板',
  `bookmark` int(10) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '状态（-1：已删除，0：禁用，1：正常）',
  `create_time` int(10) unsigned NOT NULL COMMENT '创建时间',
  `sort` smallint(3) NOT NULL DEFAULT '0' COMMENT '排序',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- -----------------------------
-- Records of `onethink_media_article`
-- -----------------------------
INSERT INTO `onethink_media_article` VALUES ('1', '36', '0', '<p class=\"Custom_UnionStyle\" align=\"center\"><img style=\"BORDER-LEFT-WIDTH: 0px; BORDER-RIGHT-WIDTH: 0px; BORDER-BOTTOM-WIDTH: 0px; BORDER-TOP-WIDTH: 0px\" src=\"http://news.tju.edu.cn/zx/ky/201510/W020151012611584761949.jpg\" width=\"800\" height=\"800\"></p>\r\n        <p class=\"Custom_UnionStyle\">　　本站讯（通讯员 郭帅）9月24至29日，生命科学学院派出代表队参加国际遗传工程机器设计竞赛（International Genetically Engineered Machine Competition，iGEM），队伍从全球的280多支参赛队伍中脱颖而出，共获得Best New Application Project、Best New Basic Part两个单项第一，一块金牌，以及Best New Composite Part提名奖。</p>\r\n        <p class=\"Custom_UnionStyle\">　　生命科学学院首次指导队伍参加比赛，参赛学生来自生命科学学院（王镐锋、韩博文、刘嘉舒、李宇辰、赵晴、汪洋、胡金鑫、宗俊杰）、化工学院（鲍东琪、迟恒、陈泽翔、韩轩、董雪梅、李树斌、张雨薇）、求是学部（邵可同、喻俊杰、王画、殷翔宇、彭一格、王晨茂）等。此代表队由生命科学学院杨海涛教授指导，王泽方老师协助指导，该项目以一种蛋白实现多种科研与生活方面的应用——芯片固定、蛋白纯化以及塑料降解，对蛋白的改造也让几项应用的商业化成为可能。参赛队员们利用寒暑假及节假日等休息时间，完成了文献检索，定题，设计，实验，建模，实践，网页制作等大量工作，反复讨论项目细节，不断改进与创新。最终在国际比赛中展现了我校本科生的精神风貌与精彩的科研成果。</p>\r\n        <p class=\"Custom_UnionStyle\">　　此次获得两个单项第一和一块金牌，不仅是对参赛队伍连日辛苦工作的肯定，更是向世界展示了天大学子的科研热情和创新精神。准备参赛的历程为本科生科技创新提供了挑战与锻炼的平台，开创性的成绩是为母校天津大学120周年华诞献上的最佳贺礼！</p>\r\n        <p class=\"Custom_UnionStyle\">　　iGEM始于2005年，每年由美国麻省理工学院（Massachusetts Institute of Technology，MIT）主办，是合成生物学（Synthetic Biology）领域的最高国际性学术竞赛。合成生物学试图重新设计现有的天然的生物系统，或是设计和构建人工生物组件和系统，其目的在于通过了解天然生物体系的运作机理来创造全新的生物体系。参赛的包括了哈佛大学、耶鲁大学、牛津大学、剑桥大学、麻省理工学院等世界顶尖学府派出的代表队。</p>\r\n        <p class=\"Custom_UnionStyle\" align=\"right\">　　（编辑 彭莉 学生编辑 李田田）</p>', '', '8', '1', '1444701925', '0');
INSERT INTO `onethink_media_article` VALUES ('2', '37', '0', '<h3 style=\"text-align: center;\">\r\n  聚青春 &nbsp; 塑英才</h3>\r\n<h3 style=\"text-align: center;\">\r\n  学院成功承办2015年天津市青工职业技能大赛</h3>\r\n<div>\r\n  <strong>&nbsp; &nbsp; &nbsp; &nbsp;（图文/团委通讯员 金轶皓）</strong>8月28、29日，天津市青工职业技能大赛暨第十一届“振兴杯”全国青年职业技能大赛天津赛区选拔赛在学院成功举行。</div>\r\n<div>\r\n  &nbsp; &nbsp; &nbsp; &nbsp;团中央城市部部长郭美荐、团市委副书记方伟、天津市人社局副局长、天津广播电视大学党委书记于茂东、天津中环电子信息集团有限公司纪委书记陈良、团市委青工部部长段海鹰等领导莅临现场指导工作，学院党委书记陈昀陪同考察。</div>\r\n<div style=\"text-align: center;\">\r\n  <img alt=\"\" src=\"http://www.tjdz.net/uploads/allimg/150922/3-15092210322Y43.jpg\" style=\"width: 553px; height: 311px;\"></div>\r\n<div style=\"text-align: center;\">\r\n  建筑结构设计师项目实操比赛现场</div>\r\n<div style=\"text-align: center;\">\r\n  <img alt=\"\" src=\"http://www.tjdz.net/uploads/allimg/150922/3-1509221032391Q.jpg\" style=\"width: 553px; height: 369px;\"></div>\r\n<div style=\"text-align: center;\">\r\n  快递业务员项目比赛现场</div>\r\n<div style=\"text-align: center;\">\r\n  <img alt=\"\" src=\"http://www.tjdz.net/uploads/allimg/150922/3-150922103250305.jpg\" style=\"width: 554px; height: 306px;\"></div>\r\n<div style=\"text-align: center;\">\r\n  电子商务师项目答辩现场</div>\r\n<div>\r\n  &nbsp; &nbsp; &nbsp; &nbsp;今年，学院承办了电子商务师、建筑结构设计师和快递业务员三个赛项，并选派计算机应用技术系王蓓和王佳两位教师参加电子商务师赛项比赛。近年来，学院教师参加青工技能大赛成绩骄人，有3位教师荣获天津市五一劳动奖章和新长征突击手称号。</div>\r\n<div>\r\n  &nbsp;</div>', '', '7', '1', '1444701925', '0');
INSERT INTO `onethink_media_article` VALUES ('3', '38', '0', '<div class=\"Custom_UnionStyle\">\r\n<p>　　<span>“如果用一句话来概括这部交响曲的内涵，那就是作者对‘独立之精神、自由之思想’的呼唤。”尽管，冯公让并不愿意用文字来更多地形容他创作的首部交响乐作品，因为音乐的魅力就在于它让任何文字的描述都显得苍白，一切都要交给耳朵和心灵。但谈及创作动因和历程，冯公让数次“情不自禁”地哽咽和激动，让我们看到了这部交响曲作者所要表达的对中国近代历史的反思，对近代高等教育的思索，对人性的或拷问、鞭挞或讴歌、赞美。</span></p>\r\n<p>　　<span>交响曲的创作，让这位年轻的作曲家经常彻夜难眠，他的情绪、他的神经甚至他的身体，都因为这部交响乐每个音符的诞生而压抑、彷徨、亢奋、颤抖。</span></p>\r\n<p>　　<span>这部交响乐共分四个乐章，创作历经</span><span>16</span><span>个月。冯公让坦诚，这</span><span>16</span><span>个月的创作过程对他来说，是一次次地洗礼自己的思想和精神。他读历史，看影像资料……很多时候，他的身体都在颤抖，不能自己，甚至情绪失控。</span></p>\r\n<p>　　<span>“如果一定要给这四个乐章‘冠上’一个主题的话，那第一乐章就是献给为救国兴邦而上下求索的仁人志士的。”冯公让谈到，危机、战争、灾难，是第一乐章的基调，但他并不想让“战争”在乐曲中“具象化”，他相信了解中国近代史的人都能听懂他要表达的情感，理解他在恰逢甲午战争</span><span>120</span><span>周年时再通过史籍和影像回顾那段历史时精神的痛苦和挣扎，也能理解他在创作过程中因为无法摆脱战争阴影而带来的恐惧和痛苦。</span></p>\r\n<p>　　<span>战争和黑暗让人恐惧，打破黑暗求索光明则需要极大的勇气和智慧。“天津大学前身北洋大学</span><span>1895</span><span>年建校，恰是中日甲午海战清廷战败后。它的诞生仿佛黑暗之中的一点光，明亮夺目，中国第一所现代大学的诞生是国人‘自强不息’精神写照，也是中国大学之精神。”冯公让坦诚，天津大学双甲子校庆让他产生了写一部交响乐的“献礼”的冲动，但他的作品却绝不局限于写天津大学，而是写百余年的中国近代史中人们对于国家和民族未来光明之求索。</span></p>\r\n<p>　　<span>第一乐章之后，冯公让创作的是第四乐章。“尽管整部作品的构思已比较清晰，但事实上在具体创作每个乐章时，我都遇到了特别大的困难，甚至有时候觉得寸步难行。”冯公让说，写完第一章后他开始着手创作第四乐章，同时也在脑海中反复敲打第二和第三乐章。</span></p>\r\n<p>　　<span>“第四乐章，我要写一种精神，一种‘自强不息’的精神。”冯公让说，这是他对于天津大学</span><span>120</span><span>年校史的理解，而给他创作灵感的则是</span><span>12</span><span>年前他从音乐学院毕业刚到天大工作时，看到青年湖上赛龙舟的震撼：“年轻人，光着膀子、敲着鼓、喊着号子，这样的场景正是一种合作精神、集体力量和自强不息精神的写照。”为了将这种“号子”表达出来，冯公让遍览各地龙舟号子，但最终却觉得任何一种“号子”都难以表达他想要的那种青春气息。最终，他借鉴了简约派的马达艺术，利用合唱和交响的配合，表达出了自己心中的这种青春昂扬的感受。在冯公让看来，“如果说第四乐章也是献礼的话，那就是献给继往开来者。”</span></p>\r\n<p>　　<span>第三章的创作让冯公让又陷入了一种矛盾、冲突、斗争和阴冷的氛围里，因为他写的是文革的十年浩劫，“我没有经历过这场浩劫，但我的母亲每每提起，都会忍不住流泪。我也看了很多写这段历史的书籍和音像资料，我能感受到我的内心在颤抖。”于是第三章的开篇便是一支长笛阴冷而空旷地呜咽宛转，奠定了整个篇章“冷”的基调。“第三章，我希望通过音乐为坚持真理、追求真理的勇士们唱一唱葬歌。”</span></p>\r\n<p>　　<span>《第一交响曲》的第二乐章描绘的则是新文化运动和五四运动中探索、求知的力量。“那种天不怕、地不怕的探索精神。”冯公让说，这是人们对于冲破黑暗、寻找光明的渴望，也正是这个国家和民族自强不息的探索。（本站记者刘晓艳）</span></p></div>', '', '1', '1', '1444701925', '0');
INSERT INTO `onethink_media_article` VALUES ('4', '39', '0', '<div class=\"Custom_UnionStyle\">\r\n<p align=\"center\">中航科工集团33所智能机器人研究室主任张新华</p>\r\n<p align=\"center\"><img style=\"BORDER-LEFT-WIDTH: 0px; BORDER-RIGHT-WIDTH: 0px; BORDER-BOTTOM-WIDTH: 0px; BORDER-TOP-WIDTH: 0px\" src=\"./W020150710324274294527.png\" oldsrc=\"W020150710324274294527.png\" _fcksavedurl=\"/webpic/W0201507/W020150710/W020150710324274294527.png\"></p>\r\n<p align=\"center\">《人民日报》 2014年12月04日　 06 版</p>\r\n<p align=\"center\"><img style=\"BORDER-LEFT-WIDTH: 0px; BORDER-RIGHT-WIDTH: 0px; BORDER-BOTTOM-WIDTH: 0px; BORDER-TOP-WIDTH: 0px\" src=\"./W020150710324274462763.jpg\" oldsrc=\"W020150710324274462763.jpg\" _fcksavedurl=\"/webpic/W0201507/W020150710/W020150710324274462763.jpg\"></p>\r\n<p>　　印刷机器人、切割机器人、装配机器人等各式各样的轻巧型工业机器人站成一排， “旋转、拨动、夹持、定位……”一气呵成，张新华得意地向大家展示他们为劳动密集型行业研制成功的系列化轻巧型机器人产品。</p>\r\n<p>　　张新华是中国航天科工集团公司三院33所智能机器人研究室主任，同事们说，新华是一个地地道道的“机器人迷”，一旦研究起机器人，他常常忘记下班。值得一提的是，张新华带领团队研制成功的装卸源机器人，可以实现放射源无人化装卸操作，被誉为我国首台应用于油田测井前线的航天“特种兵”。</p>\r\n<p>　　2002年3月，从天津大学机械设计及理论专业博士毕业的张新华应聘来到33所，初出茅庐就承担起了33所伺服系统的预研工作。扎实的理论功底和良好的专业技术让张新华很快脱颖而出。</p>\r\n<p>　　有一次，所里将一个重大难题交给张新华，他困了就趴在桌上歇会儿，晚上就睡在实验室的凳子上，经过40多天奋战，终于攻克了技术难关。此后，张新华先后担任多个型号伺服系统主任设计师，取得一系列成果。</p>\r\n<p>　　机遇偏爱有准备的头脑。2011年2月24日，伴随着国内外机器人研究的热潮，33所也成立了智能机器人研究室，38岁的张新华被任命为研究室主任。然而，机器人要搞起来很容易，但要在国内占有一席之地却并非易事。</p>\r\n<p>　　“我们的首要任务就是尽快找到合适的切入点。”张新华敏锐地意识到，确定发展方向决不能靠拍脑袋，必须走出去。张新华带领自己的团队在全国进行了长达一年的深入调研。“我们的研究方向经历了一个由发散到收敛的过程，很多方向的确定都是走出来和比出来的。比如轻巧型工业机器人最早并不是我们的重点方向，但张主任带队调研后发现，这种可以把人员从重复性劳动中解放出来的机器人市场潜力巨大，后来我们就将其调整为重点方向了。”研制人员王晓林的一番话道出了“走出去”的重要性。</p>\r\n<p>　　“我对机械还比较了解，但智能机器人研制是一项十分复杂的系统工程，必须进行大量学习和调研。”对于学习的重要性，张新华有着清醒的认识。</p>\r\n<p>　　2013年，中国市场共销售工业机器人近3.7万台，成为全球第一大工业机器人消费市场。国产工业机器人也异军突起，预计今年国产工业机器人销售总量将超过1.2万台，同比增长25%左右。</p>\r\n<p>　　面对发展如此快速的工业机器人市场，张新华兴奋地说：“我们要发扬航天精神，利用航天核心技术的独特优势，解决制约国内机器人发展的关键技术瓶颈，把我们的智能机器人产业做强做大，把我们智能机器人研究室打造成国内一流的研发团队。”</p>\r\n<p>　　人民日报：<a href=\"http://paper.people.com.cn/rmrb/html/2014-12/04/nw.D110000renmrb_20141204_6-06.htm\" _fcksavedurl=\"http://paper.people.com.cn/rmrb/html/2014-12/04/nw.D110000renmrb_20141204_6-06.htm\">http://paper.people.com.cn/rmrb/html/2014-12/04/nw.D110000renmrb_20141204_6-06.htm</a></p></div>', '', '0', '1', '1444701925', '0');
INSERT INTO `onethink_media_article` VALUES ('5', '40', '0', '<div class=\"Custom_UnionStyle\">\r\n<p align=\"center\"><img style=\"BORDER-LEFT-WIDTH: 0px; BORDER-RIGHT-WIDTH: 0px; BORDER-BOTTOM-WIDTH: 0px; BORDER-TOP-WIDTH: 0px\" src=\"./W020150714374333008944.jpg\" oldsrc=\"W020150714374333008944.jpg\" _fcksavedurl=\"/webpic/W0201507/W020150714/W020150714374333008944.jpg\"></p>\r\n<p align=\"center\">天大学生参观天津市规划展览馆</p>\r\n<p align=\"center\"><img style=\"BORDER-LEFT-WIDTH: 0px; BORDER-RIGHT-WIDTH: 0px; BORDER-BOTTOM-WIDTH: 0px; BORDER-TOP-WIDTH: 0px\" src=\"./W020150714374333060320.jpg\" oldsrc=\"W020150714374333060320.jpg\" _fcksavedurl=\"/webpic/W0201507/W020150714/W020150714374333060320.jpg\"></p>\r\n<p align=\"center\">天大学生参观海鸥手表厂</p>\r\n<p align=\"center\"><img style=\"BORDER-LEFT-WIDTH: 0px; BORDER-RIGHT-WIDTH: 0px; BORDER-BOTTOM-WIDTH: 0px; BORDER-TOP-WIDTH: 0px\" src=\"./W020150714374333118932.jpg\" oldsrc=\"W020150714374333118932.jpg\" _fcksavedurl=\"/webpic/W0201507/W020150714/W020150714374333118932.jpg\"></p>\r\n<p align=\"center\">天大学子参观天津国际生物医药联合研究院</p>\r\n<p align=\"center\"><img style=\"BORDER-LEFT-WIDTH: 0px; BORDER-RIGHT-WIDTH: 0px; BORDER-BOTTOM-WIDTH: 0px; BORDER-TOP-WIDTH: 0px\" src=\"./W020150714374333164705.jpg\" oldsrc=\"W020150714374333164705.jpg\" _fcksavedurl=\"/webpic/W0201507/W020150714/W020150714374333164705.jpg\"></p>\r\n<p align=\"center\">天大学生参观国家超级计算机天津中心</p>\r\n<p align=\"center\"><img style=\"BORDER-LEFT-WIDTH: 0px; BORDER-RIGHT-WIDTH: 0px; BORDER-BOTTOM-WIDTH: 0px; BORDER-TOP-WIDTH: 0px\" src=\"./W020150714374333215113.jpg\" oldsrc=\"W020150714374333215113.jpg\" _fcksavedurl=\"/webpic/W0201507/W020150714/W020150714374333215113.jpg\"></p>\r\n<p align=\"center\">天大学生参观建设中的于家堡高铁站</p>\r\n<p align=\"center\"><img style=\"BORDER-LEFT-WIDTH: 0px; BORDER-RIGHT-WIDTH: 0px; BORDER-BOTTOM-WIDTH: 0px; BORDER-TOP-WIDTH: 0px\" src=\"./W020150714374333269134.jpg\" oldsrc=\"W020150714374333269134.jpg\" _fcksavedurl=\"/webpic/W0201507/W020150714/W020150714374333269134.jpg\"></p>\r\n<p align=\"center\">天大学生乘船参观海河综合治理改造工程</p>\r\n<p>　　<span>本站讯（学生记者 </span><span>杨洪涛 </span><span>记者 </span><span>朱宝琳 </span><span>摄影 </span><span>赵珺鹏 </span><span>聂婷娟）</span><span>6</span><span>月</span><span>26</span><span>日，百余名天津大学优秀学子应天津市委代理书记、市长黄兴国的邀请，在市委、市政府相关部门的精心安排下，进行了为期一天的“天大学子津门行”活动。参观途中，学生们实地了解了天津的发展规划和突出成就，不时发出阵阵惊叹和掌声，他们被天津的历史文化之美、城市建设之美、未来前景之美所吸引、震撼，“民族自尊心和自信心一次次爆棚”。</span></p>\r\n<p>　　<span>当日行程紧凑、充实，天大学子依次考察了天津市规划展览馆、中科院天津工业生物技术研究所、空客</span><span>A320</span><span>天津总装项目、海鸥手表厂、天津自贸试验区东疆港区服务大厅（途径东疆湾沙滩、邮轮母港、天津港太平洋国际集装箱码头）、天津国际生物医药联合研究院、国家超级计算机天津中心、于家堡高铁站、滨海新区中心商务区、海河教育园区中国（天津）职业技能公共实训中心、天津文化中心，并乘船参观海河综合治理改造工程。从展览场馆到研究院所，从企业公司到文化中心，天津的发展情况一览无遗。</span></p>\r\n<p>　　<span>“来天津七八年了，每次看展览都有新变化，新惊喜。”来自管理与经济学部目前主修工商管理的宋瑶在参观完天津市规划展览馆后感慨。宋瑶在天津大学从本科一直读到博士，天津是她的第二故乡。父母以前很希望她回家乡辽宁工作，但是现在天津和辽宁之间通了高铁，两个小时就可以回家看看，因此父母也就不再要求女儿回家乡了。宋瑶学习研究的是区域经济发展规划，对于天津和自己的发展她很有信心：“我在学校参与了科技孵化器项目，得到了政策资金各方面的支持。将来工作了我希望做自己擅长并感兴趣的事情——把技术和经济结合起来。天津的科技型中小企业很多，这些‘小巨人’助力天津发展也给我们提供了大量的机会。这次</span><span>360</span><span>度全方位无死角的考察，特别是看到滨海新区的发展，更加坚定了我留在天津的决心，和天津一起成长。”</span></p>\r\n<p>　　<span>天津国际邮轮母港的客运大厦的外形就像一艘大型邮轮，引起建工学院水利工程专业硕士生杨旭的巨大兴趣，他说：“我本科阶段主修港口方面的知识，以前参观的都是货港，这次来到邮轮港口，听人介绍</span><span>15</span><span>层高、内部构造精细的邮轮，特别震撼。”谈起天津的建设与自己的关系，他说：“天津的港口发展很快，虽然东疆、北疆已经建设好了，但是南疆正在建设中，有很多机会，我会优先考虑在天津发展。”</span></p>\r\n<p>　　<span>在国家超级计算机天津中心，大家纷纷与在</span><span>2010</span><span>年运算速度世界排名第一的“天河一号”合影留念。超算中心为全国科研机构和央企提供高性能计算服务，来自管理与经济学部金融学的何枫就领略过它的魅力——“在天大有一个分中心提供计算接口，我们做市场模型试验，普通电脑运算很慢要一两天，但是超级计算机要快得多，节省时间可以更快将成果推广出去。”</span><span>何枫平时做过很多情景模拟以减少金融风险的试验，他希望发挥自己的专业特长优势，将来在天津高校或金融机构工作。</span></p>\r\n<p>　　<span>于家堡高铁站将于今年</span><span>8</span><span>月投入试运营，届时，从北京南站到天津自贸区只需</span><span>45</span><span>分钟。于家堡站的椭圆形壳体像一个美丽的贝壳，而在它的设计建设过程中，天大师生也参与进来。建筑学院艺术设计专业的本科生钱丰就跟着导师为高铁站消防方面提供技术支持，“我们查阅了大量的资料进行分析设计，最大的收获是把学习和实践结合起来，而且对滨海新区的发展有了深入的认识。”此外，钱丰还参与了天津支援西藏的一个项目，到昌都小学建设科技活动室，把</span><span>3D</span><span>打印等科技带到边远山区，让那里的孩子也切身感受到创新的魅力。由于高原上作业困难，所以钱丰采用“模块化”设计活动室，在满足展示科技成果的同时力求简捷，他说“我们不仅要学习知识，更应该把它投入到社会服务中去。”</span></p>\r\n<p>　　<span>在滨海新区中心商务区，学生了解到，商务区内布局了总部经济、金融创新、科技与新一代信息技术、跨境贸易电子商务、文化传媒创意等产业。滨海新区的发展也为大学生创业提供了许多机会和优惠政策，环境学院环境规划专业的研究生崔元彰就紧跟“大众创业、万众创新”“互联网</span><span>+</span><span>”的时代潮流，拥有了自己的创业项目，他表示，我们要勇敢地去实现自己的梦想。</span></p>\r\n<p>　　<span>当晚，天津市委代理书记、市长黄兴国及相关市领导，天津大学党委书记刘建平、校长李家俊与学子们共进晚餐，亲切交谈。学生们表示，这一天不虚此行，对天津的发展充满信心，希望把天津作为自己的职业启航之地，实现自我价值。</span></p>\r\n<p>　　<span>参与“天大学子津门行”活动的一百名学生是在众多报名者中筛选出来的，为了让广大学生了解本次活动，大家把考察情况和自己的感悟分享给天津大学官方微博、微信进行了“直播”，让更多的人了解天津、爱上天津，与天津一起成长。</span></p></div>', '', '0', '1', '1444701925', '0');
INSERT INTO `onethink_media_article` VALUES ('6', '41', '0', '<p class=\"Custom_UnionStyle\" align=\"center\"><img style=\"BORDER-LEFT-WIDTH: 0px; BORDER-RIGHT-WIDTH: 0px; BORDER-BOTTOM-WIDTH: 0px; BORDER-TOP-WIDTH: 0px\" src=\"http://news.tju.edu.cn/zx/ky/201510/W020151012611584761949.jpg\" width=\"800\" height=\"800\"></p>\r\n        <p class=\"Custom_UnionStyle\">　　本站讯（通讯员 郭帅）9月24至29日，生命科学学院派出代表队参加国际遗传工程机器设计竞赛（International Genetically Engineered Machine Competition，iGEM），队伍从全球的280多支参赛队伍中脱颖而出，共获得Best New Application Project、Best New Basic Part两个单项第一，一块金牌，以及Best New Composite Part提名奖。</p>\r\n        <p class=\"Custom_UnionStyle\">　　生命科学学院首次指导队伍参加比赛，参赛学生来自生命科学学院（王镐锋、韩博文、刘嘉舒、李宇辰、赵晴、汪洋、胡金鑫、宗俊杰）、化工学院（鲍东琪、迟恒、陈泽翔、韩轩、董雪梅、李树斌、张雨薇）、求是学部（邵可同、喻俊杰、王画、殷翔宇、彭一格、王晨茂）等。此代表队由生命科学学院杨海涛教授指导，王泽方老师协助指导，该项目以一种蛋白实现多种科研与生活方面的应用——芯片固定、蛋白纯化以及塑料降解，对蛋白的改造也让几项应用的商业化成为可能。参赛队员们利用寒暑假及节假日等休息时间，完成了文献检索，定题，设计，实验，建模，实践，网页制作等大量工作，反复讨论项目细节，不断改进与创新。最终在国际比赛中展现了我校本科生的精神风貌与精彩的科研成果。</p>\r\n        <p class=\"Custom_UnionStyle\">　　此次获得两个单项第一和一块金牌，不仅是对参赛队伍连日辛苦工作的肯定，更是向世界展示了天大学子的科研热情和创新精神。准备参赛的历程为本科生科技创新提供了挑战与锻炼的平台，开创性的成绩是为母校天津大学120周年华诞献上的最佳贺礼！</p>\r\n        <p class=\"Custom_UnionStyle\">　　iGEM始于2005年，每年由美国麻省理工学院（Massachusetts Institute of Technology，MIT）主办，是合成生物学（Synthetic Biology）领域的最高国际性学术竞赛。合成生物学试图重新设计现有的天然的生物系统，或是设计和构建人工生物组件和系统，其目的在于通过了解天然生物体系的运作机理来创造全新的生物体系。参赛的包括了哈佛大学、耶鲁大学、牛津大学、剑桥大学、麻省理工学院等世界顶尖学府派出的代表队。</p>\r\n        <p class=\"Custom_UnionStyle\" align=\"right\">　　（编辑 彭莉 学生编辑 李田田）</p>', '', '0', '1', '1444701925', '0');
INSERT INTO `onethink_media_article` VALUES ('7', '42', '0', '<h3 style=\"text-align: center;\">\r\n  聚青春 &nbsp; 塑英才</h3>\r\n<h3 style=\"text-align: center;\">\r\n  学院成功承办2015年天津市青工职业技能大赛</h3>\r\n<div>\r\n  <strong>&nbsp; &nbsp; &nbsp; &nbsp;（图文/团委通讯员 金轶皓）</strong>8月28、29日，天津市青工职业技能大赛暨第十一届“振兴杯”全国青年职业技能大赛天津赛区选拔赛在学院成功举行。</div>\r\n<div>\r\n  &nbsp; &nbsp; &nbsp; &nbsp;团中央城市部部长郭美荐、团市委副书记方伟、天津市人社局副局长、天津广播电视大学党委书记于茂东、天津中环电子信息集团有限公司纪委书记陈良、团市委青工部部长段海鹰等领导莅临现场指导工作，学院党委书记陈昀陪同考察。</div>\r\n<div style=\"text-align: center;\">\r\n  <img alt=\"\" src=\"http://www.tjdz.net/uploads/allimg/150922/3-15092210322Y43.jpg\" style=\"width: 553px; height: 311px;\"></div>\r\n<div style=\"text-align: center;\">\r\n  建筑结构设计师项目实操比赛现场</div>\r\n<div style=\"text-align: center;\">\r\n  <img alt=\"\" src=\"http://www.tjdz.net/uploads/allimg/150922/3-1509221032391Q.jpg\" style=\"width: 553px; height: 369px;\"></div>\r\n<div style=\"text-align: center;\">\r\n  快递业务员项目比赛现场</div>\r\n<div style=\"text-align: center;\">\r\n  <img alt=\"\" src=\"http://www.tjdz.net/uploads/allimg/150922/3-150922103250305.jpg\" style=\"width: 554px; height: 306px;\"></div>\r\n<div style=\"text-align: center;\">\r\n  电子商务师项目答辩现场</div>\r\n<div>\r\n  &nbsp; &nbsp; &nbsp; &nbsp;今年，学院承办了电子商务师、建筑结构设计师和快递业务员三个赛项，并选派计算机应用技术系王蓓和王佳两位教师参加电子商务师赛项比赛。近年来，学院教师参加青工技能大赛成绩骄人，有3位教师荣获天津市五一劳动奖章和新长征突击手称号。</div>\r\n<div>\r\n  &nbsp;</div>', '', '0', '1', '1444701925', '0');
INSERT INTO `onethink_media_article` VALUES ('8', '43', '0', '<div class=\"Custom_UnionStyle\">\r\n<p>　　<span>“如果用一句话来概括这部交响曲的内涵，那就是作者对‘独立之精神、自由之思想’的呼唤。”尽管，冯公让并不愿意用文字来更多地形容他创作的首部交响乐作品，因为音乐的魅力就在于它让任何文字的描述都显得苍白，一切都要交给耳朵和心灵。但谈及创作动因和历程，冯公让数次“情不自禁”地哽咽和激动，让我们看到了这部交响曲作者所要表达的对中国近代历史的反思，对近代高等教育的思索，对人性的或拷问、鞭挞或讴歌、赞美。</span></p>\r\n<p>　　<span>交响曲的创作，让这位年轻的作曲家经常彻夜难眠，他的情绪、他的神经甚至他的身体，都因为这部交响乐每个音符的诞生而压抑、彷徨、亢奋、颤抖。</span></p>\r\n<p>　　<span>这部交响乐共分四个乐章，创作历经</span><span>16</span><span>个月。冯公让坦诚，这</span><span>16</span><span>个月的创作过程对他来说，是一次次地洗礼自己的思想和精神。他读历史，看影像资料……很多时候，他的身体都在颤抖，不能自己，甚至情绪失控。</span></p>\r\n<p>　　<span>“如果一定要给这四个乐章‘冠上’一个主题的话，那第一乐章就是献给为救国兴邦而上下求索的仁人志士的。”冯公让谈到，危机、战争、灾难，是第一乐章的基调，但他并不想让“战争”在乐曲中“具象化”，他相信了解中国近代史的人都能听懂他要表达的情感，理解他在恰逢甲午战争</span><span>120</span><span>周年时再通过史籍和影像回顾那段历史时精神的痛苦和挣扎，也能理解他在创作过程中因为无法摆脱战争阴影而带来的恐惧和痛苦。</span></p>\r\n<p>　　<span>战争和黑暗让人恐惧，打破黑暗求索光明则需要极大的勇气和智慧。“天津大学前身北洋大学</span><span>1895</span><span>年建校，恰是中日甲午海战清廷战败后。它的诞生仿佛黑暗之中的一点光，明亮夺目，中国第一所现代大学的诞生是国人‘自强不息’精神写照，也是中国大学之精神。”冯公让坦诚，天津大学双甲子校庆让他产生了写一部交响乐的“献礼”的冲动，但他的作品却绝不局限于写天津大学，而是写百余年的中国近代史中人们对于国家和民族未来光明之求索。</span></p>\r\n<p>　　<span>第一乐章之后，冯公让创作的是第四乐章。“尽管整部作品的构思已比较清晰，但事实上在具体创作每个乐章时，我都遇到了特别大的困难，甚至有时候觉得寸步难行。”冯公让说，写完第一章后他开始着手创作第四乐章，同时也在脑海中反复敲打第二和第三乐章。</span></p>\r\n<p>　　<span>“第四乐章，我要写一种精神，一种‘自强不息’的精神。”冯公让说，这是他对于天津大学</span><span>120</span><span>年校史的理解，而给他创作灵感的则是</span><span>12</span><span>年前他从音乐学院毕业刚到天大工作时，看到青年湖上赛龙舟的震撼：“年轻人，光着膀子、敲着鼓、喊着号子，这样的场景正是一种合作精神、集体力量和自强不息精神的写照。”为了将这种“号子”表达出来，冯公让遍览各地龙舟号子，但最终却觉得任何一种“号子”都难以表达他想要的那种青春气息。最终，他借鉴了简约派的马达艺术，利用合唱和交响的配合，表达出了自己心中的这种青春昂扬的感受。在冯公让看来，“如果说第四乐章也是献礼的话，那就是献给继往开来者。”</span></p>\r\n<p>　　<span>第三章的创作让冯公让又陷入了一种矛盾、冲突、斗争和阴冷的氛围里，因为他写的是文革的十年浩劫，“我没有经历过这场浩劫，但我的母亲每每提起，都会忍不住流泪。我也看了很多写这段历史的书籍和音像资料，我能感受到我的内心在颤抖。”于是第三章的开篇便是一支长笛阴冷而空旷地呜咽宛转，奠定了整个篇章“冷”的基调。“第三章，我希望通过音乐为坚持真理、追求真理的勇士们唱一唱葬歌。”</span></p>\r\n<p>　　<span>《第一交响曲》的第二乐章描绘的则是新文化运动和五四运动中探索、求知的力量。“那种天不怕、地不怕的探索精神。”冯公让说，这是人们对于冲破黑暗、寻找光明的渴望，也正是这个国家和民族自强不息的探索。（本站记者刘晓艳）</span></p></div>', '', '1', '1', '1444701925', '0');
INSERT INTO `onethink_media_article` VALUES ('9', '44', '0', '<div class=\"Custom_UnionStyle\">\r\n<p align=\"center\">中航科工集团33所智能机器人研究室主任张新华</p>\r\n<p align=\"center\"><img style=\"BORDER-LEFT-WIDTH: 0px; BORDER-RIGHT-WIDTH: 0px; BORDER-BOTTOM-WIDTH: 0px; BORDER-TOP-WIDTH: 0px\" src=\"./W020150710324274294527.png\" oldsrc=\"W020150710324274294527.png\" _fcksavedurl=\"/webpic/W0201507/W020150710/W020150710324274294527.png\"></p>\r\n<p align=\"center\">《人民日报》 2014年12月04日　 06 版</p>\r\n<p align=\"center\"><img style=\"BORDER-LEFT-WIDTH: 0px; BORDER-RIGHT-WIDTH: 0px; BORDER-BOTTOM-WIDTH: 0px; BORDER-TOP-WIDTH: 0px\" src=\"./W020150710324274462763.jpg\" oldsrc=\"W020150710324274462763.jpg\" _fcksavedurl=\"/webpic/W0201507/W020150710/W020150710324274462763.jpg\"></p>\r\n<p>　　印刷机器人、切割机器人、装配机器人等各式各样的轻巧型工业机器人站成一排， “旋转、拨动、夹持、定位……”一气呵成，张新华得意地向大家展示他们为劳动密集型行业研制成功的系列化轻巧型机器人产品。</p>\r\n<p>　　张新华是中国航天科工集团公司三院33所智能机器人研究室主任，同事们说，新华是一个地地道道的“机器人迷”，一旦研究起机器人，他常常忘记下班。值得一提的是，张新华带领团队研制成功的装卸源机器人，可以实现放射源无人化装卸操作，被誉为我国首台应用于油田测井前线的航天“特种兵”。</p>\r\n<p>　　2002年3月，从天津大学机械设计及理论专业博士毕业的张新华应聘来到33所，初出茅庐就承担起了33所伺服系统的预研工作。扎实的理论功底和良好的专业技术让张新华很快脱颖而出。</p>\r\n<p>　　有一次，所里将一个重大难题交给张新华，他困了就趴在桌上歇会儿，晚上就睡在实验室的凳子上，经过40多天奋战，终于攻克了技术难关。此后，张新华先后担任多个型号伺服系统主任设计师，取得一系列成果。</p>\r\n<p>　　机遇偏爱有准备的头脑。2011年2月24日，伴随着国内外机器人研究的热潮，33所也成立了智能机器人研究室，38岁的张新华被任命为研究室主任。然而，机器人要搞起来很容易，但要在国内占有一席之地却并非易事。</p>\r\n<p>　　“我们的首要任务就是尽快找到合适的切入点。”张新华敏锐地意识到，确定发展方向决不能靠拍脑袋，必须走出去。张新华带领自己的团队在全国进行了长达一年的深入调研。“我们的研究方向经历了一个由发散到收敛的过程，很多方向的确定都是走出来和比出来的。比如轻巧型工业机器人最早并不是我们的重点方向，但张主任带队调研后发现，这种可以把人员从重复性劳动中解放出来的机器人市场潜力巨大，后来我们就将其调整为重点方向了。”研制人员王晓林的一番话道出了“走出去”的重要性。</p>\r\n<p>　　“我对机械还比较了解，但智能机器人研制是一项十分复杂的系统工程，必须进行大量学习和调研。”对于学习的重要性，张新华有着清醒的认识。</p>\r\n<p>　　2013年，中国市场共销售工业机器人近3.7万台，成为全球第一大工业机器人消费市场。国产工业机器人也异军突起，预计今年国产工业机器人销售总量将超过1.2万台，同比增长25%左右。</p>\r\n<p>　　面对发展如此快速的工业机器人市场，张新华兴奋地说：“我们要发扬航天精神，利用航天核心技术的独特优势，解决制约国内机器人发展的关键技术瓶颈，把我们的智能机器人产业做强做大，把我们智能机器人研究室打造成国内一流的研发团队。”</p>\r\n<p>　　人民日报：<a href=\"http://paper.people.com.cn/rmrb/html/2014-12/04/nw.D110000renmrb_20141204_6-06.htm\" _fcksavedurl=\"http://paper.people.com.cn/rmrb/html/2014-12/04/nw.D110000renmrb_20141204_6-06.htm\">http://paper.people.com.cn/rmrb/html/2014-12/04/nw.D110000renmrb_20141204_6-06.htm</a></p></div>', '', '1', '1', '1444701925', '0');
INSERT INTO `onethink_media_article` VALUES ('10', '45', '0', '<div class=\"Custom_UnionStyle\">\r\n<p align=\"center\"><img style=\"BORDER-LEFT-WIDTH: 0px; BORDER-RIGHT-WIDTH: 0px; BORDER-BOTTOM-WIDTH: 0px; BORDER-TOP-WIDTH: 0px\" src=\"./W020150714374333008944.jpg\" oldsrc=\"W020150714374333008944.jpg\" _fcksavedurl=\"/webpic/W0201507/W020150714/W020150714374333008944.jpg\"></p>\r\n<p align=\"center\">天大学生参观天津市规划展览馆</p>\r\n<p align=\"center\"><img style=\"BORDER-LEFT-WIDTH: 0px; BORDER-RIGHT-WIDTH: 0px; BORDER-BOTTOM-WIDTH: 0px; BORDER-TOP-WIDTH: 0px\" src=\"./W020150714374333060320.jpg\" oldsrc=\"W020150714374333060320.jpg\" _fcksavedurl=\"/webpic/W0201507/W020150714/W020150714374333060320.jpg\"></p>\r\n<p align=\"center\">天大学生参观海鸥手表厂</p>\r\n<p align=\"center\"><img style=\"BORDER-LEFT-WIDTH: 0px; BORDER-RIGHT-WIDTH: 0px; BORDER-BOTTOM-WIDTH: 0px; BORDER-TOP-WIDTH: 0px\" src=\"./W020150714374333118932.jpg\" oldsrc=\"W020150714374333118932.jpg\" _fcksavedurl=\"/webpic/W0201507/W020150714/W020150714374333118932.jpg\"></p>\r\n<p align=\"center\">天大学子参观天津国际生物医药联合研究院</p>\r\n<p align=\"center\"><img style=\"BORDER-LEFT-WIDTH: 0px; BORDER-RIGHT-WIDTH: 0px; BORDER-BOTTOM-WIDTH: 0px; BORDER-TOP-WIDTH: 0px\" src=\"./W020150714374333164705.jpg\" oldsrc=\"W020150714374333164705.jpg\" _fcksavedurl=\"/webpic/W0201507/W020150714/W020150714374333164705.jpg\"></p>\r\n<p align=\"center\">天大学生参观国家超级计算机天津中心</p>\r\n<p align=\"center\"><img style=\"BORDER-LEFT-WIDTH: 0px; BORDER-RIGHT-WIDTH: 0px; BORDER-BOTTOM-WIDTH: 0px; BORDER-TOP-WIDTH: 0px\" src=\"./W020150714374333215113.jpg\" oldsrc=\"W020150714374333215113.jpg\" _fcksavedurl=\"/webpic/W0201507/W020150714/W020150714374333215113.jpg\"></p>\r\n<p align=\"center\">天大学生参观建设中的于家堡高铁站</p>\r\n<p align=\"center\"><img style=\"BORDER-LEFT-WIDTH: 0px; BORDER-RIGHT-WIDTH: 0px; BORDER-BOTTOM-WIDTH: 0px; BORDER-TOP-WIDTH: 0px\" src=\"./W020150714374333269134.jpg\" oldsrc=\"W020150714374333269134.jpg\" _fcksavedurl=\"/webpic/W0201507/W020150714/W020150714374333269134.jpg\"></p>\r\n<p align=\"center\">天大学生乘船参观海河综合治理改造工程</p>\r\n<p>　　<span>本站讯（学生记者 </span><span>杨洪涛 </span><span>记者 </span><span>朱宝琳 </span><span>摄影 </span><span>赵珺鹏 </span><span>聂婷娟）</span><span>6</span><span>月</span><span>26</span><span>日，百余名天津大学优秀学子应天津市委代理书记、市长黄兴国的邀请，在市委、市政府相关部门的精心安排下，进行了为期一天的“天大学子津门行”活动。参观途中，学生们实地了解了天津的发展规划和突出成就，不时发出阵阵惊叹和掌声，他们被天津的历史文化之美、城市建设之美、未来前景之美所吸引、震撼，“民族自尊心和自信心一次次爆棚”。</span></p>\r\n<p>　　<span>当日行程紧凑、充实，天大学子依次考察了天津市规划展览馆、中科院天津工业生物技术研究所、空客</span><span>A320</span><span>天津总装项目、海鸥手表厂、天津自贸试验区东疆港区服务大厅（途径东疆湾沙滩、邮轮母港、天津港太平洋国际集装箱码头）、天津国际生物医药联合研究院、国家超级计算机天津中心、于家堡高铁站、滨海新区中心商务区、海河教育园区中国（天津）职业技能公共实训中心、天津文化中心，并乘船参观海河综合治理改造工程。从展览场馆到研究院所，从企业公司到文化中心，天津的发展情况一览无遗。</span></p>\r\n<p>　　<span>“来天津七八年了，每次看展览都有新变化，新惊喜。”来自管理与经济学部目前主修工商管理的宋瑶在参观完天津市规划展览馆后感慨。宋瑶在天津大学从本科一直读到博士，天津是她的第二故乡。父母以前很希望她回家乡辽宁工作，但是现在天津和辽宁之间通了高铁，两个小时就可以回家看看，因此父母也就不再要求女儿回家乡了。宋瑶学习研究的是区域经济发展规划，对于天津和自己的发展她很有信心：“我在学校参与了科技孵化器项目，得到了政策资金各方面的支持。将来工作了我希望做自己擅长并感兴趣的事情——把技术和经济结合起来。天津的科技型中小企业很多，这些‘小巨人’助力天津发展也给我们提供了大量的机会。这次</span><span>360</span><span>度全方位无死角的考察，特别是看到滨海新区的发展，更加坚定了我留在天津的决心，和天津一起成长。”</span></p>\r\n<p>　　<span>天津国际邮轮母港的客运大厦的外形就像一艘大型邮轮，引起建工学院水利工程专业硕士生杨旭的巨大兴趣，他说：“我本科阶段主修港口方面的知识，以前参观的都是货港，这次来到邮轮港口，听人介绍</span><span>15</span><span>层高、内部构造精细的邮轮，特别震撼。”谈起天津的建设与自己的关系，他说：“天津的港口发展很快，虽然东疆、北疆已经建设好了，但是南疆正在建设中，有很多机会，我会优先考虑在天津发展。”</span></p>\r\n<p>　　<span>在国家超级计算机天津中心，大家纷纷与在</span><span>2010</span><span>年运算速度世界排名第一的“天河一号”合影留念。超算中心为全国科研机构和央企提供高性能计算服务，来自管理与经济学部金融学的何枫就领略过它的魅力——“在天大有一个分中心提供计算接口，我们做市场模型试验，普通电脑运算很慢要一两天，但是超级计算机要快得多，节省时间可以更快将成果推广出去。”</span><span>何枫平时做过很多情景模拟以减少金融风险的试验，他希望发挥自己的专业特长优势，将来在天津高校或金融机构工作。</span></p>\r\n<p>　　<span>于家堡高铁站将于今年</span><span>8</span><span>月投入试运营，届时，从北京南站到天津自贸区只需</span><span>45</span><span>分钟。于家堡站的椭圆形壳体像一个美丽的贝壳，而在它的设计建设过程中，天大师生也参与进来。建筑学院艺术设计专业的本科生钱丰就跟着导师为高铁站消防方面提供技术支持，“我们查阅了大量的资料进行分析设计，最大的收获是把学习和实践结合起来，而且对滨海新区的发展有了深入的认识。”此外，钱丰还参与了天津支援西藏的一个项目，到昌都小学建设科技活动室，把</span><span>3D</span><span>打印等科技带到边远山区，让那里的孩子也切身感受到创新的魅力。由于高原上作业困难，所以钱丰采用“模块化”设计活动室，在满足展示科技成果的同时力求简捷，他说“我们不仅要学习知识，更应该把它投入到社会服务中去。”</span></p>\r\n<p>　　<span>在滨海新区中心商务区，学生了解到，商务区内布局了总部经济、金融创新、科技与新一代信息技术、跨境贸易电子商务、文化传媒创意等产业。滨海新区的发展也为大学生创业提供了许多机会和优惠政策，环境学院环境规划专业的研究生崔元彰就紧跟“大众创业、万众创新”“互联网</span><span>+</span><span>”的时代潮流，拥有了自己的创业项目，他表示，我们要勇敢地去实现自己的梦想。</span></p>\r\n<p>　　<span>当晚，天津市委代理书记、市长黄兴国及相关市领导，天津大学党委书记刘建平、校长李家俊与学子们共进晚餐，亲切交谈。学生们表示，这一天不虚此行，对天津的发展充满信心，希望把天津作为自己的职业启航之地，实现自我价值。</span></p>\r\n<p>　　<span>参与“天大学子津门行”活动的一百名学生是在众多报名者中筛选出来的，为了让广大学生了解本次活动，大家把考察情况和自己的感悟分享给天津大学官方微博、微信进行了“直播”，让更多的人了解天津、爱上天津，与天津一起成长。</span></p></div>', '', '0', '1', '1444701925', '0');
INSERT INTO `onethink_media_article` VALUES ('11', '46', '0', '<p class=\"Custom_UnionStyle\" align=\"center\"><img style=\"BORDER-LEFT-WIDTH: 0px; BORDER-RIGHT-WIDTH: 0px; BORDER-BOTTOM-WIDTH: 0px; BORDER-TOP-WIDTH: 0px\" src=\"http://news.tju.edu.cn/zx/ky/201510/W020151012611584761949.jpg\" width=\"800\" height=\"800\"></p>\r\n        <p class=\"Custom_UnionStyle\">　　本站讯（通讯员 郭帅）9月24至29日，生命科学学院派出代表队参加国际遗传工程机器设计竞赛（International Genetically Engineered Machine Competition，iGEM），队伍从全球的280多支参赛队伍中脱颖而出，共获得Best New Application Project、Best New Basic Part两个单项第一，一块金牌，以及Best New Composite Part提名奖。</p>\r\n        <p class=\"Custom_UnionStyle\">　　生命科学学院首次指导队伍参加比赛，参赛学生来自生命科学学院（王镐锋、韩博文、刘嘉舒、李宇辰、赵晴、汪洋、胡金鑫、宗俊杰）、化工学院（鲍东琪、迟恒、陈泽翔、韩轩、董雪梅、李树斌、张雨薇）、求是学部（邵可同、喻俊杰、王画、殷翔宇、彭一格、王晨茂）等。此代表队由生命科学学院杨海涛教授指导，王泽方老师协助指导，该项目以一种蛋白实现多种科研与生活方面的应用——芯片固定、蛋白纯化以及塑料降解，对蛋白的改造也让几项应用的商业化成为可能。参赛队员们利用寒暑假及节假日等休息时间，完成了文献检索，定题，设计，实验，建模，实践，网页制作等大量工作，反复讨论项目细节，不断改进与创新。最终在国际比赛中展现了我校本科生的精神风貌与精彩的科研成果。</p>\r\n        <p class=\"Custom_UnionStyle\">　　此次获得两个单项第一和一块金牌，不仅是对参赛队伍连日辛苦工作的肯定，更是向世界展示了天大学子的科研热情和创新精神。准备参赛的历程为本科生科技创新提供了挑战与锻炼的平台，开创性的成绩是为母校天津大学120周年华诞献上的最佳贺礼！</p>\r\n        <p class=\"Custom_UnionStyle\">　　iGEM始于2005年，每年由美国麻省理工学院（Massachusetts Institute of Technology，MIT）主办，是合成生物学（Synthetic Biology）领域的最高国际性学术竞赛。合成生物学试图重新设计现有的天然的生物系统，或是设计和构建人工生物组件和系统，其目的在于通过了解天然生物体系的运作机理来创造全新的生物体系。参赛的包括了哈佛大学、耶鲁大学、牛津大学、剑桥大学、麻省理工学院等世界顶尖学府派出的代表队。</p>\r\n        <p class=\"Custom_UnionStyle\" align=\"right\">　　（编辑 彭莉 学生编辑 李田田）</p>', '', '0', '1', '1444701925', '0');
INSERT INTO `onethink_media_article` VALUES ('12', '47', '0', '<h3 style=\"text-align: center;\">\r\n  聚青春 &nbsp; 塑英才</h3>\r\n<h3 style=\"text-align: center;\">\r\n  学院成功承办2015年天津市青工职业技能大赛</h3>\r\n<div>\r\n  <strong>&nbsp; &nbsp; &nbsp; &nbsp;（图文/团委通讯员 金轶皓）</strong>8月28、29日，天津市青工职业技能大赛暨第十一届“振兴杯”全国青年职业技能大赛天津赛区选拔赛在学院成功举行。</div>\r\n<div>\r\n  &nbsp; &nbsp; &nbsp; &nbsp;团中央城市部部长郭美荐、团市委副书记方伟、天津市人社局副局长、天津广播电视大学党委书记于茂东、天津中环电子信息集团有限公司纪委书记陈良、团市委青工部部长段海鹰等领导莅临现场指导工作，学院党委书记陈昀陪同考察。</div>\r\n<div style=\"text-align: center;\">\r\n  <img alt=\"\" src=\"http://www.tjdz.net/uploads/allimg/150922/3-15092210322Y43.jpg\" style=\"width: 553px; height: 311px;\"></div>\r\n<div style=\"text-align: center;\">\r\n  建筑结构设计师项目实操比赛现场</div>\r\n<div style=\"text-align: center;\">\r\n  <img alt=\"\" src=\"http://www.tjdz.net/uploads/allimg/150922/3-1509221032391Q.jpg\" style=\"width: 553px; height: 369px;\"></div>\r\n<div style=\"text-align: center;\">\r\n  快递业务员项目比赛现场</div>\r\n<div style=\"text-align: center;\">\r\n  <img alt=\"\" src=\"http://www.tjdz.net/uploads/allimg/150922/3-150922103250305.jpg\" style=\"width: 554px; height: 306px;\"></div>\r\n<div style=\"text-align: center;\">\r\n  电子商务师项目答辩现场</div>\r\n<div>\r\n  &nbsp; &nbsp; &nbsp; &nbsp;今年，学院承办了电子商务师、建筑结构设计师和快递业务员三个赛项，并选派计算机应用技术系王蓓和王佳两位教师参加电子商务师赛项比赛。近年来，学院教师参加青工技能大赛成绩骄人，有3位教师荣获天津市五一劳动奖章和新长征突击手称号。</div>\r\n<div>\r\n  &nbsp;</div>', '', '0', '1', '1444701925', '0');
INSERT INTO `onethink_media_article` VALUES ('13', '48', '0', '<div class=\"Custom_UnionStyle\">\r\n<p>　　<span>“如果用一句话来概括这部交响曲的内涵，那就是作者对‘独立之精神、自由之思想’的呼唤。”尽管，冯公让并不愿意用文字来更多地形容他创作的首部交响乐作品，因为音乐的魅力就在于它让任何文字的描述都显得苍白，一切都要交给耳朵和心灵。但谈及创作动因和历程，冯公让数次“情不自禁”地哽咽和激动，让我们看到了这部交响曲作者所要表达的对中国近代历史的反思，对近代高等教育的思索，对人性的或拷问、鞭挞或讴歌、赞美。</span></p>\r\n<p>　　<span>交响曲的创作，让这位年轻的作曲家经常彻夜难眠，他的情绪、他的神经甚至他的身体，都因为这部交响乐每个音符的诞生而压抑、彷徨、亢奋、颤抖。</span></p>\r\n<p>　　<span>这部交响乐共分四个乐章，创作历经</span><span>16</span><span>个月。冯公让坦诚，这</span><span>16</span><span>个月的创作过程对他来说，是一次次地洗礼自己的思想和精神。他读历史，看影像资料……很多时候，他的身体都在颤抖，不能自己，甚至情绪失控。</span></p>\r\n<p>　　<span>“如果一定要给这四个乐章‘冠上’一个主题的话，那第一乐章就是献给为救国兴邦而上下求索的仁人志士的。”冯公让谈到，危机、战争、灾难，是第一乐章的基调，但他并不想让“战争”在乐曲中“具象化”，他相信了解中国近代史的人都能听懂他要表达的情感，理解他在恰逢甲午战争</span><span>120</span><span>周年时再通过史籍和影像回顾那段历史时精神的痛苦和挣扎，也能理解他在创作过程中因为无法摆脱战争阴影而带来的恐惧和痛苦。</span></p>\r\n<p>　　<span>战争和黑暗让人恐惧，打破黑暗求索光明则需要极大的勇气和智慧。“天津大学前身北洋大学</span><span>1895</span><span>年建校，恰是中日甲午海战清廷战败后。它的诞生仿佛黑暗之中的一点光，明亮夺目，中国第一所现代大学的诞生是国人‘自强不息’精神写照，也是中国大学之精神。”冯公让坦诚，天津大学双甲子校庆让他产生了写一部交响乐的“献礼”的冲动，但他的作品却绝不局限于写天津大学，而是写百余年的中国近代史中人们对于国家和民族未来光明之求索。</span></p>\r\n<p>　　<span>第一乐章之后，冯公让创作的是第四乐章。“尽管整部作品的构思已比较清晰，但事实上在具体创作每个乐章时，我都遇到了特别大的困难，甚至有时候觉得寸步难行。”冯公让说，写完第一章后他开始着手创作第四乐章，同时也在脑海中反复敲打第二和第三乐章。</span></p>\r\n<p>　　<span>“第四乐章，我要写一种精神，一种‘自强不息’的精神。”冯公让说，这是他对于天津大学</span><span>120</span><span>年校史的理解，而给他创作灵感的则是</span><span>12</span><span>年前他从音乐学院毕业刚到天大工作时，看到青年湖上赛龙舟的震撼：“年轻人，光着膀子、敲着鼓、喊着号子，这样的场景正是一种合作精神、集体力量和自强不息精神的写照。”为了将这种“号子”表达出来，冯公让遍览各地龙舟号子，但最终却觉得任何一种“号子”都难以表达他想要的那种青春气息。最终，他借鉴了简约派的马达艺术，利用合唱和交响的配合，表达出了自己心中的这种青春昂扬的感受。在冯公让看来，“如果说第四乐章也是献礼的话，那就是献给继往开来者。”</span></p>\r\n<p>　　<span>第三章的创作让冯公让又陷入了一种矛盾、冲突、斗争和阴冷的氛围里，因为他写的是文革的十年浩劫，“我没有经历过这场浩劫，但我的母亲每每提起，都会忍不住流泪。我也看了很多写这段历史的书籍和音像资料，我能感受到我的内心在颤抖。”于是第三章的开篇便是一支长笛阴冷而空旷地呜咽宛转，奠定了整个篇章“冷”的基调。“第三章，我希望通过音乐为坚持真理、追求真理的勇士们唱一唱葬歌。”</span></p>\r\n<p>　　<span>《第一交响曲》的第二乐章描绘的则是新文化运动和五四运动中探索、求知的力量。“那种天不怕、地不怕的探索精神。”冯公让说，这是人们对于冲破黑暗、寻找光明的渴望，也正是这个国家和民族自强不息的探索。（本站记者刘晓艳）</span></p></div>', '', '0', '1', '1444701925', '0');
INSERT INTO `onethink_media_article` VALUES ('14', '49', '0', '<div class=\"Custom_UnionStyle\">\r\n<p align=\"center\">中航科工集团33所智能机器人研究室主任张新华</p>\r\n<p align=\"center\"><img style=\"BORDER-LEFT-WIDTH: 0px; BORDER-RIGHT-WIDTH: 0px; BORDER-BOTTOM-WIDTH: 0px; BORDER-TOP-WIDTH: 0px\" src=\"./W020150710324274294527.png\" oldsrc=\"W020150710324274294527.png\" _fcksavedurl=\"/webpic/W0201507/W020150710/W020150710324274294527.png\"></p>\r\n<p align=\"center\">《人民日报》 2014年12月04日　 06 版</p>\r\n<p align=\"center\"><img style=\"BORDER-LEFT-WIDTH: 0px; BORDER-RIGHT-WIDTH: 0px; BORDER-BOTTOM-WIDTH: 0px; BORDER-TOP-WIDTH: 0px\" src=\"./W020150710324274462763.jpg\" oldsrc=\"W020150710324274462763.jpg\" _fcksavedurl=\"/webpic/W0201507/W020150710/W020150710324274462763.jpg\"></p>\r\n<p>　　印刷机器人、切割机器人、装配机器人等各式各样的轻巧型工业机器人站成一排， “旋转、拨动、夹持、定位……”一气呵成，张新华得意地向大家展示他们为劳动密集型行业研制成功的系列化轻巧型机器人产品。</p>\r\n<p>　　张新华是中国航天科工集团公司三院33所智能机器人研究室主任，同事们说，新华是一个地地道道的“机器人迷”，一旦研究起机器人，他常常忘记下班。值得一提的是，张新华带领团队研制成功的装卸源机器人，可以实现放射源无人化装卸操作，被誉为我国首台应用于油田测井前线的航天“特种兵”。</p>\r\n<p>　　2002年3月，从天津大学机械设计及理论专业博士毕业的张新华应聘来到33所，初出茅庐就承担起了33所伺服系统的预研工作。扎实的理论功底和良好的专业技术让张新华很快脱颖而出。</p>\r\n<p>　　有一次，所里将一个重大难题交给张新华，他困了就趴在桌上歇会儿，晚上就睡在实验室的凳子上，经过40多天奋战，终于攻克了技术难关。此后，张新华先后担任多个型号伺服系统主任设计师，取得一系列成果。</p>\r\n<p>　　机遇偏爱有准备的头脑。2011年2月24日，伴随着国内外机器人研究的热潮，33所也成立了智能机器人研究室，38岁的张新华被任命为研究室主任。然而，机器人要搞起来很容易，但要在国内占有一席之地却并非易事。</p>\r\n<p>　　“我们的首要任务就是尽快找到合适的切入点。”张新华敏锐地意识到，确定发展方向决不能靠拍脑袋，必须走出去。张新华带领自己的团队在全国进行了长达一年的深入调研。“我们的研究方向经历了一个由发散到收敛的过程，很多方向的确定都是走出来和比出来的。比如轻巧型工业机器人最早并不是我们的重点方向，但张主任带队调研后发现，这种可以把人员从重复性劳动中解放出来的机器人市场潜力巨大，后来我们就将其调整为重点方向了。”研制人员王晓林的一番话道出了“走出去”的重要性。</p>\r\n<p>　　“我对机械还比较了解，但智能机器人研制是一项十分复杂的系统工程，必须进行大量学习和调研。”对于学习的重要性，张新华有着清醒的认识。</p>\r\n<p>　　2013年，中国市场共销售工业机器人近3.7万台，成为全球第一大工业机器人消费市场。国产工业机器人也异军突起，预计今年国产工业机器人销售总量将超过1.2万台，同比增长25%左右。</p>\r\n<p>　　面对发展如此快速的工业机器人市场，张新华兴奋地说：“我们要发扬航天精神，利用航天核心技术的独特优势，解决制约国内机器人发展的关键技术瓶颈，把我们的智能机器人产业做强做大，把我们智能机器人研究室打造成国内一流的研发团队。”</p>\r\n<p>　　人民日报：<a href=\"http://paper.people.com.cn/rmrb/html/2014-12/04/nw.D110000renmrb_20141204_6-06.htm\" _fcksavedurl=\"http://paper.people.com.cn/rmrb/html/2014-12/04/nw.D110000renmrb_20141204_6-06.htm\">http://paper.people.com.cn/rmrb/html/2014-12/04/nw.D110000renmrb_20141204_6-06.htm</a></p></div>', '', '0', '1', '1444701925', '0');
INSERT INTO `onethink_media_article` VALUES ('15', '8', '0', '<div class=\"Custom_UnionStyle\">\r\n<p align=\"center\"><img style=\"BORDER-LEFT-WIDTH: 0px; BORDER-RIGHT-WIDTH: 0px; BORDER-BOTTOM-WIDTH: 0px; BORDER-TOP-WIDTH: 0px\" src=\"./W020150714374333008944.jpg\" oldsrc=\"W020150714374333008944.jpg\" _fcksavedurl=\"/webpic/W0201507/W020150714/W020150714374333008944.jpg\"></p>\r\n<p align=\"center\">天大学生参观天津市规划展览馆</p>\r\n<p align=\"center\"><img style=\"BORDER-LEFT-WIDTH: 0px; BORDER-RIGHT-WIDTH: 0px; BORDER-BOTTOM-WIDTH: 0px; BORDER-TOP-WIDTH: 0px\" src=\"./W020150714374333060320.jpg\" oldsrc=\"W020150714374333060320.jpg\" _fcksavedurl=\"/webpic/W0201507/W020150714/W020150714374333060320.jpg\"></p>\r\n<p align=\"center\">天大学生参观海鸥手表厂</p>\r\n<p align=\"center\"><img style=\"BORDER-LEFT-WIDTH: 0px; BORDER-RIGHT-WIDTH: 0px; BORDER-BOTTOM-WIDTH: 0px; BORDER-TOP-WIDTH: 0px\" src=\"./W020150714374333118932.jpg\" oldsrc=\"W020150714374333118932.jpg\" _fcksavedurl=\"/webpic/W0201507/W020150714/W020150714374333118932.jpg\"></p>\r\n<p align=\"center\">天大学子参观天津国际生物医药联合研究院</p>\r\n<p align=\"center\"><img style=\"BORDER-LEFT-WIDTH: 0px; BORDER-RIGHT-WIDTH: 0px; BORDER-BOTTOM-WIDTH: 0px; BORDER-TOP-WIDTH: 0px\" src=\"./W020150714374333164705.jpg\" oldsrc=\"W020150714374333164705.jpg\" _fcksavedurl=\"/webpic/W0201507/W020150714/W020150714374333164705.jpg\"></p>\r\n<p align=\"center\">天大学生参观国家超级计算机天津中心</p>\r\n<p align=\"center\"><img style=\"BORDER-LEFT-WIDTH: 0px; BORDER-RIGHT-WIDTH: 0px; BORDER-BOTTOM-WIDTH: 0px; BORDER-TOP-WIDTH: 0px\" src=\"./W020150714374333215113.jpg\" oldsrc=\"W020150714374333215113.jpg\" _fcksavedurl=\"/webpic/W0201507/W020150714/W020150714374333215113.jpg\"></p>\r\n<p align=\"center\">天大学生参观建设中的于家堡高铁站</p>\r\n<p align=\"center\"><img style=\"BORDER-LEFT-WIDTH: 0px; BORDER-RIGHT-WIDTH: 0px; BORDER-BOTTOM-WIDTH: 0px; BORDER-TOP-WIDTH: 0px\" src=\"./W020150714374333269134.jpg\" oldsrc=\"W020150714374333269134.jpg\" _fcksavedurl=\"/webpic/W0201507/W020150714/W020150714374333269134.jpg\"></p>\r\n<p align=\"center\">天大学生乘船参观海河综合治理改造工程</p>\r\n<p>　　<span>本站讯（学生记者 </span><span>杨洪涛 </span><span>记者 </span><span>朱宝琳 </span><span>摄影 </span><span>赵珺鹏 </span><span>聂婷娟）</span><span>6</span><span>月</span><span>26</span><span>日，百余名天津大学优秀学子应天津市委代理书记、市长黄兴国的邀请，在市委、市政府相关部门的精心安排下，进行了为期一天的“天大学子津门行”活动。参观途中，学生们实地了解了天津的发展规划和突出成就，不时发出阵阵惊叹和掌声，他们被天津的历史文化之美、城市建设之美、未来前景之美所吸引、震撼，“民族自尊心和自信心一次次爆棚”。</span></p>\r\n<p>　　<span>当日行程紧凑、充实，天大学子依次考察了天津市规划展览馆、中科院天津工业生物技术研究所、空客</span><span>A320</span><span>天津总装项目、海鸥手表厂、天津自贸试验区东疆港区服务大厅（途径东疆湾沙滩、邮轮母港、天津港太平洋国际集装箱码头）、天津国际生物医药联合研究院、国家超级计算机天津中心、于家堡高铁站、滨海新区中心商务区、海河教育园区中国（天津）职业技能公共实训中心、天津文化中心，并乘船参观海河综合治理改造工程。从展览场馆到研究院所，从企业公司到文化中心，天津的发展情况一览无遗。</span></p>\r\n<p>　　<span>“来天津七八年了，每次看展览都有新变化，新惊喜。”来自管理与经济学部目前主修工商管理的宋瑶在参观完天津市规划展览馆后感慨。宋瑶在天津大学从本科一直读到博士，天津是她的第二故乡。父母以前很希望她回家乡辽宁工作，但是现在天津和辽宁之间通了高铁，两个小时就可以回家看看，因此父母也就不再要求女儿回家乡了。宋瑶学习研究的是区域经济发展规划，对于天津和自己的发展她很有信心：“我在学校参与了科技孵化器项目，得到了政策资金各方面的支持。将来工作了我希望做自己擅长并感兴趣的事情——把技术和经济结合起来。天津的科技型中小企业很多，这些‘小巨人’助力天津发展也给我们提供了大量的机会。这次</span><span>360</span><span>度全方位无死角的考察，特别是看到滨海新区的发展，更加坚定了我留在天津的决心，和天津一起成长。”</span></p>\r\n<p>　　<span>天津国际邮轮母港的客运大厦的外形就像一艘大型邮轮，引起建工学院水利工程专业硕士生杨旭的巨大兴趣，他说：“我本科阶段主修港口方面的知识，以前参观的都是货港，这次来到邮轮港口，听人介绍</span><span>15</span><span>层高、内部构造精细的邮轮，特别震撼。”谈起天津的建设与自己的关系，他说：“天津的港口发展很快，虽然东疆、北疆已经建设好了，但是南疆正在建设中，有很多机会，我会优先考虑在天津发展。”</span></p>\r\n<p>　　<span>在国家超级计算机天津中心，大家纷纷与在</span><span>2010</span><span>年运算速度世界排名第一的“天河一号”合影留念。超算中心为全国科研机构和央企提供高性能计算服务，来自管理与经济学部金融学的何枫就领略过它的魅力——“在天大有一个分中心提供计算接口，我们做市场模型试验，普通电脑运算很慢要一两天，但是超级计算机要快得多，节省时间可以更快将成果推广出去。”</span><span>何枫平时做过很多情景模拟以减少金融风险的试验，他希望发挥自己的专业特长优势，将来在天津高校或金融机构工作。</span></p>\r\n<p>　　<span>于家堡高铁站将于今年</span><span>8</span><span>月投入试运营，届时，从北京南站到天津自贸区只需</span><span>45</span><span>分钟。于家堡站的椭圆形壳体像一个美丽的贝壳，而在它的设计建设过程中，天大师生也参与进来。建筑学院艺术设计专业的本科生钱丰就跟着导师为高铁站消防方面提供技术支持，“我们查阅了大量的资料进行分析设计，最大的收获是把学习和实践结合起来，而且对滨海新区的发展有了深入的认识。”此外，钱丰还参与了天津支援西藏的一个项目，到昌都小学建设科技活动室，把</span><span>3D</span><span>打印等科技带到边远山区，让那里的孩子也切身感受到创新的魅力。由于高原上作业困难，所以钱丰采用“模块化”设计活动室，在满足展示科技成果的同时力求简捷，他说“我们不仅要学习知识，更应该把它投入到社会服务中去。”</span></p>\r\n<p>　　<span>在滨海新区中心商务区，学生了解到，商务区内布局了总部经济、金融创新、科技与新一代信息技术、跨境贸易电子商务、文化传媒创意等产业。滨海新区的发展也为大学生创业提供了许多机会和优惠政策，环境学院环境规划专业的研究生崔元彰就紧跟“大众创业、万众创新”“互联网</span><span>+</span><span>”的时代潮流，拥有了自己的创业项目，他表示，我们要勇敢地去实现自己的梦想。</span></p>\r\n<p>　　<span>当晚，天津市委代理书记、市长黄兴国及相关市领导，天津大学党委书记刘建平、校长李家俊与学子们共进晚餐，亲切交谈。学生们表示，这一天不虚此行，对天津的发展充满信心，希望把天津作为自己的职业启航之地，实现自我价值。</span></p>\r\n<p>　　<span>参与“天大学子津门行”活动的一百名学生是在众多报名者中筛选出来的，为了让广大学生了解本次活动，大家把考察情况和自己的感悟分享给天津大学官方微博、微信进行了“直播”，让更多的人了解天津、爱上天津，与天津一起成长。</span></p></div>', '', '0', '1', '1444701925', '0');
INSERT INTO `onethink_media_article` VALUES ('16', '7', '0', '<p class=\"Custom_UnionStyle\" align=\"center\"><img style=\"BORDER-LEFT-WIDTH: 0px; BORDER-RIGHT-WIDTH: 0px; BORDER-BOTTOM-WIDTH: 0px; BORDER-TOP-WIDTH: 0px\" src=\"http://news.tju.edu.cn/zx/ky/201510/W020151012611584761949.jpg\" width=\"800\" height=\"800\"></p>\r\n        <p class=\"Custom_UnionStyle\">　　本站讯（通讯员 郭帅）9月24至29日，生命科学学院派出代表队参加国际遗传工程机器设计竞赛（International Genetically Engineered Machine Competition，iGEM），队伍从全球的280多支参赛队伍中脱颖而出，共获得Best New Application Project、Best New Basic Part两个单项第一，一块金牌，以及Best New Composite Part提名奖。</p>\r\n        <p class=\"Custom_UnionStyle\">　　生命科学学院首次指导队伍参加比赛，参赛学生来自生命科学学院（王镐锋、韩博文、刘嘉舒、李宇辰、赵晴、汪洋、胡金鑫、宗俊杰）、化工学院（鲍东琪、迟恒、陈泽翔、韩轩、董雪梅、李树斌、张雨薇）、求是学部（邵可同、喻俊杰、王画、殷翔宇、彭一格、王晨茂）等。此代表队由生命科学学院杨海涛教授指导，王泽方老师协助指导，该项目以一种蛋白实现多种科研与生活方面的应用——芯片固定、蛋白纯化以及塑料降解，对蛋白的改造也让几项应用的商业化成为可能。参赛队员们利用寒暑假及节假日等休息时间，完成了文献检索，定题，设计，实验，建模，实践，网页制作等大量工作，反复讨论项目细节，不断改进与创新。最终在国际比赛中展现了我校本科生的精神风貌与精彩的科研成果。</p>\r\n        <p class=\"Custom_UnionStyle\">　　此次获得两个单项第一和一块金牌，不仅是对参赛队伍连日辛苦工作的肯定，更是向世界展示了天大学子的科研热情和创新精神。准备参赛的历程为本科生科技创新提供了挑战与锻炼的平台，开创性的成绩是为母校天津大学120周年华诞献上的最佳贺礼！</p>\r\n        <p class=\"Custom_UnionStyle\">　　iGEM始于2005年，每年由美国麻省理工学院（Massachusetts Institute of Technology，MIT）主办，是合成生物学（Synthetic Biology）领域的最高国际性学术竞赛。合成生物学试图重新设计现有的天然的生物系统，或是设计和构建人工生物组件和系统，其目的在于通过了解天然生物体系的运作机理来创造全新的生物体系。参赛的包括了哈佛大学、耶鲁大学、牛津大学、剑桥大学、麻省理工学院等世界顶尖学府派出的代表队。</p>\r\n        <p class=\"Custom_UnionStyle\" align=\"right\">　　（编辑 彭莉 学生编辑 李田田）</p>', '', '0', '1', '1444701925', '0');
INSERT INTO `onethink_media_article` VALUES ('17', '6', '0', '<h3 style=\"text-align: center;\">\r\n  聚青春 &nbsp; 塑英才</h3>\r\n<h3 style=\"text-align: center;\">\r\n  学院成功承办2015年天津市青工职业技能大赛</h3>\r\n<div>\r\n  <strong>&nbsp; &nbsp; &nbsp; &nbsp;（图文/团委通讯员 金轶皓）</strong>8月28、29日，天津市青工职业技能大赛暨第十一届“振兴杯”全国青年职业技能大赛天津赛区选拔赛在学院成功举行。</div>\r\n<div>\r\n  &nbsp; &nbsp; &nbsp; &nbsp;团中央城市部部长郭美荐、团市委副书记方伟、天津市人社局副局长、天津广播电视大学党委书记于茂东、天津中环电子信息集团有限公司纪委书记陈良、团市委青工部部长段海鹰等领导莅临现场指导工作，学院党委书记陈昀陪同考察。</div>\r\n<div style=\"text-align: center;\">\r\n  <img alt=\"\" src=\"http://www.tjdz.net/uploads/allimg/150922/3-15092210322Y43.jpg\" style=\"width: 553px; height: 311px;\"></div>\r\n<div style=\"text-align: center;\">\r\n  建筑结构设计师项目实操比赛现场</div>\r\n<div style=\"text-align: center;\">\r\n  <img alt=\"\" src=\"http://www.tjdz.net/uploads/allimg/150922/3-1509221032391Q.jpg\" style=\"width: 553px; height: 369px;\"></div>\r\n<div style=\"text-align: center;\">\r\n  快递业务员项目比赛现场</div>\r\n<div style=\"text-align: center;\">\r\n  <img alt=\"\" src=\"http://www.tjdz.net/uploads/allimg/150922/3-150922103250305.jpg\" style=\"width: 554px; height: 306px;\"></div>\r\n<div style=\"text-align: center;\">\r\n  电子商务师项目答辩现场</div>\r\n<div>\r\n  &nbsp; &nbsp; &nbsp; &nbsp;今年，学院承办了电子商务师、建筑结构设计师和快递业务员三个赛项，并选派计算机应用技术系王蓓和王佳两位教师参加电子商务师赛项比赛。近年来，学院教师参加青工技能大赛成绩骄人，有3位教师荣获天津市五一劳动奖章和新长征突击手称号。</div>\r\n<div>\r\n  &nbsp;</div>', '', '0', '1', '1444701925', '0');
INSERT INTO `onethink_media_article` VALUES ('18', '5', '0', '<div class=\"Custom_UnionStyle\">\r\n<p>　　<span>“如果用一句话来概括这部交响曲的内涵，那就是作者对‘独立之精神、自由之思想’的呼唤。”尽管，冯公让并不愿意用文字来更多地形容他创作的首部交响乐作品，因为音乐的魅力就在于它让任何文字的描述都显得苍白，一切都要交给耳朵和心灵。但谈及创作动因和历程，冯公让数次“情不自禁”地哽咽和激动，让我们看到了这部交响曲作者所要表达的对中国近代历史的反思，对近代高等教育的思索，对人性的或拷问、鞭挞或讴歌、赞美。</span></p>\r\n<p>　　<span>交响曲的创作，让这位年轻的作曲家经常彻夜难眠，他的情绪、他的神经甚至他的身体，都因为这部交响乐每个音符的诞生而压抑、彷徨、亢奋、颤抖。</span></p>\r\n<p>　　<span>这部交响乐共分四个乐章，创作历经</span><span>16</span><span>个月。冯公让坦诚，这</span><span>16</span><span>个月的创作过程对他来说，是一次次地洗礼自己的思想和精神。他读历史，看影像资料……很多时候，他的身体都在颤抖，不能自己，甚至情绪失控。</span></p>\r\n<p>　　<span>“如果一定要给这四个乐章‘冠上’一个主题的话，那第一乐章就是献给为救国兴邦而上下求索的仁人志士的。”冯公让谈到，危机、战争、灾难，是第一乐章的基调，但他并不想让“战争”在乐曲中“具象化”，他相信了解中国近代史的人都能听懂他要表达的情感，理解他在恰逢甲午战争</span><span>120</span><span>周年时再通过史籍和影像回顾那段历史时精神的痛苦和挣扎，也能理解他在创作过程中因为无法摆脱战争阴影而带来的恐惧和痛苦。</span></p>\r\n<p>　　<span>战争和黑暗让人恐惧，打破黑暗求索光明则需要极大的勇气和智慧。“天津大学前身北洋大学</span><span>1895</span><span>年建校，恰是中日甲午海战清廷战败后。它的诞生仿佛黑暗之中的一点光，明亮夺目，中国第一所现代大学的诞生是国人‘自强不息’精神写照，也是中国大学之精神。”冯公让坦诚，天津大学双甲子校庆让他产生了写一部交响乐的“献礼”的冲动，但他的作品却绝不局限于写天津大学，而是写百余年的中国近代史中人们对于国家和民族未来光明之求索。</span></p>\r\n<p>　　<span>第一乐章之后，冯公让创作的是第四乐章。“尽管整部作品的构思已比较清晰，但事实上在具体创作每个乐章时，我都遇到了特别大的困难，甚至有时候觉得寸步难行。”冯公让说，写完第一章后他开始着手创作第四乐章，同时也在脑海中反复敲打第二和第三乐章。</span></p>\r\n<p>　　<span>“第四乐章，我要写一种精神，一种‘自强不息’的精神。”冯公让说，这是他对于天津大学</span><span>120</span><span>年校史的理解，而给他创作灵感的则是</span><span>12</span><span>年前他从音乐学院毕业刚到天大工作时，看到青年湖上赛龙舟的震撼：“年轻人，光着膀子、敲着鼓、喊着号子，这样的场景正是一种合作精神、集体力量和自强不息精神的写照。”为了将这种“号子”表达出来，冯公让遍览各地龙舟号子，但最终却觉得任何一种“号子”都难以表达他想要的那种青春气息。最终，他借鉴了简约派的马达艺术，利用合唱和交响的配合，表达出了自己心中的这种青春昂扬的感受。在冯公让看来，“如果说第四乐章也是献礼的话，那就是献给继往开来者。”</span></p>\r\n<p>　　<span>第三章的创作让冯公让又陷入了一种矛盾、冲突、斗争和阴冷的氛围里，因为他写的是文革的十年浩劫，“我没有经历过这场浩劫，但我的母亲每每提起，都会忍不住流泪。我也看了很多写这段历史的书籍和音像资料，我能感受到我的内心在颤抖。”于是第三章的开篇便是一支长笛阴冷而空旷地呜咽宛转，奠定了整个篇章“冷”的基调。“第三章，我希望通过音乐为坚持真理、追求真理的勇士们唱一唱葬歌。”</span></p>\r\n<p>　　<span>《第一交响曲》的第二乐章描绘的则是新文化运动和五四运动中探索、求知的力量。“那种天不怕、地不怕的探索精神。”冯公让说，这是人们对于冲破黑暗、寻找光明的渴望，也正是这个国家和民族自强不息的探索。（本站记者刘晓艳）</span></p></div>', '', '0', '1', '1444701925', '0');
INSERT INTO `onethink_media_article` VALUES ('19', '4', '0', '<div class=\"Custom_UnionStyle\">\r\n<p align=\"center\">中航科工集团33所智能机器人研究室主任张新华</p>\r\n<p align=\"center\"><img style=\"BORDER-LEFT-WIDTH: 0px; BORDER-RIGHT-WIDTH: 0px; BORDER-BOTTOM-WIDTH: 0px; BORDER-TOP-WIDTH: 0px\" src=\"./W020150710324274294527.png\" oldsrc=\"W020150710324274294527.png\" _fcksavedurl=\"/webpic/W0201507/W020150710/W020150710324274294527.png\"></p>\r\n<p align=\"center\">《人民日报》 2014年12月04日　 06 版</p>\r\n<p align=\"center\"><img style=\"BORDER-LEFT-WIDTH: 0px; BORDER-RIGHT-WIDTH: 0px; BORDER-BOTTOM-WIDTH: 0px; BORDER-TOP-WIDTH: 0px\" src=\"./W020150710324274462763.jpg\" oldsrc=\"W020150710324274462763.jpg\" _fcksavedurl=\"/webpic/W0201507/W020150710/W020150710324274462763.jpg\"></p>\r\n<p>　　印刷机器人、切割机器人、装配机器人等各式各样的轻巧型工业机器人站成一排， “旋转、拨动、夹持、定位……”一气呵成，张新华得意地向大家展示他们为劳动密集型行业研制成功的系列化轻巧型机器人产品。</p>\r\n<p>　　张新华是中国航天科工集团公司三院33所智能机器人研究室主任，同事们说，新华是一个地地道道的“机器人迷”，一旦研究起机器人，他常常忘记下班。值得一提的是，张新华带领团队研制成功的装卸源机器人，可以实现放射源无人化装卸操作，被誉为我国首台应用于油田测井前线的航天“特种兵”。</p>\r\n<p>　　2002年3月，从天津大学机械设计及理论专业博士毕业的张新华应聘来到33所，初出茅庐就承担起了33所伺服系统的预研工作。扎实的理论功底和良好的专业技术让张新华很快脱颖而出。</p>\r\n<p>　　有一次，所里将一个重大难题交给张新华，他困了就趴在桌上歇会儿，晚上就睡在实验室的凳子上，经过40多天奋战，终于攻克了技术难关。此后，张新华先后担任多个型号伺服系统主任设计师，取得一系列成果。</p>\r\n<p>　　机遇偏爱有准备的头脑。2011年2月24日，伴随着国内外机器人研究的热潮，33所也成立了智能机器人研究室，38岁的张新华被任命为研究室主任。然而，机器人要搞起来很容易，但要在国内占有一席之地却并非易事。</p>\r\n<p>　　“我们的首要任务就是尽快找到合适的切入点。”张新华敏锐地意识到，确定发展方向决不能靠拍脑袋，必须走出去。张新华带领自己的团队在全国进行了长达一年的深入调研。“我们的研究方向经历了一个由发散到收敛的过程，很多方向的确定都是走出来和比出来的。比如轻巧型工业机器人最早并不是我们的重点方向，但张主任带队调研后发现，这种可以把人员从重复性劳动中解放出来的机器人市场潜力巨大，后来我们就将其调整为重点方向了。”研制人员王晓林的一番话道出了“走出去”的重要性。</p>\r\n<p>　　“我对机械还比较了解，但智能机器人研制是一项十分复杂的系统工程，必须进行大量学习和调研。”对于学习的重要性，张新华有着清醒的认识。</p>\r\n<p>　　2013年，中国市场共销售工业机器人近3.7万台，成为全球第一大工业机器人消费市场。国产工业机器人也异军突起，预计今年国产工业机器人销售总量将超过1.2万台，同比增长25%左右。</p>\r\n<p>　　面对发展如此快速的工业机器人市场，张新华兴奋地说：“我们要发扬航天精神，利用航天核心技术的独特优势，解决制约国内机器人发展的关键技术瓶颈，把我们的智能机器人产业做强做大，把我们智能机器人研究室打造成国内一流的研发团队。”</p>\r\n<p>　　人民日报：<a href=\"http://paper.people.com.cn/rmrb/html/2014-12/04/nw.D110000renmrb_20141204_6-06.htm\" _fcksavedurl=\"http://paper.people.com.cn/rmrb/html/2014-12/04/nw.D110000renmrb_20141204_6-06.htm\">http://paper.people.com.cn/rmrb/html/2014-12/04/nw.D110000renmrb_20141204_6-06.htm</a></p></div>', '', '0', '1', '1444701925', '0');
INSERT INTO `onethink_media_article` VALUES ('20', '3', '0', '<div class=\"Custom_UnionStyle\">\r\n	<p align=\"center\">\r\n		<br />\r\n	</p>\r\n	<p align=\"center\">\r\n		天大学生乘船参观海河综合治理改造工程\r\n	</p>\r\n	<p>\r\n		　　<span>本站讯（学生记者 </span><span>杨洪涛 </span><span>记者 </span><span>朱宝琳 </span><span>摄影 </span><span>赵珺鹏 </span><span>聂婷娟）</span><span>6</span><span>月</span><span>26</span><span>日，百余名天津大学优秀学子应天津市委代理书记、市长黄兴国的邀请，在市委、市政府相关部门的精心安排下，进行了为期一天的“天大学子津门行”活动。参观途中，学生们实地了解了天津的发展规划和突出成就，不时发出阵阵惊叹和掌声，他们被天津的历史文化之美、城市建设之美、未来前景之美所吸引、震撼，“民族自尊心和自信心一次次爆棚”。</span> \r\n	</p>\r\n	<p>\r\n		　　<span>当日行程紧凑、充实，天大学子依次考察了天津市规划展览馆、中科院天津工业生物技术研究所、空客</span><span>A320</span><span>天津总装项目、海鸥手表厂、天津自贸试验区东疆港区服务大厅（途径东疆湾沙滩、邮轮母港、天津港太平洋国际集装箱码头）、天津国际生物医药联合研究院、国家超级计算机天津中心、于家堡高铁站、滨海新区中心商务区、海河教育园区中国（天津）职业技能公共实训中心、天津文化中心，并乘船参观海河综合治理改造工程。从展览场馆到研究院所，从企业公司到文化中心，天津的发展情况一览无遗。</span> \r\n	</p>\r\n	<p>\r\n		　　<span>“来天津七八年了，每次看展览都有新变化，新惊喜。”来自管理与经济学部目前主修工商管理的宋瑶在参观完天津市规划展览馆后感慨。宋瑶在天津大学从本科一直读到博士，天津是她的第二故乡。父母以前很希望她回家乡辽宁工作，但是现在天津和辽宁之间通了高铁，两个小时就可以回家看看，因此父母也就不再要求女儿回家乡了。宋瑶学习研究的是区域经济发展规划，对于天津和自己的发展她很有信心：“我在学校参与了科技孵化器项目，得到了政策资金各方面的支持。将来工作了我希望做自己擅长并感兴趣的事情——把技术和经济结合起来。天津的科技型中小企业很多，这些‘小巨人’助力天津发展也给我们提供了大量的机会。这次</span><span>360</span><span>度全方位无死角的考察，特别是看到滨海新区的发展，更加坚定了我留在天津的决心，和天津一起成长。”</span> \r\n	</p>\r\n	<p>\r\n		　　<span>天津国际邮轮母港的客运大厦的外形就像一艘大型邮轮，引起建工学院水利工程专业硕士生杨旭的巨大兴趣，他说：“我本科阶段主修港口方面的知识，以前参观的都是货港，这次来到邮轮港口，听人介绍</span><span>15</span><span>层高、内部构造精细的邮轮，特别震撼。”谈起天津的建设与自己的关系，他说：“天津的港口发展很快，虽然东疆、北疆已经建设好了，但是南疆正在建设中，有很多机会，我会优先考虑在天津发展。”</span> \r\n	</p>\r\n	<p>\r\n		　　<span>在国家超级计算机天津中心，大家纷纷与在</span><span>2010</span><span>年运算速度世界排名第一的“天河一号”合影留念。超算中心为全国科研机构和央企提供高性能计算服务，来自管理与经济学部金融学的何枫就领略过它的魅力——“在天大有一个分中心提供计算接口，我们做市场模型试验，普通电脑运算很慢要一两天，但是超级计算机要快得多，节省时间可以更快将成果推广出去。”</span><span>何枫平时做过很多情景模拟以减少金融风险的试验，他希望发挥自己的专业特长优势，将来在天津高校或金融机构工作。</span> \r\n	</p>\r\n	<p>\r\n		　　<span>于家堡高铁站将于今年</span><span>8</span><span>月投入试运营，届时，从北京南站到天津自贸区只需</span><span>45</span><span>分钟。于家堡站的椭圆形壳体像一个美丽的贝壳，而在它的设计建设过程中，天大师生也参与进来。建筑学院艺术设计专业的本科生钱丰就跟着导师为高铁站消防方面提供技术支持，“我们查阅了大量的资料进行分析设计，最大的收获是把学习和实践结合起来，而且对滨海新区的发展有了深入的认识。”此外，钱丰还参与了天津支援西藏的一个项目，到昌都小学建设科技活动室，把</span><span>3D</span><span>打印等科技带到边远山区，让那里的孩子也切身感受到创新的魅力。由于高原上作业困难，所以钱丰采用“模块化”设计活动室，在满足展示科技成果的同时力求简捷，他说“我们不仅要学习知识，更应该把它投入到社会服务中去。”</span> \r\n	</p>\r\n	<p>\r\n		　　<span>在滨海新区中心商务区，学生了解到，商务区内布局了总部经济、金融创新、科技与新一代信息技术、跨境贸易电子商务、文化传媒创意等产业。滨海新区的发展也为大学生创业提供了许多机会和优惠政策，环境学院环境规划专业的研究生崔元彰就紧跟“大众创业、万众创新”“互联网</span><span>+</span><span>”的时代潮流，拥有了自己的创业项目，他表示，我们要勇敢地去实现自己的梦想。</span> \r\n	</p>\r\n	<p>\r\n		　　<span>当晚，天津市委代理书记、市长黄兴国及相关市领导，天津大学党委书记刘建平、校长李家俊与学子们共进晚餐，亲切交谈。学生们表示，这一天不虚此行，对天津的发展充满信心，希望把天津作为自己的职业启航之地，实现自我价值。</span> \r\n	</p>\r\n	<p>\r\n		　　<span>参与“天大学子津门行”活动的一百名学生是在众多报名者中筛选出来的，为了让广大学生了解本次活动，大家把考察情况和自己的感悟分享给天津大学官方微博、微信进行了“直播”，让更多的人了解天津、爱上天津，与天津一起成长。</span> \r\n	</p>\r\n</div>', '', '4', '1', '1444701925', '0');
INSERT INTO `onethink_media_article` VALUES ('21', '2', '0', '<p class=\"Custom_UnionStyle\" align=\"center\"><img style=\"BORDER-LEFT-WIDTH: 0px; BORDER-RIGHT-WIDTH: 0px; BORDER-BOTTOM-WIDTH: 0px; BORDER-TOP-WIDTH: 0px\" src=\"http://news.tju.edu.cn/zx/ky/201510/W020151012611584761949.jpg\" width=\"800\" height=\"800\"></p>\r\n        <p class=\"Custom_UnionStyle\">　　本站讯（通讯员 郭帅）9月24至29日，生命科学学院派出代表队参加国际遗传工程机器设计竞赛（International Genetically Engineered Machine Competition，iGEM），队伍从全球的280多支参赛队伍中脱颖而出，共获得Best New Application Project、Best New Basic Part两个单项第一，一块金牌，以及Best New Composite Part提名奖。</p>\r\n        <p class=\"Custom_UnionStyle\">　　生命科学学院首次指导队伍参加比赛，参赛学生来自生命科学学院（王镐锋、韩博文、刘嘉舒、李宇辰、赵晴、汪洋、胡金鑫、宗俊杰）、化工学院（鲍东琪、迟恒、陈泽翔、韩轩、董雪梅、李树斌、张雨薇）、求是学部（邵可同、喻俊杰、王画、殷翔宇、彭一格、王晨茂）等。此代表队由生命科学学院杨海涛教授指导，王泽方老师协助指导，该项目以一种蛋白实现多种科研与生活方面的应用——芯片固定、蛋白纯化以及塑料降解，对蛋白的改造也让几项应用的商业化成为可能。参赛队员们利用寒暑假及节假日等休息时间，完成了文献检索，定题，设计，实验，建模，实践，网页制作等大量工作，反复讨论项目细节，不断改进与创新。最终在国际比赛中展现了我校本科生的精神风貌与精彩的科研成果。</p>\r\n        <p class=\"Custom_UnionStyle\">　　此次获得两个单项第一和一块金牌，不仅是对参赛队伍连日辛苦工作的肯定，更是向世界展示了天大学子的科研热情和创新精神。准备参赛的历程为本科生科技创新提供了挑战与锻炼的平台，开创性的成绩是为母校天津大学120周年华诞献上的最佳贺礼！</p>\r\n        <p class=\"Custom_UnionStyle\">　　iGEM始于2005年，每年由美国麻省理工学院（Massachusetts Institute of Technology，MIT）主办，是合成生物学（Synthetic Biology）领域的最高国际性学术竞赛。合成生物学试图重新设计现有的天然的生物系统，或是设计和构建人工生物组件和系统，其目的在于通过了解天然生物体系的运作机理来创造全新的生物体系。参赛的包括了哈佛大学、耶鲁大学、牛津大学、剑桥大学、麻省理工学院等世界顶尖学府派出的代表队。</p>\r\n        <p class=\"Custom_UnionStyle\" align=\"right\">　　（编辑 彭莉 学生编辑 李田田）</p>', '', '0', '1', '1444701925', '0');
INSERT INTO `onethink_media_article` VALUES ('22', '1', '0', '<h3 style=\"text-align:center;\">\r\n	聚青春 &nbsp; 塑英才\r\n</h3>\r\n<h3 style=\"text-align:center;\">\r\n	学院成功承办2015年天津市青工职业技能大赛\r\n</h3>\r\n<div>\r\n	<strong>&nbsp; &nbsp; &nbsp; &nbsp;（图文/团委通讯员 金轶皓）</strong>8月28、29日，天津市青工职业技能大赛暨第十一届“振兴杯”全国青年职业技能大赛天津赛区选拔赛在学院成功举行。\r\n</div>\r\n<div>\r\n	&nbsp; &nbsp; &nbsp; &nbsp;团中央城市部部长郭美荐、团市委副书记方伟、天津市人社局副局长、天津广播电视大学党委书记于茂东、天津中环电子信息集团有限公司纪委书记陈良、团市委青工部部长段海鹰等领导莅临现场指导工作，学院党委书记陈昀陪同考察。\r\n</div>\r\n<div style=\"text-align:center;\">\r\n	<img src=\"/wwwroot/Uploads/Editor/2015-10-29/563218194b003.jpg\" alt=\"\" /><br />\r\n</div>\r\n<div style=\"text-align:center;\">\r\n	建筑结构设计师项目实操比赛现场\r\n</div>\r\n<div style=\"text-align:center;\">\r\n	<img alt=\"\" src=\"http://www.tjdz.net/uploads/allimg/150922/3-1509221032391Q.jpg\" style=\"width:553px;height:369px;\" />\r\n</div>\r\n<div style=\"text-align:center;\">\r\n	快递业务员项目比赛现场\r\n</div>\r\n<div style=\"text-align:center;\">\r\n	<img alt=\"\" src=\"http://www.tjdz.net/uploads/allimg/150922/3-150922103250305.jpg\" style=\"width:554px;height:306px;\" />\r\n</div>\r\n<div style=\"text-align:center;\">\r\n	电子商务师项目答辩现场\r\n</div>\r\n<div>\r\n	&nbsp; &nbsp; &nbsp; &nbsp;今年，学院承办了电子商务师、建筑结构设计师和快递业务员三个赛项，并选派计算机应用技术系王蓓和王佳两位教师参加电子商务师赛项比赛。近年来，学院教师参加青工技能大赛成绩骄人，有3位教师荣获天津市五一劳动奖章和新长征突击手称号。\r\n</div>\r\n<div>\r\n	&nbsp;\r\n</div>', '', '0', '1', '1444701925', '0');

-- -----------------------------
-- Table structure for `onethink_media_data`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_media_data`;
CREATE TABLE `onethink_media_data` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `type` tinyint(4) NOT NULL COMMENT '所属分类： 0其他 1新闻 2教学 3图文',
  `group` tinyint(4) NOT NULL COMMENT '所属分类: ',
  `title` varchar(20) COLLATE utf8_bin NOT NULL COMMENT '标题',
  `tab` int(11) unsigned DEFAULT NULL COMMENT '标签',
  `synopsis` varchar(160) COLLATE utf8_bin NOT NULL COMMENT '简介',
  `img` varchar(255) COLLATE utf8_bin NOT NULL COMMENT '图片',
  `create_time` int(10) unsigned NOT NULL COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL COMMENT '修改时间',
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '状态（-1：已删除，0：禁用，1：正常）',
  `sort` smallint(3) unsigned DEFAULT '0' COMMENT '排序',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=60 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- -----------------------------
-- Records of `onethink_media_data`
-- -----------------------------
INSERT INTO `onethink_media_data` VALUES ('1', '1', '1', '世界那么大，后台那么新，教你如何不迷失~', '', ' 肇基学府三世纪，兴学强国百廿年。10月2日，中国第一所现代大学――天津大学（北洋大学）举行了建校120周年庆祝大会。', '4', '1443714500', '1443714542', '1', '0');
INSERT INTO `onethink_media_data` VALUES ('2', '1', '1', '阔知网络三周年庆，EduSoho全面刷.', '', '网络是我们了解世界的一部分，我们今天就 采访了 我们的网络专家', '4', '1443714502', '1443714542', '1', '0');
INSERT INTO `onethink_media_data` VALUES ('3', '1', '1', '国家允许兴办盈利性民办教育...', '', ' 肇基学府三世纪，兴学强国百廿年。10月2日，中国第一所现代大学――天津大学（北洋大学）举行了建校120周年庆祝大会。', '4', '1443714506', '1443714542', '1', '0');
INSERT INTO `onethink_media_data` VALUES ('4', '1', '1', '射手学院宫鑫：新网校如何选择网络营销方.', '', '近日，天津大学召开了“60个重大科学问题和60个重大技术难题”征集发布会，公布了从全校学者中征集和评选出的首批20个“聚焦国家重大战略需求和世界科技发展前沿”的重大科学问题和重大技术难题。 评选出的首批20个“聚焦国家重大战略需求和', '4', '1443714508', '1443714542', '1', '0');
INSERT INTO `onethink_media_data` VALUES ('5', '1', '1', '在线教育选择视频云，应该关心哪些参数？.', '', ' 肇基学府三世纪，兴学强国百廿年。10月2日，中国第一所现代大学――天津大学（北洋大学）举行了建校120周年庆祝大会。', '4', '1443714510', '1443714542', '1', '0');
INSERT INTO `onethink_media_data` VALUES ('6', '1', '1', '阔知网络三周年庆，EduSoho全面刷.', '', '光明日报头版：天津大学：喜迎双甲子 再创新辉煌行了建校120周年庆祝大会。', '4', '1443714514', '1443714542', '1', '0');
INSERT INTO `onethink_media_data` VALUES ('7', '1', '1', '在线教育选择视频云，应该关心哪些参数？.', '', ' 肇基学府三世纪，兴学强国百廿年。10月2日，中国第一所现代大学――天津大学（北洋大学）举行了建校120周年庆祝大会。', '4', '1443714516', '1443714542', '1', '0');
INSERT INTO `onethink_media_data` VALUES ('8', '1', '1', '阔知网络三周年庆，EduSoho全面刷.', '', ' 肇基学府三世纪，兴学强国百廿年。10月2日，中国第一所现代大学――天津大学（北洋大学）举中国教育报头版头条：一所高校一百二十年的坚守', '4', '1443714518', '1443714542', '1', '0');
INSERT INTO `onethink_media_data` VALUES ('9', '3', '1', '蚂蚁社团', '', '这个社团成立于 xxxx年，是一个 以XXX为主的社团，我们友爱，团结，做自己喜欢的事情', '4', '1443775413', '1443775413', '1', '0');
INSERT INTO `onethink_media_data` VALUES ('10', '3', '1', '乒乓球社团', '', '这个社团成立于 xxxx年，是一个 以XXX为主的社团，我们友爱，团结，做自己喜欢的事情', '4', '1443775413', '1443775413', '1', '0');
INSERT INTO `onethink_media_data` VALUES ('11', '3', '1', '跆拳道社团', '', '这个社团成立于 xxxx年，是一个 以XXX为主的社团，我们友爱，团结，做自己喜欢的事情', '4', '1443775413', '1443775413', '1', '0');
INSERT INTO `onethink_media_data` VALUES ('12', '3', '1', '电子竞技社团', '', '这个社团成立于 xxxx年，是一个 以XXX为主的社团，我们友爱，团结，做自己喜欢的事情', '4', '1443775413', '1443775413', '1', '0');
INSERT INTO `onethink_media_data` VALUES ('13', '3', '1', '篮球社团', '', '这个社团成立于 xxxx年，是一个 以XXX为主的社团，我们友爱，团结，做自己喜欢的事情', '4', '1443775413', '1443775413', '1', '0');
INSERT INTO `onethink_media_data` VALUES ('14', '3', '1', '礼仪社团', '', '这个社团成立于 xxxx年，是一个 以XXX为主的社团，我们友爱，团结，做自己喜欢的事情', '4', '1443775413', '1443775413', '1', '0');
INSERT INTO `onethink_media_data` VALUES ('15', '3', '1', '英语口语社团', '', '这个社团成立于 xxxx年，是一个 以XXX为主的社团，我们友爱，团结，做自己喜欢的事情', '4', '1443775413', '1443775413', '1', '0');
INSERT INTO `onethink_media_data` VALUES ('16', '3', '1', '网络社团', '', '这个社团成立于 xxxx年，是一个 以XXX为主的社团，我们友爱，团结，做自己喜欢的事情', '4', '1443775413', '1443775413', '1', '0');
INSERT INTO `onethink_media_data` VALUES ('17', '3', '2', '第一届读书节', '', '第一届读书节，以创新 大胆为元素，办的更加有特色, 更加吸引人，让人不知不觉就在读书中遨游，多读书，读好书，才能真正明白 这一点', '4', '1443775413', '1443775413', '1', '0');
INSERT INTO `onethink_media_data` VALUES ('18', '3', '2', '第二届读书节', '', '第二届读书节，传承了上一届的元素，办的更加有特色，更加吸引人，让人不知不觉就在读书中遨游，多读书，读好书，才能真正明白 这一点', '4', '1443775413', '1443775413', '1', '0');
INSERT INTO `onethink_media_data` VALUES ('19', '3', '2', '第三届读书节', '', '第三届读书节，传承了以往两局的 元素，办的更加有特色，更加吸引人，让人不知不觉就在读书中遨游，多读书，读好书，才能真正明白 这一点', '4', '1443775413', '1443775413', '1', '0');
INSERT INTO `onethink_media_data` VALUES ('20', '3', '3', '老客勒', '', '凯旋门下的老绅士，散发着成熟的魅力！', '4', '1443775413', '1443775413', '1', '0');
INSERT INTO `onethink_media_data` VALUES ('21', '3', '3', '信仰的力量', '', '斯里兰卡的印度庙内，这位战争的受害者，依然坚持每天来到寺庙祈福', '4', '1443775413', '1443775413', '1', '0');
INSERT INTO `onethink_media_data` VALUES ('22', '3', '3', '仙人钓鱼', '', '在这里，我们看到 人与自然和谐的融合在一起，成为美丽的画', '4', '1443775413', '1443775413', '1', '0');
INSERT INTO `onethink_media_data` VALUES ('23', '3', '3', '祈福', '', '摄于尼泊尔加德满都，老人双手合十，潜心祷告！', '4', '1443775413', '1443775413', '1', '0');
INSERT INTO `onethink_media_data` VALUES ('24', '3', '3', '静', '', '一个老和尚，稳稳的踏着每一步，大隐于市', '4', '1443775413', '1443775413', '1', '0');
INSERT INTO `onethink_media_data` VALUES ('25', '3', '3', '仙艺', '', '如梦如画，就像大自然 自然而成的一样', '4', '1443775413', '1443775413', '1', '0');
INSERT INTO `onethink_media_data` VALUES ('26', '3', '3', '幻境', '', '夏威夷的 夏天，蔚蓝的海边，微风吹过，带来丰收的气息', '4', '1443775413', '1443775413', '1', '0');
INSERT INTO `onethink_media_data` VALUES ('27', '3', '3', '邂逅奶油日落', '', '坐在礁石上,看太阳 缓缓落下，周围 逐渐安静下来，拉开了夜晚的帷幕', '4', '1443775413', '1443775413', '1', '0');
INSERT INTO `onethink_media_data` VALUES ('28', '3', '3', 'Quokka', '', '就像好多 绿色的墓碑一个，他们整齐的生长', '4', '1443775413', '1443775413', '1', '0');
INSERT INTO `onethink_media_data` VALUES ('29', '3', '3', '育儿袋', '', '在澳大利亚，袋鼠妈妈 使用它们的 育儿袋来 携带宝宝，小家伙们，惬意的享受着', '4', '1443775413', '1443775413', '1', '0');
INSERT INTO `onethink_media_data` VALUES ('30', '3', '4', '古色藤椅', '', '浏览历史长河中，坐伴随我们，成为一种文化', '4', '1443775413', '1443775413', '1', '0');
INSERT INTO `onethink_media_data` VALUES ('31', '3', '4', '钟表与台灯', '', '时间，光明，不仅是我们精神上的支柱，更是肉体上不可或缺的部分', '4', '1443775413', '1443775413', '1', '0');
INSERT INTO `onethink_media_data` VALUES ('32', '3', '4', '生活是一种态度', '', '华丽丽的色彩，表达我不一样的生活方式，不一样的态度', '4', '1443775413', '1443775413', '1', '0');
INSERT INTO `onethink_media_data` VALUES ('33', '3', '4', '现代与过去', '', '历史的的过去，与未来，坐落在这中间点上，交错', '4', '1443775413', '1443775413', '1', '0');
INSERT INTO `onethink_media_data` VALUES ('34', '3', '4', '棒槌生活', '', '一个小小的石头，与电线连接，我们并不赋予它多高的使命，它只爆发最原始的呐喊', '4', '1443775413', '1443775413', '1', '0');
INSERT INTO `onethink_media_data` VALUES ('35', '3', '4', '简约美', '', '一眼过去，没有复杂的华丽，只有点，线，面。仿若天生', '4', '1443775413', '1443775413', '1', '0');
INSERT INTO `onethink_media_data` VALUES ('36', '1', '2', '学院数字艺术系第八届学生优秀作品展圆满结', '', '学院数字艺术系第八届学生优秀作品展圆满结', '4', '1443960609', '1443960609', '1', '0');
INSERT INTO `onethink_media_data` VALUES ('37', '1', '2', '学院“睿创空间”——闯吧创业小站正式运营', '', '学院数字艺术系第八届学生优秀作品展圆满结', '4', '1443960609', '1443960609', '1', '0');
INSERT INTO `onethink_media_data` VALUES ('38', '1', '2', '社团巡礼节圆满结束', '', '社团巡礼节圆满结束', '4', '1443960609', '1443960609', '1', '0');
INSERT INTO `onethink_media_data` VALUES ('39', '1', '2', '2015届新生军训结束', '', '2015届新生军训结束，社团巡礼节圆满结束', '4', '1443960609', '1443960609', '1', '0');
INSERT INTO `onethink_media_data` VALUES ('40', '1', '2', '大运会，在我校举行', '', '大运会，在我校举行', '4', '1443960609', '1443960609', '1', '0');
INSERT INTO `onethink_media_data` VALUES ('41', '1', '2', '青青我心，电影在我校拍摄', '', '青青我心，电影在我校拍摄', '4', '1443960609', '1443960609', '1', '0');
INSERT INTO `onethink_media_data` VALUES ('42', '1', '2', '第二届读书节即将展开', '', '第二届读书节，以创新 大胆为元素，办的更加有特色, 更加吸引人，让人不知不觉就在读书中遨游，多读书，读好书，才能真正明白 这一点', '4', '1443960609', '1443960609', '1', '0');
INSERT INTO `onethink_media_data` VALUES ('43', '1', '3', '下周二我们要开始读书节', '', '第三届读书节，传承了以往两局的', '4', '1443960609', '1443960609', '1', '0');
INSERT INTO `onethink_media_data` VALUES ('44', '1', '3', '今天下午大家都到餐厅集合', '', '浏览历史长河中，坐伴随我们，成为一种文化', '4', '1443960609', '1443960609', '1', '0');
INSERT INTO `onethink_media_data` VALUES ('45', '1', '3', '下周五放假', '', '时间，光明，不仅是我们精神上的支柱，更是肉体上不可或缺的部分', '4', '1443960609', '1443960609', '1', '0');
INSERT INTO `onethink_media_data` VALUES ('46', '1', '3', '生活是一种态度，校园播音室', '', '华丽丽的色彩，表达我不一样的生活方式，不一样的态度', '4', '1443960609', '1443960609', '1', '0');
INSERT INTO `onethink_media_data` VALUES ('47', '1', '3', '五一放假', '', '历史的的过去，与未来，坐落在这中间点上，交错', '4', '1443960609', '1443960609', '1', '0');
INSERT INTO `onethink_media_data` VALUES ('48', '1', '3', '关于贫困生', '', '一个小小的石头，与电线连接，我们并不赋予它多高的使命，它只爆发最原始的呐喊', '4', '1443960609', '1443960609', '1', '0');
INSERT INTO `onethink_media_data` VALUES ('49', '1', '3', '入学简介', '', '一眼过去，没有复杂的华丽，只有点，线，面。仿若天生', '4', '1443960609', '1443960609', '1', '0');
INSERT INTO `onethink_media_data` VALUES ('50', '2', '1', '《思修道德修养与法律基础》教学大纲', '', '这是思想道德修养与法律基础', '4', '1444117273', '1444117273', '1', '0');
INSERT INTO `onethink_media_data` VALUES ('51', '2', '1', '《毛泽东思想和中国特色社会主义理论体系概', '', '《毛泽东思想和中国特色社会主义理论体系概', '4', '1444117273', '1444117273', '1', '0');
INSERT INTO `onethink_media_data` VALUES ('52', '2', '1', '《马克思主义基本原理概论》教学大纲', '', '《马克思主义基本原理概论》教学大纲', '4', '1444117273', '1444117273', '1', '0');
INSERT INTO `onethink_media_data` VALUES ('53', '2', '1', '《中国近现代史纲要》教学大纲', '', '《中国近现代史纲要》教学大纲', '4', '1444117273', '1444117273', '1', '0');
INSERT INTO `onethink_media_data` VALUES ('54', '2', '2', '情景教学法简介', '', '情景教学法简介', '4', '1444117273', '1444117273', '1', '0');
INSERT INTO `onethink_media_data` VALUES ('55', '2', '2', '思政课情景剧教学实施过程流程图', '', '思政课情景剧教学实施过程流程图', '4', '1444117273', '1444117273', '1', '0');
INSERT INTO `onethink_media_data` VALUES ('56', '2', '2', '思修剧剧本 大学生活--考试风云', '', '思修剧剧本 大学生活--考试风云', '4', '1444117273', '1444117273', '1', '0');
INSERT INTO `onethink_media_data` VALUES ('57', '2', '3', '教学评价 简介', '', '教学评价 简介', '4', '1444117273', '1444117273', '1', '0');
INSERT INTO `onethink_media_data` VALUES ('58', '2', '3', '教学成果', '', '教学成果', '4', '1444117273', '1444117273', '1', '0');
INSERT INTO `onethink_media_data` VALUES ('59', '2', '3', '教学评价', '', '教学成果', '4', '1444117273', '1444117273', '1', '0');

-- -----------------------------
-- Table structure for `onethink_member`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_member`;
CREATE TABLE `onethink_member` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户ID',
  `nickname` char(16) NOT NULL DEFAULT '' COMMENT '昵称',
  `sex` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '性别',
  `birthday` date NOT NULL DEFAULT '0000-00-00' COMMENT '生日',
  `qq` char(10) NOT NULL DEFAULT '' COMMENT 'qq号',
  `score` mediumint(8) NOT NULL DEFAULT '0' COMMENT '用户积分',
  `login` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '登录次数',
  `reg_ip` bigint(20) NOT NULL DEFAULT '0' COMMENT '注册IP',
  `reg_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '注册时间',
  `last_login_ip` bigint(20) NOT NULL DEFAULT '0' COMMENT '最后登录IP',
  `last_login_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '最后登录时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '会员状态',
  PRIMARY KEY (`uid`),
  KEY `status` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COMMENT='会员表';

-- -----------------------------
-- Records of `onethink_member`
-- -----------------------------
INSERT INTO `onethink_member` VALUES ('1', 'admin', '0', '0000-00-00', '', '200', '55', '0', '1440939470', '0', '1446210417', '1');
INSERT INTO `onethink_member` VALUES ('2', 'cheng1483', '0', '0000-00-00', '', '10', '1', '2130706433', '1440944380', '2130706433', '1440944380', '-1');
INSERT INTO `onethink_member` VALUES ('4', 'cheng', '0', '0000-00-00', '', '10', '3', '2130706433', '1444206200', '2130706433', '1444206608', '1');
INSERT INTO `onethink_member` VALUES ('5', 'zz1234', '0', '0000-00-00', '', '10', '2', '2130706433', '1444206742', '2130706433', '1444206774', '1');
INSERT INTO `onethink_member` VALUES ('6', 'cctv', '0', '0000-00-00', '', '10', '9', '2130706433', '1445309296', '2130706433', '1445427090', '1');

-- -----------------------------
-- Table structure for `onethink_menu`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_menu`;
CREATE TABLE `onethink_menu` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '文档ID',
  `title` varchar(50) NOT NULL DEFAULT '' COMMENT '标题',
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `sort` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '排序（同级有效）',
  `url` char(255) NOT NULL DEFAULT '' COMMENT '链接地址',
  `hide` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否隐藏',
  `tip` varchar(255) NOT NULL DEFAULT '' COMMENT '提示',
  `group` varchar(50) DEFAULT '' COMMENT '分组',
  `is_dev` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否仅开发者模式可见',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`),
  KEY `status` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=133 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `onethink_menu`
-- -----------------------------
INSERT INTO `onethink_menu` VALUES ('1', '首页', '0', '1', 'Index/index', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('2', '内容', '0', '2', 'Article/index', '1', '', '', '1', '1');
INSERT INTO `onethink_menu` VALUES ('3', '文档列表', '2', '0', 'article/index', '1', '', '内容', '0', '1');
INSERT INTO `onethink_menu` VALUES ('4', '新增', '3', '0', 'article/add', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('5', '编辑', '3', '0', 'article/edit', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('6', '改变状态', '3', '0', 'article/setStatus', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('7', '保存', '3', '0', 'article/update', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('8', '保存草稿', '3', '0', 'article/autoSave', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('9', '移动', '3', '0', 'article/move', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('10', '复制', '3', '0', 'article/copy', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('11', '粘贴', '3', '0', 'article/paste', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('12', '导入', '3', '0', 'article/batchOperate', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('13', '回收站', '2', '0', 'article/recycle', '1', '', '内容', '0', '1');
INSERT INTO `onethink_menu` VALUES ('14', '还原', '13', '0', 'article/permit', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('15', '清空', '13', '0', 'article/clear', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('16', '用户', '0', '3', 'User/index', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('17', '用户信息', '16', '0', 'User/index', '0', '', '用户管理', '0', '1');
INSERT INTO `onethink_menu` VALUES ('18', '新增用户', '17', '0', 'User/add', '0', '添加新用户', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('19', '用户行为', '16', '0', 'User/action', '0', '', '行为管理', '0', '1');
INSERT INTO `onethink_menu` VALUES ('20', '新增用户行为', '19', '0', 'User/addaction', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('21', '编辑用户行为', '19', '0', 'User/editaction', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('22', '保存用户行为', '19', '0', 'User/saveAction', '0', '\"用户->用户行为\"保存编辑和新增的用户行为', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('23', '变更行为状态', '19', '0', 'User/setStatus', '0', '\"用户->用户行为\"中的启用,禁用和删除权限', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('24', '禁用会员', '19', '0', 'User/changeStatus?method=forbidUser', '0', '\"用户->用户信息\"中的禁用', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('25', '启用会员', '19', '0', 'User/changeStatus?method=resumeUser', '0', '\"用户->用户信息\"中的启用', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('26', '删除会员', '19', '0', 'User/changeStatus?method=deleteUser', '0', '\"用户->用户信息\"中的删除', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('27', '权限管理', '16', '0', 'AuthManager/index', '0', '', '用户管理', '0', '1');
INSERT INTO `onethink_menu` VALUES ('28', '删除', '27', '0', 'AuthManager/changeStatus?method=deleteGroup', '0', '删除用户组', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('29', '禁用', '27', '0', 'AuthManager/changeStatus?method=forbidGroup', '0', '禁用用户组', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('30', '恢复', '27', '0', 'AuthManager/changeStatus?method=resumeGroup', '0', '恢复已禁用的用户组', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('31', '新增', '27', '0', 'AuthManager/createGroup', '0', '创建新的用户组', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('32', '编辑', '27', '0', 'AuthManager/editGroup', '0', '编辑用户组名称和描述', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('33', '保存用户组', '27', '0', 'AuthManager/writeGroup', '0', '新增和编辑用户组的\"保存\"按钮', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('34', '授权', '27', '0', 'AuthManager/group', '0', '\"后台 \\ 用户 \\ 用户信息\"列表页的\"授权\"操作按钮,用于设置用户所属用户组', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('35', '访问授权', '27', '0', 'AuthManager/access', '0', '\"后台 \\ 用户 \\ 权限管理\"列表页的\"访问授权\"操作按钮', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('36', '成员授权', '27', '0', 'AuthManager/user', '0', '\"后台 \\ 用户 \\ 权限管理\"列表页的\"成员授权\"操作按钮', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('37', '解除授权', '27', '0', 'AuthManager/removeFromGroup', '0', '\"成员授权\"列表页内的解除授权操作按钮', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('38', '保存成员授权', '27', '0', 'AuthManager/addToGroup', '0', '\"用户信息\"列表页\"授权\"时的\"保存\"按钮和\"成员授权\"里右上角的\"添加\"按钮)', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('39', '分类授权', '27', '0', 'AuthManager/category', '0', '\"后台 \\ 用户 \\ 权限管理\"列表页的\"分类授权\"操作按钮', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('40', '保存分类授权', '27', '0', 'AuthManager/addToCategory', '0', '\"分类授权\"页面的\"保存\"按钮', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('41', '模型授权', '27', '0', 'AuthManager/modelauth', '0', '\"后台 \\ 用户 \\ 权限管理\"列表页的\"模型授权\"操作按钮', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('42', '保存模型授权', '27', '0', 'AuthManager/addToModel', '0', '\"分类授权\"页面的\"保存\"按钮', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('43', '扩展', '0', '7', 'Addons/index', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('44', '插件管理', '43', '1', 'Addons/index', '0', '', '扩展', '0', '1');
INSERT INTO `onethink_menu` VALUES ('45', '创建', '44', '0', 'Addons/create', '0', '服务器上创建插件结构向导', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('46', '检测创建', '44', '0', 'Addons/checkForm', '0', '检测插件是否可以创建', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('47', '预览', '44', '0', 'Addons/preview', '0', '预览插件定义类文件', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('48', '快速生成插件', '44', '0', 'Addons/build', '0', '开始生成插件结构', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('49', '设置', '44', '0', 'Addons/config', '0', '设置插件配置', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('50', '禁用', '44', '0', 'Addons/disable', '0', '禁用插件', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('51', '启用', '44', '0', 'Addons/enable', '0', '启用插件', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('52', '安装', '44', '0', 'Addons/install', '0', '安装插件', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('53', '卸载', '44', '0', 'Addons/uninstall', '0', '卸载插件', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('54', '更新配置', '44', '0', 'Addons/saveconfig', '0', '更新插件配置处理', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('55', '插件后台列表', '44', '0', 'Addons/adminList', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('56', 'URL方式访问插件', '44', '0', 'Addons/execute', '0', '控制是否有权限通过url访问插件控制器方法', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('57', '钩子管理', '43', '2', 'Addons/hooks', '0', '', '扩展', '0', '1');
INSERT INTO `onethink_menu` VALUES ('58', '模型管理', '68', '3', 'Model/index', '0', '', '系统设置', '1', '1');
INSERT INTO `onethink_menu` VALUES ('59', '新增', '58', '0', 'model/add', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('60', '编辑', '58', '0', 'model/edit', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('61', '改变状态', '58', '0', 'model/setStatus', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('62', '保存数据', '58', '0', 'model/update', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('63', '属性管理', '68', '0', 'Attribute/index', '1', '网站属性配置。', '', '1', '1');
INSERT INTO `onethink_menu` VALUES ('64', '新增', '63', '0', 'Attribute/add', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('65', '编辑', '63', '0', 'Attribute/edit', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('66', '改变状态', '63', '0', 'Attribute/setStatus', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('67', '保存数据', '63', '0', 'Attribute/update', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('68', '系统', '0', '4', 'Config/group', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('69', '网站设置', '68', '1', 'Config/group', '0', '', '系统设置', '0', '1');
INSERT INTO `onethink_menu` VALUES ('70', '配置管理', '68', '4', 'Config/index', '0', '', '系统设置', '1', '1');
INSERT INTO `onethink_menu` VALUES ('71', '编辑', '70', '0', 'Config/edit', '0', '新增编辑和保存配置', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('72', '删除', '70', '0', 'Config/del', '0', '删除配置', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('73', '新增', '70', '0', 'Config/add', '0', '新增配置', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('74', '保存', '70', '0', 'Config/save', '0', '保存配置', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('75', '菜单管理', '68', '5', 'Menu/index', '0', '', '系统设置', '1', '1');
INSERT INTO `onethink_menu` VALUES ('76', '导航管理', '68', '6', 'Channel/index', '0', '', '系统设置', '1', '1');
INSERT INTO `onethink_menu` VALUES ('77', '新增', '76', '0', 'Channel/add', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('78', '编辑', '76', '0', 'Channel/edit', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('79', '删除', '76', '0', 'Channel/del', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('80', '分类管理', '68', '2', 'Category/index', '0', '', '系统设置', '1', '1');
INSERT INTO `onethink_menu` VALUES ('81', '编辑', '80', '0', 'Category/edit', '0', '编辑和保存栏目分类', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('82', '新增', '80', '0', 'Category/add', '0', '新增栏目分类', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('83', '删除', '80', '0', 'Category/remove', '0', '删除栏目分类', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('84', '移动', '80', '0', 'Category/operate/type/move', '0', '移动栏目分类', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('85', '合并', '80', '0', 'Category/operate/type/merge', '0', '合并栏目分类', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('86', '备份数据库', '68', '0', 'Database/index?type=export', '0', '', '数据备份', '0', '1');
INSERT INTO `onethink_menu` VALUES ('87', '备份', '86', '0', 'Database/export', '0', '备份数据库', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('88', '优化表', '86', '0', 'Database/optimize', '0', '优化数据表', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('89', '修复表', '86', '0', 'Database/repair', '0', '修复数据表', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('90', '还原数据库', '68', '0', 'Database/index?type=import', '0', '', '数据备份', '0', '1');
INSERT INTO `onethink_menu` VALUES ('91', '恢复', '90', '0', 'Database/import', '0', '数据库恢复', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('92', '删除', '90', '0', 'Database/del', '0', '删除备份文件', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('93', '其他', '0', '8', 'other', '1', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('96', '新增', '75', '0', 'Menu/add', '0', '', '系统设置', '0', '1');
INSERT INTO `onethink_menu` VALUES ('98', '编辑', '75', '0', 'Menu/edit', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('106', '行为日志', '16', '0', 'Action/actionlog', '0', '', '行为管理', '0', '1');
INSERT INTO `onethink_menu` VALUES ('108', '修改密码', '16', '0', 'User/updatePassword', '1', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('109', '修改昵称', '16', '0', 'User/updateNickname', '1', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('110', '查看行为日志', '106', '0', 'action/edit', '1', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('112', '新增数据', '58', '0', 'think/add', '1', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('113', '编辑数据', '58', '0', 'think/edit', '1', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('114', '导入', '75', '0', 'Menu/import', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('115', '生成', '58', '0', 'Model/generate', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('116', '新增钩子', '57', '0', 'Addons/addHook', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('117', '编辑钩子', '57', '0', 'Addons/edithook', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('118', '文档排序', '3', '0', 'Article/sort', '1', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('119', '排序', '70', '0', 'Config/sort', '1', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('120', '排序', '75', '0', 'Menu/sort', '1', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('121', '排序', '76', '0', 'Channel/sort', '1', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('122', '数据列表', '58', '0', 'think/lists', '1', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('123', '审核列表', '3', '0', 'Article/examine', '1', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('124', '资源', '0', '5', 'Advertisement/index', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('125', '幻灯片', '124', '0', 'Advertisement/index', '0', '', '广告', '0', '1');
INSERT INTO `onethink_menu` VALUES ('126', '资源标签', '124', '0', 'Tab/index', '0', '', '教学资源', '0', '1');
INSERT INTO `onethink_menu` VALUES ('127', '视频资源', '124', '0', 'Resource/index', '0', '', '教学资源', '0', '1');
INSERT INTO `onethink_menu` VALUES ('128', '教学人员', '124', '0', 'Personnel/index', '0', '', '教学资源', '0', '1');
INSERT INTO `onethink_menu` VALUES ('129', '新闻内容', '124', '0', 'Media/news', '0', '', '图文资源', '0', '1');
INSERT INTO `onethink_menu` VALUES ('130', '教学内容', '124', '0', 'Media/teaching', '0', '', '图文资源', '0', '1');
INSERT INTO `onethink_menu` VALUES ('131', '图文内容', '124', '0', 'Media/rich', '0', '', '图文资源', '0', '1');
INSERT INTO `onethink_menu` VALUES ('132', '友情链接', '124', '0', 'Friendlink/index', '0', '', '网站设置', '0', '1');

-- -----------------------------
-- Table structure for `onethink_message`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_message`;
CREATE TABLE `onethink_message` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `title` varchar(80) NOT NULL DEFAULT '' COMMENT '留言名称',
  `summary` varchar(255) NOT NULL DEFAULT '' COMMENT '留言内容',
  `username` varchar(100) NOT NULL DEFAULT '' COMMENT '真实姓名',
  `email` varchar(100) NOT NULL DEFAULT '' COMMENT '电子邮件',
  `qq` varchar(100) NOT NULL DEFAULT '' COMMENT 'QQ',
  `phone` varchar(100) NOT NULL DEFAULT '' COMMENT '电话',
  `addr` varchar(100) NOT NULL DEFAULT '' COMMENT '地址',
  `sort` int(3) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '类型分组 1:投诉、建议 2:问题咨询 3:其他',
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '状态（0：禁用，1：正常）',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '添加时间',
  `reply_info` text NOT NULL COMMENT '回复内容',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='留言板表';


-- -----------------------------
-- Table structure for `onethink_model`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_model`;
CREATE TABLE `onethink_model` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '模型ID',
  `name` char(30) NOT NULL DEFAULT '' COMMENT '模型标识',
  `title` char(30) NOT NULL DEFAULT '' COMMENT '模型名称',
  `extend` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '继承的模型',
  `relation` varchar(30) NOT NULL DEFAULT '' COMMENT '继承与被继承模型的关联字段',
  `need_pk` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '新建表时是否需要主键字段',
  `field_sort` text COMMENT '表单字段排序',
  `field_group` varchar(255) NOT NULL DEFAULT '1:基础' COMMENT '字段分组',
  `attribute_list` text COMMENT '属性列表（表的字段）',
  `attribute_alias` varchar(255) NOT NULL DEFAULT '' COMMENT '属性别名定义',
  `template_list` varchar(100) NOT NULL DEFAULT '' COMMENT '列表模板',
  `template_add` varchar(100) NOT NULL DEFAULT '' COMMENT '新增模板',
  `template_edit` varchar(100) NOT NULL DEFAULT '' COMMENT '编辑模板',
  `list_grid` text COMMENT '列表定义',
  `list_row` smallint(2) unsigned NOT NULL DEFAULT '10' COMMENT '列表数据长度',
  `search_key` varchar(50) NOT NULL DEFAULT '' COMMENT '默认搜索字段',
  `search_list` varchar(255) NOT NULL DEFAULT '' COMMENT '高级搜索的字段',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '状态',
  `engine_type` varchar(25) NOT NULL DEFAULT 'MyISAM' COMMENT '数据库引擎',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COMMENT='文档模型表';

-- -----------------------------
-- Records of `onethink_model`
-- -----------------------------
INSERT INTO `onethink_model` VALUES ('1', 'document', '基础文档', '0', '', '1', '{\"1\":[\"1\",\"2\",\"3\",\"4\",\"5\",\"6\",\"7\",\"8\",\"9\",\"10\",\"11\",\"12\",\"13\",\"14\",\"15\",\"16\",\"17\",\"18\",\"19\",\"20\",\"21\",\"22\"]}', '1:基础', '', '', '', '', '', 'id:编号\r\ntitle:标题:[EDIT]\r\ntype:类型\r\nupdate_time:最后更新\r\nstatus:状态\r\nview:浏览\r\nid:操作:[EDIT]|编辑,[DELETE]|删除', '0', '', '', '1383891233', '1384507827', '1', 'MyISAM');
INSERT INTO `onethink_model` VALUES ('2', 'article', '文章', '1', '', '1', '{\"1\":[\"3\",\"24\",\"2\",\"5\"],\"2\":[\"9\",\"13\",\"19\",\"10\",\"12\",\"16\",\"17\",\"26\",\"20\",\"14\",\"11\",\"25\"]}', '1:基础,2:扩展', '', '', '', '', '', '', '0', '', '', '1383891243', '1387260622', '1', 'MyISAM');
INSERT INTO `onethink_model` VALUES ('3', 'download', '下载', '1', '', '1', '{\"1\":[\"3\",\"28\",\"30\",\"32\",\"2\",\"5\",\"31\"],\"2\":[\"13\",\"10\",\"27\",\"9\",\"12\",\"16\",\"17\",\"19\",\"11\",\"20\",\"14\",\"29\"]}', '1:基础,2:扩展', '', '', '', '', '', '', '0', '', '', '1383891252', '1387260449', '1', 'MyISAM');
INSERT INTO `onethink_model` VALUES ('8', 'banner_list', '广告', '0', '', '1', '{\"1\":[\"62\",\"63\",\"64\",\"65\",\"66\",\"68\",\"69\",\"67\",\"70\"]}', '1:基础', '', '', '', '', '', 'id:编号\r\ntitle:标题:[EDIT]\r\ntype:类型\r\nupdate_time:最后更新\r\nstatus:状态\r\nid:操作:[EDIT]|编辑,[DELETE]|删除', '10', '', '', '1442280074', '1442280394', '1', 'MyISAM');

-- -----------------------------
-- Table structure for `onethink_personnel_article`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_personnel_article`;
CREATE TABLE `onethink_personnel_article` (
  `id` int(11) NOT NULL COMMENT '自增主键',
  `parse` tinyint(4) NOT NULL COMMENT '内容解析类型（0-html,1-ubb,2-markdown）',
  `content` text COLLATE utf8_bin NOT NULL COMMENT '文章内容',
  `template` varchar(100) COLLATE utf8_bin NOT NULL COMMENT '详情页显示模板',
  `bookmark` int(10) unsigned NOT NULL,
  `status` tinyint(4) NOT NULL COMMENT '状态（-1：已删除，0：禁用，1：正常）',
  `create_time` int(10) unsigned NOT NULL COMMENT '创建时间',
  `sort` smallint(3) NOT NULL DEFAULT '0' COMMENT '排序',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;


-- -----------------------------
-- Table structure for `onethink_personnel_data`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_personnel_data`;
CREATE TABLE `onethink_personnel_data` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `type` tinyint(4) NOT NULL COMMENT '所属分类：1教师2 成功3专家 0其他',
  `name` varchar(20) COLLATE utf8_bin NOT NULL COMMENT '名字',
  `company` varchar(20) COLLATE utf8_bin NOT NULL COMMENT '在职单位',
  `synopsis` varchar(160) COLLATE utf8_bin NOT NULL COMMENT '简介',
  `portrait` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '0' COMMENT '头像',
  `create_time` int(10) unsigned NOT NULL COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL COMMENT '修改时间',
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '状态（-1：已删除，0：禁用，1：正常）',
  `sort` smallint(3) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- -----------------------------
-- Records of `onethink_personnel_data`
-- -----------------------------
INSERT INTO `onethink_personnel_data` VALUES ('1', '1', '李老师', '天津电子信息职业技术学院', '作为优秀老师，把最新鲜的资讯与大家分享是我的职责', '11', '1443426737', '1445959249', '1', '0');
INSERT INTO `onethink_personnel_data` VALUES ('2', '1', '王老师', '天津电子信息职业技术学院', '最新鲜的资讯与大家分享是我成为老师的原因', '12', '1443426737', '1445959358', '1', '0');
INSERT INTO `onethink_personnel_data` VALUES ('3', '1', '张老师', '天津电子信息职业技术学院', '作为优秀老师，把最新鲜的资讯与大家分享是我的职责', '11', '1443426737', '1443426737', '1', '0');
INSERT INTO `onethink_personnel_data` VALUES ('4', '2', '马云', '淘宝公司', '作为优秀老师，把最新鲜的资讯与大家分享是我的职责', '11', '1443426737', '1443426737', '1', '0');
INSERT INTO `onethink_personnel_data` VALUES ('5', '2', '李彦宏1', '百度公司', '作为优秀老师，把最新鲜的资讯与大家分享是我的职责', '11', '1443512504', '1443512504', '1', '0');
INSERT INTO `onethink_personnel_data` VALUES ('6', '2', '马化腾2', '腾讯公司', '作为优秀老师，把最新鲜的资讯与大家分享是我的职责', '11', '1443512504', '1443512504', '1', '0');
INSERT INTO `onethink_personnel_data` VALUES ('7', '2', '赵军3', '360公司', '作为优秀老师，把最新鲜的资讯与大家分享是我的职责', '11', '1443512504', '1443512504', '1', '0');
INSERT INTO `onethink_personnel_data` VALUES ('8', '2', '马云4', '淘宝公司', '作为优秀老师，把最新鲜的资讯与大家分享是我的职责', '11', '1443512504', '1443512504', '1', '0');
INSERT INTO `onethink_personnel_data` VALUES ('9', '2', '李彦宏5', '百度公司', '作为优秀老师，把最新鲜的资讯与大家分享是我的职责', '11', '1443512504', '1443512504', '1', '0');
INSERT INTO `onethink_personnel_data` VALUES ('10', '2', '马化腾6', '腾讯公司', '作为优秀老师，把最新鲜的资讯与大家分享是我的职责', '11', '1443512504', '1443512504', '1', '0');
INSERT INTO `onethink_personnel_data` VALUES ('11', '3', '专家1', '百度公司', '作为优秀老师，把最新鲜的资讯与大家分享是我的职责', '11', '1443512504', '1443512504', '1', '0');
INSERT INTO `onethink_personnel_data` VALUES ('12', '3', '专家2', '腾讯公司', '作为优秀老师，把最新鲜的资讯与大家分享是我的职责', '11', '1443512504', '1443512504', '1', '0');
INSERT INTO `onethink_personnel_data` VALUES ('13', '3', '专家3', '360公司', '作为优秀老师，把最新鲜的资讯与大家分享是我的职责', '11', '1443512504', '1443512504', '1', '0');
INSERT INTO `onethink_personnel_data` VALUES ('14', '3', '专家4', '淘宝公司', '作为优秀老师，把最新鲜的资讯与大家分享是我的职责', '11', '1443512504', '1443512504', '1', '0');
INSERT INTO `onethink_personnel_data` VALUES ('15', '2', '123456', '123456', '123456', '12', '1446023936', '1446023936', '1', '0');
INSERT INTO `onethink_personnel_data` VALUES ('16', '2', '称不能为', '称不能为', '123456', '12', '1446023958', '1446024050', '1', '0');
INSERT INTO `onethink_personnel_data` VALUES ('17', '2', '名称不能为空', '名称不能为空', '123465', '12', '1446023976', '1446024060', '1', '0');
INSERT INTO `onethink_personnel_data` VALUES ('18', '2', '名称不能为空', '名称不能为空', '名称不能为空', '12', '1446024025', '1446024025', '1', '0');

-- -----------------------------
-- Table structure for `onethink_picture`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_picture`;
CREATE TABLE `onethink_picture` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键id自增',
  `path` varchar(255) NOT NULL DEFAULT '' COMMENT '路径',
  `url` varchar(255) NOT NULL DEFAULT '' COMMENT '图片链接',
  `md5` char(32) NOT NULL DEFAULT '' COMMENT '文件md5',
  `sha1` char(40) NOT NULL DEFAULT '' COMMENT '文件 sha1编码',
  `status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '状态',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `onethink_picture`
-- -----------------------------
INSERT INTO `onethink_picture` VALUES ('1', '/Uploads/Picture/2015-08-30/55e31e52ad2c6.jpg', '', '43a79cbb2ae7826649592a81b85ab6eb', '84f3d471665d931e8a91ac748a1120516ddb1c68', '1', '1440947794');
INSERT INTO `onethink_picture` VALUES ('2', '/Uploads/Picture/2015-09-15/55f775bd31035.png', '', 'f4a5a6ae9aa965ed10971d57e3dbc9ba', 'af0eb640a8c57975c3d2daca6aa88ad9745bb9a3', '1', '1442280892');
INSERT INTO `onethink_picture` VALUES ('3', '/Uploads/Picture/2015-10-24/562b2b91df209.jpg', '', '819748bcb2b30145e423e119d20f9ba8', 'cfca4a6d83c42de286ea901ef0029f39ec829d7b', '1', '1445669777');
INSERT INTO `onethink_picture` VALUES ('4', '/Uploads/Picture/2015-10-24/562b2f75075d2.jpg', '', '5ec43c5648082407c44db0db3909b790', '4b9ff2cafcf8f5cafccba476abf47e1a74c94159', '1', '1445670772');
INSERT INTO `onethink_picture` VALUES ('5', '/Uploads/Picture/2015-10-24/562b71bc1e300.jpg', '', 'bf534e77626fdbb80d2ee93b47a303d0', '2afe1912dd8056b57de5a4d841feb8a26967f084', '1', '1445687739');
INSERT INTO `onethink_picture` VALUES ('6', '/Uploads/Picture/2015-10-24/562b72411abb6.jpg', '', 'c02a41f26c302245c22ba1759c9780b7', 'e40cca7ae3a6bfa5f3b18256884339ed0a224755', '1', '1445687873');
INSERT INTO `onethink_picture` VALUES ('7', '/Uploads/Picture/2015-10-24/562b73922ae98.jpg', '', '73e31b39f65a13f146fda6734ab746f5', '3580fff20fed5d2d9bd37c16c6936297074c0677', '1', '1445688210');
INSERT INTO `onethink_picture` VALUES ('8', '/Uploads/Picture/2015-10-24/562b75d9b40f6.jpg', '', '3398f6a3e701e2f71019d107e49b2c85', 'bb3579445eb9b9502973f08ed7c3931a41e2790a', '1', '1445688793');
INSERT INTO `onethink_picture` VALUES ('9', '/Uploads/Picture/2015-10-26/562e026a3ca37.jpg', '', '3dae2a32ec93f643c177bc9cdf52c006', '8d22460582a866f426d5c0a980f3ee28f77116a1', '1', '1445855850');
INSERT INTO `onethink_picture` VALUES ('10', '/Uploads/Picture/2015-10-26/562e11b635a4b.jpg', '', 'c680c0007ace2ed1fe972d2898fd91ef', 'd36f49a50ba0b43047cdc7fc46dfb6c0e2bcdf74', '1', '1445859766');
INSERT INTO `onethink_picture` VALUES ('11', '/Uploads/Picture/2015-10-27/562f954a430b2.jpg', '', '737b8212baff38b83e8a6b8122d1ca52', '5a78b7b76e26181a085a17fa46d98d6e1fbac49b', '1', '1445958986');
INSERT INTO `onethink_picture` VALUES ('12', '/Uploads/Picture/2015-10-27/562f96ab2b521.jpg', '', '91f28ebf6634b99f1de64691fb783823', 'ff418e64f2e38760daadf3bc7441c7a02f420d8a', '1', '1445959339');

-- -----------------------------
-- Table structure for `onethink_pictures_show`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_pictures_show`;
CREATE TABLE `onethink_pictures_show` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '广告题目',
  `title` varchar(80) COLLATE utf8_bin NOT NULL COMMENT '广告题目',
  `url` varchar(255) COLLATE utf8_bin DEFAULT NULL COMMENT '链接地址',
  `img` varchar(255) COLLATE utf8_bin NOT NULL COMMENT '图片链接地址',
  `set` int(11) NOT NULL COMMENT '集合',
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '状态（-1：已删除，0：禁用，1：正常）',
  `create_time` int(10) unsigned NOT NULL COMMENT '创建时间',
  `update_time` int(10) NOT NULL COMMENT '修改时间',
  `sort` smallint(3) unsigned DEFAULT '0' COMMENT '排序，默认为0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;


-- -----------------------------
-- Table structure for `onethink_resource`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_resource`;
CREATE TABLE `onethink_resource` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `title` varchar(80) COLLATE utf8_bin NOT NULL COMMENT '标题',
  `type` tinyint(4) unsigned NOT NULL DEFAULT '1' COMMENT '资源类型：0:其他  1:视频  2:文本',
  `group` tinyint(4) unsigned NOT NULL COMMENT '分组：0其他 1名师 2 经典 ',
  `tab` int(11) unsigned NOT NULL COMMENT '资源标签',
  `img` varchar(255) COLLATE utf8_bin NOT NULL COMMENT '图片地址',
  `video` varchar(255) COLLATE utf8_bin NOT NULL COMMENT '视频地址',
  `authority` int(11) unsigned NOT NULL COMMENT '人员id',
  `set` int(11) unsigned NOT NULL COMMENT '合集',
  `player_number` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '播放数',
  `create_time` int(10) NOT NULL COMMENT '创建时间',
  `update_time` int(10) NOT NULL COMMENT '修改时间',
  `status` tinyint(4) DEFAULT '1' COMMENT '状态（-1：已删除，0：禁用，1：正常）',
  `sort` smallint(3) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- -----------------------------
-- Records of `onethink_resource`
-- -----------------------------
INSERT INTO `onethink_resource` VALUES ('1', '特色社团', '1', '1', '2', '4', '8', '3', '123', '3', '1443103867', '1445941231', '1', '0');
INSERT INTO `onethink_resource` VALUES ('2', '摄影基础', '1', '1', '1', '4', '5', '1', '123', '2', '1443103867', '1443103867', '1', '0');
INSERT INTO `onethink_resource` VALUES ('3', '社会主义理论', '1', '1', '1', '4', '5', '3', '123', '0', '1443103867', '1443103867', '1', '0');
INSERT INTO `onethink_resource` VALUES ('4', '传承与理论', '1', '1', '2', '4', '5', '1', '123', '0', '1443103867', '1443103867', '1', '0');
INSERT INTO `onethink_resource` VALUES ('5', '特色社团', '1', '1', '2', '4', '5', '2', '123', '0', '1443281302', '1443281302', '1', '0');
INSERT INTO `onethink_resource` VALUES ('6', '摄影基础', '1', '1', '2', '4', '5', '1', '222', '3', '1443281302', '1443281302', '1', '0');
INSERT INTO `onethink_resource` VALUES ('7', '社会主义理论', '1', '1', '2', '4', '5', '3', '123', '0', '1443281302', '1443281302', '1', '0');
INSERT INTO `onethink_resource` VALUES ('8', '传承与理论', '1', '1', '2', '4', '5', '1', '123', '0', '1443281302', '1443281302', '1', '0');
INSERT INTO `onethink_resource` VALUES ('10', '摄影基础', '1', '1', '3', '4', '5', '2', '123', '0', '1443281491', '1443281491', '1', '0');
INSERT INTO `onethink_resource` VALUES ('11', '社会主义理论', '1', '1', '3', '4', '5', '1', '222', '0', '1443281491', '1443281491', '1', '0');
INSERT INTO `onethink_resource` VALUES ('12', '传承与理论', '1', '1', '3', '4', '5', '3', '123', '0', '1443281491', '1443281491', '1', '0');
INSERT INTO `onethink_resource` VALUES ('13', '特色社团', '1', '1', '3', '4', '5', '1', '123', '0', '1443281515', '1443281515', '1', '0');
INSERT INTO `onethink_resource` VALUES ('14', '摄影基础', '1', '1', '4', '4', '5', '2', '222', '0', '1443281515', '1443281515', '1', '0');
INSERT INTO `onethink_resource` VALUES ('15', '社会主义理论', '1', '1', '4', '4', '5', '3', '123', '1', '1443281515', '1443281515', '1', '0');
INSERT INTO `onethink_resource` VALUES ('16', '传承与理论', '1', '1', '4', '4', '5', '2', '22', '2', '1443281515', '1443281515', '1', '0');
INSERT INTO `onethink_resource` VALUES ('17', '特色社团', '1', '1', '4', '4', '5', '3', '123', '0', '1443281536', '1443281536', '1', '0');
INSERT INTO `onethink_resource` VALUES ('18', '摄影基础', '1', '1', '5', '4', '5', '1', '22', '13', '1443281536', '1443281536', '1', '0');
INSERT INTO `onethink_resource` VALUES ('19', '社会主义理论', '1', '1', '5', '4', '5', '3', '222', '0', '1443281536', '1443281536', '1', '0');
INSERT INTO `onethink_resource` VALUES ('20', '传承与理论', '1', '1', '5', '4', '5', '3', '22', '1', '1443281536', '1443281536', '1', '0');
INSERT INTO `onethink_resource` VALUES ('22', '摄影基础2', '1', '2', '1', '4', '5', '1', '111', '0', '1443496757', '1443496757', '1', '0');
INSERT INTO `onethink_resource` VALUES ('23', '社会主义理论3', '1', '2', '2', '4', '5', '2', '11', '0', '1443496757', '1443496757', '1', '0');
INSERT INTO `onethink_resource` VALUES ('24', '传承与理论4', '1', '2', '2', '4', '5', '2', '11', '0', '1443496757', '1443496757', '1', '0');
INSERT INTO `onethink_resource` VALUES ('25', '社会主义理论5', '1', '2', '1', '4', '5', '2', '123', '0', '1443496757', '1443496757', '1', '0');
INSERT INTO `onethink_resource` VALUES ('29', '资源名字', '1', '1', '6', '4', '8', '3', '0', '0', '1445941278', '1445941278', '1', '0');

-- -----------------------------
-- Table structure for `onethink_resource_tab`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_resource_tab`;
CREATE TABLE `onethink_resource_tab` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `type` tinyint(4) unsigned NOT NULL COMMENT '资源类型：0:其他  1:视频  2:文档',
  `name` varchar(40) COLLATE utf8_bin NOT NULL COMMENT '标签名字',
  `features` tinyint(4) NOT NULL DEFAULT '0' COMMENT '特征：1：标注  0:未标注 -1:全部',
  `create_time` int(10) unsigned NOT NULL COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL COMMENT '更新时间',
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '状态（-1：已删除，0：禁用，1：正常）',
  `sort` smallint(3) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- -----------------------------
-- Records of `onethink_resource_tab`
-- -----------------------------
INSERT INTO `onethink_resource_tab` VALUES ('1', '1', '马克思主义基本概论', '1', '1445775784', '1445775784', '1', '0');
INSERT INTO `onethink_resource_tab` VALUES ('2', '1', '毛泽东思想和中国特色社会主义理论体系概论', '1', '1442999223', '1442999223', '1', '0');
INSERT INTO `onethink_resource_tab` VALUES ('3', '1', '中国近现代史纲要', '1', '1442999223', '1442999223', '1', '0');
INSERT INTO `onethink_resource_tab` VALUES ('4', '1', '思想道德修养与法律基础', '1', '1442999223', '1442999223', '1', '0');
INSERT INTO `onethink_resource_tab` VALUES ('5', '1', '形势与政策', '1', '1442999223', '1442999223', '1', '0');
INSERT INTO `onethink_resource_tab` VALUES ('6', '1', '社会主义', '0', '1442999223', '1442999223', '1', '0');
INSERT INTO `onethink_resource_tab` VALUES ('7', '1', '邓小平理论', '0', '1442999223', '1442999223', '1', '0');
INSERT INTO `onethink_resource_tab` VALUES ('8', '1', '三个代表', '0', '1442999223', '1442999223', '1', '0');
INSERT INTO `onethink_resource_tab` VALUES ('9', '1', '社会主义核心价值观', '0', '1442999223', '1442999223', '1', '0');
INSERT INTO `onethink_resource_tab` VALUES ('10', '1', '中国特色社会主义理论', '0', '1442999223', '1442999223', '1', '0');

-- -----------------------------
-- Table structure for `onethink_ucenter_admin`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_ucenter_admin`;
CREATE TABLE `onethink_ucenter_admin` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '管理员ID',
  `member_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '管理员用户ID',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '管理员状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='管理员表';


-- -----------------------------
-- Table structure for `onethink_ucenter_app`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_ucenter_app`;
CREATE TABLE `onethink_ucenter_app` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '应用ID',
  `title` varchar(30) NOT NULL COMMENT '应用名称',
  `url` varchar(100) NOT NULL COMMENT '应用URL',
  `ip` char(15) NOT NULL DEFAULT '' COMMENT '应用IP',
  `auth_key` varchar(100) NOT NULL DEFAULT '' COMMENT '加密KEY',
  `sys_login` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '同步登陆',
  `allow_ip` varchar(255) NOT NULL DEFAULT '' COMMENT '允许访问的IP',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '应用状态',
  PRIMARY KEY (`id`),
  KEY `status` (`status`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='应用表';


-- -----------------------------
-- Table structure for `onethink_ucenter_member`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_ucenter_member`;
CREATE TABLE `onethink_ucenter_member` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户ID',
  `username` char(16) NOT NULL COMMENT '用户名',
  `password` char(32) NOT NULL COMMENT '密码',
  `email` char(32) NOT NULL COMMENT '用户邮箱',
  `mobile` char(15) NOT NULL DEFAULT '' COMMENT '用户手机',
  `reg_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '注册时间',
  `reg_ip` bigint(20) NOT NULL DEFAULT '0' COMMENT '注册IP',
  `last_login_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '最后登录时间',
  `last_login_ip` bigint(20) NOT NULL DEFAULT '0' COMMENT '最后登录IP',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) DEFAULT '0' COMMENT '用户状态',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  KEY `status` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COMMENT='用户表';

-- -----------------------------
-- Records of `onethink_ucenter_member`
-- -----------------------------
INSERT INTO `onethink_ucenter_member` VALUES ('1', 'admin', '6556f0cff7707117a47b5c34f8c2c9af', 'cheng1483@163.com', '', '1440939470', '2130706433', '1446210417', '0', '1440939470', '1');
INSERT INTO `onethink_ucenter_member` VALUES ('2', 'cheng1483', '02d610d0032cefc0c765648ec616a925', '1614638361@qq.com', '', '1440944344', '2130706433', '1440944380', '2130706433', '1440944344', '1');
INSERT INTO `onethink_ucenter_member` VALUES ('3', 'cc', 'd062e41c288edf2b138f4b532ea6db87', 'zz@qq.com', '', '1444206059', '2130706433', '0', '0', '1444206059', '1');
INSERT INTO `onethink_ucenter_member` VALUES ('4', 'cheng', 'd062e41c288edf2b138f4b532ea6db87', 'cheng1483@qq.com', '', '1444206181', '2130706433', '1444206608', '2130706433', '1444206181', '1');
INSERT INTO `onethink_ucenter_member` VALUES ('5', 'zz1234', 'd062e41c288edf2b138f4b532ea6db87', 'qq@qq.com', '', '1444206727', '2130706433', '1444206774', '2130706433', '1444206727', '1');
INSERT INTO `onethink_ucenter_member` VALUES ('6', 'cctv', '798d1203dcfde7b9c9f7487f05e37664', 'cheng1483@164.com', '', '1445427869', '2130706433', '1445427090', '2130706433', '1445427869', '1');

-- -----------------------------
-- Table structure for `onethink_ucenter_setting`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_ucenter_setting`;
CREATE TABLE `onethink_ucenter_setting` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '设置ID',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '配置类型（1-用户配置）',
  `value` text NOT NULL COMMENT '配置数据',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='设置表';


-- -----------------------------
-- Table structure for `onethink_url`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_url`;
CREATE TABLE `onethink_url` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '链接唯一标识',
  `url` char(255) NOT NULL DEFAULT '' COMMENT '链接地址',
  `short` char(100) NOT NULL DEFAULT '' COMMENT '短网址',
  `status` tinyint(2) NOT NULL DEFAULT '2' COMMENT '状态',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_url` (`url`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='链接表';


-- -----------------------------
-- Table structure for `onethink_userdata`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_userdata`;
CREATE TABLE `onethink_userdata` (
  `uid` int(10) unsigned NOT NULL COMMENT '用户id',
  `type` tinyint(3) unsigned NOT NULL COMMENT '类型标识',
  `target_id` int(10) unsigned NOT NULL COMMENT '目标id',
  UNIQUE KEY `uid` (`uid`,`type`,`target_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

